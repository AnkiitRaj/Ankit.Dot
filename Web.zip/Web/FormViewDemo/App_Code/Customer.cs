﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customer
/// </summary>
/// 
[Serializable]
public class Customer
{
    public int cid;
    public string cname;
    public DateTime cdob;
    public string cstatus;
    public string ccity;
    public double cout;

	public Customer()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public Customer(int cid, string cname, DateTime cdob, string cstatus, string ccity, double cout)
    {
        this.cid = cid;
        this.cname = cname;
        this.cdob = cdob;
        this.cstatus = cstatus;
        this.ccity = ccity;
        this.cout = cout;
    }
}