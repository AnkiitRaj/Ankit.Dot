﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["cust"] != null)
        {
            Customer c = (Customer)Session["cust"];
            ListBox1.Items.Add(c.cid.ToString());
            ListBox1.Items.Add(c.cname.ToString());
            ListBox1.Items.Add(c.cdob.ToString());
            ListBox1.Items.Add(c.cstatus.ToString());
            ListBox1.Items.Add(c.ccity.ToString());
            ListBox1.Items.Add(c.cout.ToString());
            ListBox1.Items.Add(Session.SessionID); 
        }
        if (Session["LoginTime"] != null)
        {
            ListBox1.Items.Add(Session["LoginTime"].ToString());
            //Session.Remove("LoginTime");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}