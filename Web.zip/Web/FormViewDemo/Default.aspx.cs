﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
[Serializable]

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("Hello !! You are the " + Session["UserCount"].ToString() + " user visiting our site");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        FormView2.ChangeMode(FormViewMode.Insert);
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        Calendar mycal = (Calendar)FormView2.FindControl("frmView2Calenderdob");
        mycal.Visible = true;
    }
    protected void frmView2Calenderdob_SelectionChanged(object sender, EventArgs e)
    {
        ((TextBox)FormView2.FindControl("cdobTextBox")).Text = ((Calendar)sender).SelectedDate.ToString();
        ((Calendar)sender).Visible = false;
        DateTime nw = DateTime.Now;
        DateTime dob = ((Calendar)sender).SelectedDate;
        //TimeSpan ts = DateTime.Today - ((Calendar)sender).SelectedDate;
        TimeSpan t = nw - dob;
        if (t.TotalDays / 365.25 >= 60)
        {
            ((TextBox)FormView2.FindControl("cstatusTextBox")).Text = "sc";
        }
        else 
        {
            ((TextBox)FormView2.FindControl("cstatusTextBox")).Text = "nsc";
        }
    }
    protected void cdobTextBox_TextChanged(object sender, EventArgs e)
    {
        Calendar mycal = (Calendar)FormView2.FindControl("frmView2Calenderdob");
        mycal.SelectedDate = DateTime.Parse(((TextBox)FormView2.FindControl("cdobTextBox")).Text);
        mycal.VisibleDate = DateTime.Parse(((TextBox)FormView2.FindControl("cdobTextBox")).Text);
    }
   
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Calendar mycal = (Calendar)FormView2.FindControl("frmView2Calenderdob");
        mycal.VisibleDate = DateTime.Parse("07/01/"+((DropDownList)sender).SelectedValue.ToString());
        mycal.SelectedDate = DateTime.Parse("07/01/"+((DropDownList)sender).SelectedValue.ToString());
    }

    protected void DropDownList2_Load(object sender, EventArgs e)
    {
        DateTime currentDate = DateTime.Today;
        DateTime maxDate = currentDate.AddYears(-18);
        DateTime minDate = currentDate.AddYears(-80);
        for (int i = minDate.Year; i <= maxDate.Year; i++)
            ((DropDownList)sender).Items.Add(i.ToString());
        Calendar mycal = (Calendar)FormView2.FindControl("frmView2Calenderdob");
        mycal.VisibleDate = DateTime.Parse("07/01/" +
            ((DropDownList)sender).SelectedValue.ToString());
        mycal.SelectedDate = DateTime.Parse("07/01/" +
            ((DropDownList)sender).SelectedValue.ToString());
    }
    protected void Button1_Click2(object sender, EventArgs e)
    {
        Customer mycust = new Customer();
        mycust.cid = int.Parse(((Label)FormView2.FindControl("cidLabel")).Text);
        mycust.cname = ((Label)FormView2.FindControl("cnameLabel")).Text;
        mycust.cdob = DateTime.Parse(((Label)FormView2.FindControl("cdobLabel")).Text);
        mycust.cstatus = ((Label)FormView2.FindControl("cstatusLabel")).Text;
        mycust.ccity = ((Label)FormView2.FindControl("ccityLabel")).Text;
        mycust.cout = double.Parse(((Label)FormView2.FindControl("coutLabel")).Text);
        Session["cust"] = mycust; 
        //Session.Add("LoginTime",DateTime.Now.ToShortTimeString());
        //Session.Timeout = 1;
        Response.Redirect("Default2.aspx");
    }
}