﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

/// <summary>
/// Summary description for ErrorHandling
/// </summary>
public static class ErrorHandling
{
	public static void LogError(string path, string message)
	{
        FileStream fs = File.Open(path, FileMode.OpenOrCreate | FileMode.Append);
        StreamWriter sw = new StreamWriter(fs);
        sw.WriteLine(message);
        sw.Close();
        fs.Close();
    }
}