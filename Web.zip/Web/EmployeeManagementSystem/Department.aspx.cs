﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;
using BusinessObjects;

public partial class Department : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnDeptAdd_Click(object sender, EventArgs e)
    {
        //try
        //{
            DeptBO deptbo = new DeptBO(int.Parse(txtDeptiD.Text), txtDeptName.Text, txtDeptLoc.Text);
            DeptBL dept = new DeptBL();
            object id = null;
            if (dept.AddDept(deptbo, out id) >= 1)
            {
                DeptMessage.Text = "Insert Successfull";
                txtDeptiD.Text = id.ToString();
            }
            else
                DeptMessage.Text = "Insert Unsucessfull";
        //}
        //catch
        //{
        //    Response.Redirect("ErrorPage.html");
        //}
    }
}