﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Caching;

public partial class CachingDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Cache["mycache"] == null)
        {
            Response.Write(DateTime.Now.ToLongTimeString());
            Cache.Insert("mycache", DateTime.Now.ToLongTimeString(), new SqlCacheDependency("sales_proj", "dept"));
                //new CacheDependency(@"d:\a.txt"));
                //null, DateTime.Now.AddSeconds(10), System.Web.Caching.Cache.NoSlidingExpiration);
        }
        else
        {
            Response.Write("Displaying the cachce Value..");
            Response.Write(Cache["mycache"].ToString());
        }
    }
    //public static string SubMethod(HttpContext hc)
    //{
    //    return DateTime.Now.ToLongTimeString();
    //}
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Write("Removing the cache...");
        Cache.Remove("mycache");
    }
}