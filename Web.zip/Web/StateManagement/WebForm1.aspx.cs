﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = "";
        string lastvisit = "";
        if (Request.Cookies["mycookie"] != null)
        {
            HttpCookie rcookie = Request.Cookies["mycookie"];
            name = rcookie["name"].ToString();
            lastvisit = rcookie["lastvisit"].ToString();
        }

        greetings.InnerHtml = "Hello " + name + "</br> You Last Visited on " + lastvisit;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Request.Cookies["mycookie"] != null)
        {
            Response.Cookies["mycookie"].Expires = DateTime.Now.AddSeconds(-10);
            //Response.Cookies["lastvisit"].Expires = DateTime.Now.AddSeconds(-10);
            //Response.Redirect("WebForm2.aspx");
        }
        
    }
}