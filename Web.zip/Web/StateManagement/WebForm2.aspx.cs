﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Cookies["mycookie"] != null)
            Response.Redirect("WebForm1.aspx");
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {

        if (TextBox1.Text == "abc" && TextBox2.Text == "1234")
        {
            HttpCookie mycookie = new HttpCookie("mycookie");
            mycookie["name"] = TextBox1.Text;
            mycookie["lastvisit"] = DateTime.Now.ToString();
            mycookie.Expires = DateTime.Now.AddMinutes(5);
            Response.Cookies.Add(mycookie);
            Response.Redirect("WebForm1.aspx?"); //name=".TextBox1.Text);
            //ViewState["name"] = TextBox1.Text;
        }
    }
}