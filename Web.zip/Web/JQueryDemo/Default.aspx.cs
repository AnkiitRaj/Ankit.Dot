﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    public class Customer
    {
        public string name;
        public string gender;
        public string city;
        public string dob;
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    [WebMethod]
    public static string SaveToDatabase(string name, string city, string gender, string dob)
    {
        SqlConnection con=null;
        try
        {
            DateTime mydob = DateTime.Parse(dob);
            string constring =
                    ConfigurationManager.AppSettings["sqlConnection"].ToString();
            con = new SqlConnection(constring);
            SqlCommand insCommand = new SqlCommand();
            insCommand.CommandText =
                "insert into myuser(name,city,gender,dob)values(@name,@city,@gender,@dob)";
            insCommand.CommandType = CommandType.Text;
            insCommand.Connection = con;
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@name", name);
            param[0] = new SqlParameter("@city", city);
            param[0] = new SqlParameter("@gender", gender);
            param[0] = new SqlParameter("@dob", mydob);
            insCommand.Parameters.AddRange(param);
            con.Open();
            insCommand.ExecuteNonQuery();
        }
        catch
        {
            con.Close();
            return "failure";
        }
        finally
        {
            con.Close();
        }
       
        return "success";
    }
    [WebMethod]
    public static string SaveToDatabase(Customer[] mycust)
    {
        SqlConnection con = null;
    //    SqlConnection con = null;
    //    try
    //    {
    //        DateTime mydob = DateTime.Parse(dob);
    //        string constring =
    //                ConfigurationManager.AppSettings["sqlConnection"].ToString();
    //        con = new SqlConnection(constring);
    //        SqlCommand insCommand = new SqlCommand();
    //        insCommand.CommandText =
    //            "insert into myuser(name,city,gender,dob)values(@name,@city,@gender,@dob)";
    //        insCommand.CommandType = CommandType.Text;
    //        insCommand.Connection = con;
    //        SqlParameter[] param = new SqlParameter[4];
    //        param[0] = new SqlParameter("@name", name);
    //        param[0] = new SqlParameter("@city", city);
    //        param[0] = new SqlParameter("@gender", gender);
    //        param[0] = new SqlParameter("@dob", mydob);
    //        insCommand.Parameters.AddRange(param);
    //        con.Open();
    //        insCommand.ExecuteNonQuery();
    //    }
    //    catch
    //    {
    //        con.Close();
    //        return "failure";
    //    }
    //    finally
    //    {
    //        con.Close();
    //    }

        return "success";
    }
}