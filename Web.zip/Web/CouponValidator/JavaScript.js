﻿function getcoupon() {

    $.ajax({
        type: "POST",
        url: "Default.aspx/GetDetail",
        data: JSON.stringify({ coupon_code: $("#coupon_code").val() }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            console.log(data.d);
            //Check if Coupon is valid
            if (data.d != "No") {
                //If valid split using '-'
                var SplittedValues = data.d.split("-");
                var total = $("#TotalAmount").text();
                //check is coupon amount need to deduct in percent or not
                if (SplittedValues[1] == "1") {
                    //yes percent

                    var PercentTodeduct = SplittedValues[0];

                    var PercentOftotal = (parseFloat((PercentTodeduct / 100)) * parseFloat(total)); //calculate percent of total
                    console.log(PercentOftotal);
                    //deduct amount
                    $("#TotalAmountAfterDcisount").html(parseInt(total, 10) - parseInt(PercentOftotal, 10));
                }
                else {
                    // minus amount directly

                    var AmountTodeduct = SplittedValues[0];

                    //deduct amount
                    $("#TotalAmountAfterDcisount").html(parseInt(total, 10) - parseInt(AmountTodeduct, 10));
                }
            }
            else {
                //if "No" is sent, alert invalid coupun code
                alert("Invalid coupon code");
            }

        },
        failure: function (response) {
            alert("Failed");
        }
    });
}

$(document).ready(function () {

    $("#Apply_Coupon").on('click', getcoupon);
})