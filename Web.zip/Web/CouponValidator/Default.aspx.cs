﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    [System.Web.Services.WebMethod]
    public static string GetDetail(string coupon_code)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = @"Server=DESKTOP-PC\SQLEXPRESS2;Database=DatabaseName;Trusted_Connection=true";
            string s = "select voucher_amount,Off_type from admin_voucher where voucher_code='" + coupon_code + "'";

            SqlDataAdapter da = new SqlDataAdapter();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = s;
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();

            conn.Open();
            da.Fill(ds);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    //return both Amount and Off-Type
                    return Math.Round(Convert.ToDecimal(ds.Tables[0].Rows[0][0]), 2).ToString() + "-" + ds.Tables[0].Rows[0][1].ToString();
                }
                else
                {

                    return "No"; //means invalid coupon code
                }
            }
            else
            {
                return "No";
            }

        }
    }
}