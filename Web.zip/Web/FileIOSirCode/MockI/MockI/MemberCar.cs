﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class MemberCar
    {
        private long _id;

        public long Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private Member _member;

        internal Member Member
        {
            get { return _member; }
            set { _member = value; }
        }
        private Car _car;

        internal Car Car
        {
            get { return _car; }
            set { _car = value; }
        }
        private string _carRegistrationNumber;

        public string CarRegistrationNumber
        {
            get { return _carRegistrationNumber; }
            set { _carRegistrationNumber = value; }
        }
        private string _carColor;

        public string CarColor
        {
            get { return _carColor; }
            set { _carColor = value; }
        }
        public MemberCar()
        { }
        public MemberCar(long id, Member member, Car car, string carregistrationnumber, string carcolor)
        {
            this.Id = id;
            this.Member = member;
            this.Car = car;
            this.CarRegistrationNumber = carregistrationnumber;
            this.CarColor = carcolor;
        }
    }

