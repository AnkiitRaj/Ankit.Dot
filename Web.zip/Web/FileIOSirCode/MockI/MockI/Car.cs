﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Car
    {
        private long _id;

        public long Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _model;

        public string Model
        {
            get { return _model; }
            set { _model = value; }
        }
        private int _makeYear;

        public int MakeYear
        {
            get { return _makeYear; }
            set { _makeYear = value; }
        }
        private string _company;

        public string Company
        {
            get { return _company; }
            set { _company = value; }
        }
        private int _comfortLevel;

        public int ComfortLevel
        {
            get { return _comfortLevel; }
            set { _comfortLevel = value; }
        }
        
        public Car()
        { }
        public Car(long id, string name, string model, int makeyear, string company, int comfortlevel)
        {
            this.Id = id;
            this.Name = name;
            this.Model = model;
            this.MakeYear = makeyear;
            this.Company = company;
            this.ComfortLevel = comfortlevel;
        }
        public static Car FindCar(long carID, ArrayList carList)
        {
            Car cr = null;
            foreach (Car c in carList)
            {
                if (c.Id == carID)
                    cr = c;

            }
            return cr;

        }


        internal static ArrayList InitCar()
        {
            throw new NotImplementedException();
        }
    }

