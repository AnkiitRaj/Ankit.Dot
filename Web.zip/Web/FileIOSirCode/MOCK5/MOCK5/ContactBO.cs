﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class ContactBO : Contact
{
    public List<Contact> FindContact(List<Contact> contactList, List<string> name)
    {
        List<Contact> cl = new List<Contact>();
        foreach (string s in name)
        {
            foreach (Contact c in contactList)
            {
                if (c.Name.Equals(s))
                    cl.Add(c);
            }
        }
        return cl;
    }
    public List<Contact> FindContact(List<Contact> contactList, DateTime dateCreated)
    {
        List<Contact> cl = new List<Contact>();
        foreach (Contact c in contactList)
        {
            if (c.DateCreated == dateCreated)
            {
                cl.Add(c);
            }
        }
        return cl;
    }
    public List<Contact> FindContact(List<Contact> contactList, string domain)
    {
        List<Contact> cl = new List<Contact>();
        foreach (Contact c in contactList)
        {
            if (c.Company == domain)
                cl.Add(c);
        }
        return cl;
    }
}