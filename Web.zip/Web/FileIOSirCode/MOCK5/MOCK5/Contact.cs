﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Contact
{
    
    //fill code here.
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private string _company;

    public string Company
    {
        get { return _company; }
        set { _company = value; }
    }
    private string _title;

    public string Title
    {
        get { return _title; }
        set { _title = value; }
    }
    private string _mobile;

    public string Mobile
    {
        get { return _mobile; }
        set { _mobile = value; }
    }
    private string _alternateMobile;

    public string AlternateMobile
    {
        get { return _alternateMobile; }
        set { _alternateMobile = value; }
    }
    private string _email;

    public string Email
    {
        get { return _email; }
        set { _email = value; }
    }
    private DateTime _dateCreated;

    public DateTime DateCreated
    {
        get { return _dateCreated; }
        set { _dateCreated = value; }
    }
    public Contact() { }
    public Contact(string Name, string Company, string Title, string Mobile, string AlternateMobile, string Email, DateTime DateCreated)
    {
        this.Name = Name;
        this.Company = Company;
        this.Title = Title;
        this.Mobile = Mobile;
        this.AlternateMobile = AlternateMobile;
        this.Email = Email;
        this.DateCreated = DateCreated;
    }
    public override string ToString()
    {
        return String.Format("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", this.Name, this.Company, this.Title, this.Mobile, this.AlternateMobile, this.Email, this.DateCreated.ToString("dd-MM-yyyy"));
    }

    public static SortedDictionary<string, int> GetContactCountForDomain(List<Contact> list)
    {
        SortedDictionary<string, int> lst = new SortedDictionary<string, int>();
        foreach (var obj in list)
        {
            string[] s = obj.Email.Split('@');
            string[] arr = s[1].Split('.');
            string domain = arr[0];
            if (!lst.ContainsKey(domain))
            {
                
                lst.Add(domain, 1);
            }
            else
            {
                lst[domain]++;
            }
        }
        return lst;
    }
}
