﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        SortedDictionary<string, int> lst1 = new SortedDictionary<string, int>();
        List<Contact> ls = new List<Contact>();
        Contact c = new Contact();
        Console.WriteLine("Enter the number of contacts:");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            string s = Console.ReadLine();
            string[] s1 = s.Split(',');
            string name = s1[0];
            string company = s1[1];
            string title = s1[2];
            string mo = s1[3];
            string am = s1[4];
            string e = s1[5];
            string date = s1[6];
            DateTime d = DateTime.ParseExact(date, "dd-MM-yyyy", null);
            c=new Contact(name, company, title, mo, am, e, d);
            //lst.Add(name, c);
            ls.Add(c);
        }
       lst1= Contact.GetContactCountForDomain(ls);
       Console.WriteLine("{0} {1,20}", "Domain Name", "Count");

       foreach (var obj in lst1)
       {
           
           Console.WriteLine("{0} {1,20}",obj.Key,obj.Value);
       }
        Console.ReadKey();
    }
}
