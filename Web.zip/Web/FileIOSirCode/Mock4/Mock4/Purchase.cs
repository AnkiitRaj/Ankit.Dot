﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Purchase:IComparable<Purchase>
    {
        private long _id;

        public long Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private DateTime _purchaseDate;

        public DateTime PurchaseDate
        {
            get { return _purchaseDate; }
            set { _purchaseDate = value; }
        }
        private double _totalAmount;

        public double TotalAmount
        {
            get { return _totalAmount; }
            set { _totalAmount = value; }
        }
        private string _user;

        public string User
        {
            get { return _user; }
            set { _user = value; }
        }
        public Purchase() { }
        public Purchase(long _id, DateTime _purchaseDate, double _totalAmount, string _user)
        {
            this.Id = _id;
            this.PurchaseDate = _purchaseDate;
            this.TotalAmount = _totalAmount;
            this.User = _user;
        }

        public static Purchase ObtainPurchaseWithAmount(String str)
        {
            Purchase p = null;
            string[] arr = str.Split(',');
            //int f = 0;
            int len = arr.Length;
            if(len>=18)
            {
                double sum = 0;
                for (int i = 4; i < arr.Length; i = i + 3)
                {
                    double am = double.Parse(arr[i]);
                    int q = int.Parse(arr[i+1]); 
                    sum += (am*q);
                }
                long id = long.Parse(arr[0]);
                string dt = arr[1];
                DateTime d = DateTime.ParseExact(dt,"dd-MM-yyyy",null);
                double tam = sum;
                string user = arr[2];

                p = new Purchase(id,d,tam,user);
            }
            return p;
        }


        public int CompareTo(Purchase other)
        {
            if (this.Id.CompareTo(other.Id) == 1)
                return -1;
            else if (this.Id.CompareTo(other.Id) == -1)
                return 1;
            return 0;
        }
    }
