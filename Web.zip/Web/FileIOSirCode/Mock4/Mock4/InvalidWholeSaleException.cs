﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class InvalidWholeSaleException:Exception
    {
      public InvalidWholeSaleException(string s):base(s)
      {
          Console.WriteLine("InvalidWholeSaleException: Purchase {0} is not a whole sale",s);

      }
      public InvalidWholeSaleException() { }
    }
