//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.IO;

//public class Program
//{
//    public static void Main(string[] args)
//    {
//        List<Booking> bl = new List<Booking>();
//        string a ="yes";
//        do
//        {
//            Console.WriteLine("Enter a booking detail:");
//            string b = Console.ReadLine();
//            string [] s = b.Split(',');
//            long bid = long.Parse(s[0]);
//            DateTime d = DateTime.ParseExact(s[1],"dd-MM-yyyy",null);
//            string pm = s[2];
//            long cid = long.Parse(s[3]);
//            long crdid = long.Parse(s[4]);
//            double amt = double.Parse(s[5]);
//            string ser = s[6];
//            bl.Add(new Booking(bid,d,pm,cid,crdid,amt,ser));
//            Console.WriteLine("Do you want to add another booking detail:");
//            a = Console.ReadLine();
//        }while(a=="yes");

//        SortedDictionary<string, List<Booking>> dic = new SortedDictionary<string, List<Booking>>();
//        dic = Booking.OrganizeBookings(bl);
//        Console.WriteLine("Name - No of Booking");
//        foreach(KeyValuePair<string ,List<Booking>> bf in dic)
//        {
//            Console.WriteLine(bf.Key+" - "+bf.Value);
//        }
//        List<string> ls = new List<string>();
//        ls = Booking.FindBestServiceEngineer(dic);
//        Booking.OrganizeBookings(bl);
//        Console.ReadKey();
//    }
//}
using System;

using System.Collections;

using System.Collections.Generic;

using System.IO;

using System.Linq;

public class Program
{

    public static void Main(string[] args)
    {

        //fill code here.

        List<Booking> bl = new List<Booking>();

        List<string> ls = new List<string>();

        string a = "yes";

        do
        {

            Console.WriteLine("Enter a booking detail:");

            string b = Console.ReadLine();

            string[] s = b.Split(',');

            long bid = long.Parse(s[0]);

            DateTime d = DateTime.ParseExact(s[1], "dd-MM-yyyy", null);

            string pm = s[2];

            long cid = long.Parse(s[3]);

            long crdid = long.Parse(s[4]);

            double amt = double.Parse(s[5]);

            string ser = s[6];

            bl.Add(new Booking(bid, d, pm, cid, crdid, amt, ser));

            ls.Add(ser);

            Console.WriteLine("Do you want to add another booking detail:");

            a = Console.ReadLine();

        } while (a == "yes");



        //SortedDictionary<string, List<Booking>> dic = new SortedDictionary<string, List<Booking>>();

        //dic = Booking.OrganizeBookings(bl);

        //Console.WriteLine("Name - No of Booking");

        //foreach(KeyValuePair<string ,List<Booking>> bf in dic)

        //{

        // Console.WriteLine(bf.Key+"-"+bf.Value.Count);

        //}

        //List<string> ls = new List<string>();

        //ls = Booking.FindBestServiceEngineer(dic);

        //Booking.OrganizeBookings(bl);

        List<string> bas = ls.Distinct().ToList();

        int c = 0;

        Console.WriteLine("Name - No of Booking");

        for (int i = 0; i < bas.Count; i++)
        {

            for (int j = 0; j < ls.Count; j++)
            {

                if (bas[i] == ls[j])
                {

                    c++;

                }

            }

            Console.WriteLine(bas[i] + "-" + c);

        }



        Console.ReadKey();

    }

}