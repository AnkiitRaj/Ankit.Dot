﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace FileIO
{
    [Serializable]
    class Employee
    {
        public int eid;
        public string name;
        public double sal;
        public Employee() { }
        public Employee(int eid, string name, double sal)
        {
            this.eid = eid;
            this.name = name;
            this.sal = sal;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string ans = "y";
            do
            {
                Console.WriteLine("1.Insert Record");
                Console.WriteLine("2.Update Record");
                Console.WriteLine("3.Delete Record");
                Console.WriteLine("4.Display Record");
                Console.WriteLine("5.Defragment Record");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        InsertRecord();
                        break;
                    case 2:
                        UpdateRecord();
                        break;
                    case 3:
                        DeleteRecord();
                       break;
                    case 4:
                        DisplayRecord();
                        break;
                    case 5:
                        Defragement();
                        break;
                }
                Console.Write("Wanna Continue(y/n)::");
                ans = Console.ReadLine();
            } while (ans == "y");
        }
        static void InsertRecord()
        {
            Console.Write("Enter Your ID :");
            int eid = int.Parse(Console.ReadLine());
            Console.Write("Enter Your Name:");
            string name = Console.ReadLine();
            Console.Write("Enter Your Salary:");
            double sal = double.Parse(Console.ReadLine());
            FileStream fs = new FileStream(@"D:\Ank\IO\employeeInfo1.txt",FileMode.OpenOrCreate|FileMode.Append);
            Employee emp = new Employee(eid,name,sal);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, emp);
            fs.Close();
            Console.WriteLine("Data Successfully Saved....");
        }
        static long RecordSearch(string name)
        {
            FileStream fs = new FileStream(@"D:\Ank\IO\employeeInfo.txt", FileMode.Open);
            char c = '\0';
            string s = "";
            int flag = 0;
            while (fs.Position < fs.Length)
            {
                c = (char)fs.ReadByte();
                if (c == ',' || c == '\n')
                {
                    s = "";
                    continue;
                }
                s += c.ToString();
                if (s == name)
                {
                    flag = 1;
                    break;
                }
            }
            if (flag == 1)
            {
                long pos = fs.Position;
                fs.Close();
                return pos;
            }
            fs.Close();
            return -1;
        }
        static void UpdateRecord()
        {
            Console.Write("Enter Name::");
            string name = Console.ReadLine();
            long pos = RecordSearch(name);
            FileStream fs = new FileStream(@"D:\Ank\IO\employeeInfo.txt", FileMode.OpenOrCreate);
            StreamWriter sw = new StreamWriter(fs);
            fs.Position = pos - name.Length;
            for (int i = 0; i < name.Length; i++)
            {
                fs.WriteByte((byte)' ');
            }
            fs.Position = fs.Length;
            sw.Write("\n\r");
            sw.Write(name);
            sw.Write(",");
            Console.Write("Enter New City::");
            string city = Console.ReadLine();
            sw.Write(city);
            sw.Write(",");
            Console.Write("Enter New Salary::");
            double sal = double.Parse(Console.ReadLine());
            sw.WriteLine(sal);
            sw.Close();
            fs.Close();
        }
        static void DeleteRecord()
        {
        }
        static void DisplayRecord()
        {
            Console.WriteLine("Reading From File......");
            FileStream fs = File.OpenRead(@"D:\Ank\IO\employeeInfo2.txt");
            BinaryFormatter bf = new BinaryFormatter();
           
            Console.WriteLine("ID\tName\tSalary");
            while (fs.Position < fs.Length)
            {
                Employee e = (Employee)bf.Deserialize(fs);
                Console.WriteLine(e.eid + "\t" +
                                    e.name + "\t" +
                                    e.sal);
            }
            fs.Close();
        }
        static void Defragement()
        {
            List<string> mydata = new List<string>();
            StreamReader sr = new StreamReader(@"D:\Ank\IO\employeeInfo.txt");
            while (!sr.EndOfStream)
            {
                string r = sr.ReadLine();
                string[] s = r.Split(',');
                if (s[0].Trim().Length != 0)
                {
                    mydata.Add(r);
                }
            }
            sr.Close();
            File.Delete(@"D:\Ank\IO\employeeInfo.txtt");
            StreamWriter sw = new StreamWriter(@"D:\Ank\IO\employeeInfo.txt", true);
            foreach (string r in mydata)
            {
                string[] s = r.Split(',');
                sw.Write(s[0]);
                sw.Write(",");
                sw.Write(s[1]);
                sw.Write(",");
                sw.WriteLine(s[2]);

            }
        }
    }
}