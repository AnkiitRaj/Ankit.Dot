﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 

class Program
    {
        public class Employee
        {
            public string name;
            public double sal;
            public int grade;
            public Employee() { }
            public Employee(string name, double sal, int grade)
            {
                this.name = name;
                this.sal = sal;
                this.grade = grade;
            }

        }
        public delegate int calc(int x, int y);
        calc c;
        public Program()
        {
            //c = new calc(Add);
            c += Add;
            c += Sub;
            c += delegate(int x, int y) // anonymous methods.
            {
                Console.WriteLine("Multiply Called..");
                return x * y;
            };
            c += (x, y) => { Console.WriteLine("Divide Called.."); return x / y; };  // This is Known as => Goes To '=>' // Lambda Expressions.
            // Anonymous Function: anonymous method and lambda expression.

            Console.WriteLine(c(10,5));
        }
        public int Add(int x, int y)
        {
            Console.WriteLine("Add Called..");
            return x + y;
        }
        public int Sub(int x, int y)
        {
            Console.WriteLine("Sub Called..");
            return x - y;
        }
        static void Main(string[] args)
        {
            ////Data Source
            //string[] names = { "Bill", "Steve", "James", "Mohan" };
            ////LInq Query
            //var myLinqQuery = from name in names
            //                  where name.Contains('a')
            //                  select name;
            ////Query Execution
            //foreach (var name in myLinqQuery)
            //    Console.WriteLine(name + " ");

            //var myLinqQuery = names.OrderByDescending(name => name);
            //foreach(var name in myLinqQuery)
            //    Console.WriteLine(name);

            //Program p = new Program();


            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee("Zaheer", 800, 5));
            empList.Add(new Employee("Amir", 1600, 19));
            empList.Add(new Employee("Sohaib", 1700, 10));
            //empList.Sort();
            //r in his name and salary 

            Console.WriteLine("*************************************************");
            var query = from emp in empList
                        where emp.name.Contains('r') && emp.sal > 1000
                        select emp;
            foreach (var q in query)
            {
                Console.WriteLine(q.name + "\t" + q.sal + "\t" + q.grade);
            }

            Console.WriteLine("*************************************************");
            var newList = empList.Where(e => e.name.Contains('r') && e.sal > 1000);
            foreach(Employee e in newList)
                Console.WriteLine(e.name + "\t" + e.sal + "\t" + e.grade);
            
            Console.WriteLine("*************************************************");
            var sortedList = empList.OrderBy(e => e.sal).ThenBy(e => e.grade);
            foreach(Employee e in sortedList)
            Console.WriteLine(e.name+ "\t" + e.sal + "\t" + e.grade);
            Console.WriteLine("*************************************************");
            
            Console.ReadKey();
        }
    }
