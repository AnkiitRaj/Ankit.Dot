﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        Dictionary<string, string> dict = new Dictionary<string, string>();
        string res = "no";
        do
        {
            Console.WriteLine("Enter the player name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter wickets - seperated by \"|\" symbol");
            string wicket = Console.ReadLine();
            dict.Add(name, wicket);
            Console.WriteLine("Do you want to add another player (yes/no)");
            res = Console.ReadLine();

        } while (res == "yes");
        int count = 0; string c = null;
        do
        {
            Console.WriteLine("Enter the player name to search");
            string s = Console.ReadLine();

            foreach (KeyValuePair<string, string> item in dict)
            {
                if (item.Key.Contains(s))
                {
                    count++;
                    Console.WriteLine("Player Name : {0}", item.Key);
                    string[] str = item.Value.Split('|');
                    Console.WriteLine("Wickets :");
                    for (int i = 0; i < str.Length; i++)
                    {
                        Console.WriteLine(str[i]);
                    }
                }

            }
            if (count == 0)
            {
                Console.WriteLine("No player found with the name {0}", s);
            }
            Console.WriteLine("Do you want to search another player (yes/no)");
            c = Console.ReadLine();

        } while (c == "yes");
        Console.ReadLine();




    }
}

