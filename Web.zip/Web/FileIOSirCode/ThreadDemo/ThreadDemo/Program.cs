﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadDemo
{
    class Program
    {
        //int count = 0;
        //int readCount = 0, writeCount = 0, diff =0;
        StringBuilder message = new StringBuilder("HelloWorld");
        object lockon = new object();
        public Program()
        {
            Console.WriteLine("Main Thread Starts...");
            Thread read = new Thread(readMessage);
            Thread write = new Thread(writeMessage);
            //write.IsBackground = true;
            //read.IsBackground = true;
            read.Name = "Read";
            write.Name = "Write";
            //write.Priority = ThreadPriority.Lowest;
            //read.Priority = ThreadPriority.Highest;
            write.Start();
            read.Start();
            //write.Join();
           // read.Join();
            Console.WriteLine("Main Thread Ends...");
        }
        void readMessage()
        {
            while (true)
            {
                lock (lockon)
                {
                    string name = Thread.CurrentThread.Name;
                    Console.WriteLine(name + " : acquired Lock...");
                    if (message.Length == 0)
                    {
                        Console.WriteLine("Nothing to read..");
                        Thread.Sleep(1000);
                    }
                        for (int i = 0; i < message.Length; i++)
                    {
                        Console.WriteLine(message[i]);
                        Thread.Sleep(100);
                    }
                    message.Clear();
                    Console.WriteLine(name + " : release Lock.. ");
                }
            }
        }
        void writeMessage()
        {
            while (true)
            {
                lock (lockon)
                {
                    string name = Thread.CurrentThread.Name;
                    Console.WriteLine(name + " : acquired lock..");
                    if (message.Length > 0)
                    {
                        Console.WriteLine("Sorry! Data not read..");
                        Thread.Sleep(1000);
                        goto gohere;
                        
                    }
                        for (int i = 0; i < 10; i++)
                    {
                        message.Insert(i, (char)(97 + 1));
                        Console.Write(".");
                        Thread.Sleep(1000);
                    }
                gohere:
                    Console.WriteLine();
                    Console.WriteLine(name + " release lock..");
                }
            }
        }
        //public void run()
        //{
        //    int opp = 0;
        //    Console.WriteLine(Thread.CurrentThread.Name + "starts executing...");
        //    for (; count < 1000; count++)
        //    {
        //        Console.WriteLine(Thread.CurrentThread.Name + ":" + (count+1));
        //        //if (Thread.CurrentThread.Name == "Read")
        //        //    Thread.Sleep(800);
        //        //else
        //        //    Thread.Sleep(1000);
        //        opp++;
        //    }
        //    Console.WriteLine(Thread.CurrentThread.Name + " got " + opp + " opportunity to execute before ending");
        //    if (Thread.CurrentThread.Name == "Read")
        //        readCount = opp;
        //    else if (Thread.CurrentThread.Name == "Write")
        //        writeCount = opp;
        //    //if (writeCount > readCount)
        //    //    diff = writeCount - readCount;
        //    //else
        //    //    diff = readCount - writeCount;
        //    Console.WriteLine("Diff is " + Math.Abs(readCount - writeCount));
        //}
        static void Main(string[] args)
        {
            new Program();
            Console.ReadKey();
        }
    }
}
