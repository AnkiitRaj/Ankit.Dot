use sales_proj;

create table employee
(
id int primary key identity,
name varchar(100) not null,
suffix char(5) not null,
gender char(10) not null,
dob date not null,
address varchar(1000) not null,
email varchar(100),
tel varchar(20)
);

select * from employee;

truncate table employee;
