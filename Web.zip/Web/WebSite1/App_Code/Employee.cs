﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
[Serializable]

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{
    public int id;
    public string suffix;
    public string name;
    public string gender;
    public string address;
    public DateTime dob;
    public string email;
    public string phone;

	public Employee()
	{
	}
    public Employee(string name, string gender,string address, DateTime dob, string email, string phone)
    {
        this.name = name;
        this.gender = gender;
        this.address = address;
        this.dob = dob;
        this.email=email;
        this.phone = phone;
    }
}