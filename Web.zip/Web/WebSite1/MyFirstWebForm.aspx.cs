﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class MyFirstWebForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = Request.Params["name"].ToString();
        string suffix = Request.Params["suffix"].ToString();
        string gender = Request.Params["gender"].ToString();
        DateTime dob = DateTime.Parse(Request.Params["dob"].ToString());
        string address = Request.Params["address"].ToString();
        string email = Request.Params["email"].ToString();
        string tel = Request.Params["tel"].ToString();
        TextBox1.Text = "Hello " + suffix + "." + name;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
    //  Response.Write("Name" + TextBox1.Text);
        string name = Request.Params["name"].ToString();
        string suffix = Request.Params["suffix"].ToString();
        string gender = Request.Params["gender"].ToString();
        DateTime dob = DateTime.Parse(Request.Params["dob"].ToString());
        string address = Request.Params["address"].ToString();
        string email = Request.Params["email"].ToString();
        string tel = Request.Params["tel"].ToString();
        TextBox1.Text = "Hello " + suffix + "." + name;
        
        SqlConnection con = new SqlConnection();
        con.ConnectionString=@"data source=PC399003\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=sales_proj";
        con.Open();
        SqlCommand insertItem = new SqlCommand();       
         insertItem.CommandText= ("Insert into employee(name,suffix,gender,dob,address,email,tel)" +
             "values('" + name + "','" + suffix + "','" + gender + "','" + dob + "','" + address + "','" + email + "','" + tel + "')");
         insertItem.Connection = con;
         insertItem.ExecuteNonQuery();
        con.Close();
  
    }
}