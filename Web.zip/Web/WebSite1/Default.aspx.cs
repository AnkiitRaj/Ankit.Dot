﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    int x;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            x = 0;
            ViewState["counter"] = 0;
        }
        else
        {
            if (ViewState["counter"] != null)
            {
                x = (int)ViewState["counter"];
                x++;
                ViewState["counter"] = x;
            }
        }
        TextBox1.Text = x.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //ListBox1.Items.Add("3");
        //ListBox1.Items.Add("4");
        //ListBox1.Items.Add("5");
    }
}