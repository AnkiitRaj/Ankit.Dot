﻿var EmployeeList = new Array();
var count = 0;
function Employee()
{
    var id;
    var name;
    var suffix
    var dob;
    var gender;
    var address;
    var email;
    var tel;
}

function CallMe() {
    alert("Hello"+document.getElementById("name").value);
}
function checkSuffix() {
    if (document.getElementById("suffix").value == "Mr")
        document.getElementById("male").checked = true;
    else
        document.getElementById("female").checked = true;
}
function AddEmployee()
{
    var emp = new Employee();
    emp.name=document.getElementById("name").value;
    emp.suffix=document.getElementById("suffix").value;
    emp.dob = document.getElementById("dob").value;
    if (document.getElementById("male").checked)
        emp.gender = document.getElementById("male").value;
    else
        emp.gender = document.getElementById("female").value;
    emp.address=document.getElementById("address").value;
    emp.email=document.getElementById("email").value;
    emp.tel = document.getElementById("tel").value;
    EmployeeList[count] = emp;
    count++;
    PopulateData(EmployeeList);
}

function PopulateData(mydata) {
    document.getElementById("mydata").innerHTML = "";
    var str = "";
    str += "<table border='1' cellpadding='2' border-collapse=collapse"; 
    str += "<table>";
    for(i=0; i<mydata.length;i++)
    {
        str += "<tr>";
        str += "<td>" + mydata[i].suffix + "</td>";
        str += "<td>" + mydata[i].name + "</td>";
        str += "<td>" + mydata[i].dob + "</td>";
        str += "<td>" + mydata[i].gender + "</td>";
        str += "<td>" + mydata[i].address + "</td>";
        str += "<td>" + mydata[i].email + "</td>";
        str += "<td>" + mydata[i].tel + "</td>";
        str += "</tr>";   
    }
    str += "</table>";
    document.getElementById("mydata").innerHTML += str;
}