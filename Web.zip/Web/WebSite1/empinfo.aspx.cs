﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class empinfo : System.Web.UI.Page
{
    List<Employee> empList;
    DataSet ds = new DataSet();
    SqlDataAdapter employeeAdapter = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            empList = new List<Employee>();
            ViewState["myList"] = empList;
        }
        else 
        {
            if (ViewState["myList"] != null)
            {
                empList = (List<Employee>)ViewState["myList"];
            }
        }
        SqlConnection con = new SqlConnection(@"data source=PC399003\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=sales_proj");
        SqlDataAdapter employeeAdapter = new SqlDataAdapter("select * from employee", con);
        DataSet ds = new DataSet();
        employeeAdapter.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void ddsuffix_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddsuffix.SelectedValue == "Mr")
        {
            rdmale.Checked = true;
            rdfemale.Checked = false;
        }
        else
        {
            rdmale.Checked = false;
            rdfemale.Checked = true;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
          ds = (DataSet)ViewState["dataset"];
        employeeAdapter.Update(ds);
        ds = new DataSet();
        employeeAdapter.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        Response.Write("Updated");
    }
    protected void txtSubmit_Click(object sender, EventArgs e)
    {
        string g = "";
        if (rdfemale.Checked)
            g = rdfemale.Text;
        else
            g = rdmale.Text;
        Employee myemp = new Employee(textname.Text, g, textaddress.Text,
            DateTime.Parse(txtbirthday.SelectedDate.ToString()), textemail.Text, txtphone.Text);
        empList.Add(myemp);
        ViewState["myList"] = empList;
        //Response.Write(empList.Count);
        foreach (Employee emp in empList)
        {
            DataRow dr = ds.Tables[0].NewRow();
            dr["name"] = emp.name;
            dr["suffix"] = emp.suffix;
            dr["gender"] = emp.gender;
            dr["dob"] = emp.dob;
            dr["address"] = emp.address;
            dr["email"] = emp.email;
            dr["tel"] = emp.phone;
            ds.Tables[0].Rows.Add(dr);
        }
        ViewState["dataset"] = ds;
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}