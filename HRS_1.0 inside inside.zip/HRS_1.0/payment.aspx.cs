﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessObject;
using HotelBusinessLayer;
using HotelDataLayer;
using System.Collections;
using iTextSharp.text;
using iTextSharp.text.html;
using System.Configuration;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

public partial class payment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Pay_btn(object sender, EventArgs e)
    {
        if (Session["id"] != null && Session["BookingDetails"]!=null)
        {
            string card_number = Request.Params["CardNumber"].ToString();
            string name_on_card = Request.Params["NameOnCard"].ToString();
            string userId = (string)Session["id"];
            string expmonth = Request.Params["expmonth"].ToString();
            string expyear = Request.Params["expyear"].ToString();
            string cvv = Request.Params["cvv"].ToString();
           
            ArrayList al = (ArrayList)Session["SearchHotel"];
            string checkin = al[0].ToString();
            string checkout = al[1].ToString();
            string nop = al[2].ToString();
            string rtype = al[3].ToString();
            string chin = Convert.ToDateTime(checkin).ToString("dd-MM-yyyy");
            string chout = Convert.ToDateTime(checkout).ToString("dd-MM-yyyy");
            DateTime cin = DateTime.ParseExact(chin, "dd-MM-yyyy", null);
            DateTime cout = DateTime.ParseExact(chout, "dd-MM-yyyy", null);
            string  today = DateTime.Now.ToString("dd-MM-yyyy");
            DateTime bdate = DateTime.ParseExact(today, "dd-MM-yyyy", null);           
            int bstatus = 1;
            ArrayList Als = (ArrayList)Session["HotelSession"];

            string hid = Als[1].ToString();
            int HID = int.Parse(hid);
            string cid = Als[0].ToString();
            int CID = int.Parse(cid);
            string rid = Als[2].ToString();
            int RID = int.Parse(rid);
            string rbookingprice = Als[3].ToString();
            double brprice = double.Parse(rbookingprice);
            string userID = Session["id"].ToString();

            HotelBusinessLayer.PaymentBL pbl1 = new HotelBusinessLayer.PaymentBL();
            DataTable dt = pbl1.PaymentCurrentBalnce(userID);
            int pid = int.Parse(dt.Rows[0][0].ToString());
            double current_bal = double.Parse(dt.Rows[0][1].ToString());

             HotelBusinessLayer.PaymentBL pbl = new HotelBusinessLayer.PaymentBL();

             int result = pbl.PaymentEntry(bdate, cin, cout, brprice, bstatus, HID, RID, userID, CID, card_number, name_on_card,current_bal,pid);
            


            if (result > 0)
            {
                Response.Write("<script>alert('Payment SucessFull')</script>");
                Response.Redirect("../HRS_1.0/projectuser/index.html");
              
            }
            else
            {
                Response.Write("<script>alert('Payment UnSucessFull')</script>");
                Response.Redirect("../HRS_1.0/projectuser/index.html");
            }
          
        }
    }

    
}