﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Redirectfront_page : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["id"] != null)
            Label1.Text = Session["id"].ToString();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();       
        Response.Redirect("../HRS_1.0/front_page.aspx");
        
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string checkin = Request.Params["checkin"].ToString();
        string checkout = Request.Params["checkout"].ToString();
        string nop = Request.Params["nop"].ToString();
        string rtype = Request.Params["rtype"].ToString();
        string chin = Convert.ToDateTime(checkin).ToString("dd-MM-yyyy");
        string chout = Convert.ToDateTime(checkout).ToString("dd-MM-yyyy");
        DateTime cin = DateTime.ParseExact(chin, "dd-MM-yyyy", null);
        DateTime cout = DateTime.ParseExact(chout, "dd-MM-yyyy", null);

        ArrayList al = new ArrayList();
        ArrayList bookingDetails = new ArrayList();

        al.Add(cin);
        al.Add(cout);
        al.Add(nop);
        al.Add(rtype);
        bookingDetails.Add(Session["id"]);
        bookingDetails.Add(cin);
        bookingDetails.Add(cout);
        bookingDetails.Add(nop);
        Session["SearchHotel"] = al;
        Session["BookingDetails"] = bookingDetails;
        Response.Redirect("../HRS_1.0/reserve2.aspx?=" + Session["SearchHotel"] + Session["BookingDetails"]);
    }
}