﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessObject;
using HotelBusinessLayer;
using HotelDataLayer;
using System.Collections;


public partial class personalDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string s = hid.Value;
        //int bookingHid = int.Parse(s);
       // ArrayList al = (ArrayList)Session["BookingDetails"];
        //al.Add(bookingHid);
        //Session["BookingDetails"] = al;
    }
    public void refress()
    {
        name.Text = "";
        age.Text = "";
        gender.Text = "";
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        String pageUrl = "";
        pageUrl = Request.Url.ToString();
        string[] array = pageUrl.Split('=');
        string[] arr = array[1].Split('&');
        //string s = Request.Form["hid"].ToString();
        int bookingHid = int.Parse(arr[0]);
        double BookingRprice = double.Parse(arr[1]);
        ArrayList al = (ArrayList)Session["BookingDetails"];
       
        if (Session["id"] != null)
        {
            string Name = name.Text;
            string Age = age.Text;
            string Gender = gender.Text;
            string userId = (string)Session["id"];
            HotelBusinessObject.personalDetails HO = new HotelBusinessObject.personalDetails(Name, Age, Gender, userId);
            HotelBusinessLayer.personalDetailsBL Hpl = new HotelBusinessLayer.personalDetailsBL();
            int res = Hpl.personalDetailsEntry(HO);

            
            if (res > 0)
            {
                HotelBusinessLayer.personalDetailsBL pbl = new personalDetailsBL();
                DataTable dt = pbl.PersonalDetails(userId);
                string cid = dt.Rows[0][0].ToString();

                HotelBusinessLayer.personalDetailsBL pbl1 = new personalDetailsBL();
                DataTable dt1 = pbl1.HotelDetails(bookingHid);
                string rid = dt1.Rows[0][0].ToString();

                al.Add(cid);
                al.Add(bookingHid);
                al.Add(rid);
                al.Add(BookingRprice);
                Session["BookingDetails"] = al;
                
                ArrayList Ho = new ArrayList();
                
                Ho.Add(cid);
                Ho.Add(bookingHid);
                Ho.Add(rid);
                Ho.Add(BookingRprice);
                Session["HotelSession"] = Ho;

                
                
                Response.Redirect("../HRS_1.0/payment.aspx?="+al+Ho);
            }
            else
            {
                Response.Redirect("../HRS_1.0/personalDetails.aspx");
            }
            
        }
    }
            protected void Button1_Click(object sender, EventArgs e)
            {
                refress();
                Literal1.Text = "";
            }
        }







