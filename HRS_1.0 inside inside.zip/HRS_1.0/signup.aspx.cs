﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessLayer;
using HotelBusinessObject;
using HotelDataLayer;

public partial class signup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string fname = Request.Params["fname"].ToString();
        string lname = Request.Params["lname"].ToString();
        string phoneNumber = Request.Params["phoneNumber"].ToString();
        string userID = Request.Params["userID"].ToString();
        string psw = Request.Params["psw"].ToString();
        string psw_repeat = Request.Params["psw-repeat"].ToString();
        if (psw.Equals(psw_repeat))
        {
            HotelBusinessObject.SignUp s = new HotelBusinessObject.SignUp(fname, lname, phoneNumber, userID, psw);
            HotelBusinessLayer.SignUpBL Hbl = new HotelBusinessLayer.SignUpBL();
            Random random = new Random();
            long Card_Number = 0;
            string cardNumber;
            for (int i = 0; i < 16; i++)
            {
                Card_Number += (long)(Math.Pow(10, i) * random.Next(1, 10));
            }
            cardNumber = Card_Number.ToString();
            int res = Hbl.SignUpUser(s, cardNumber);
            if (res > 0)
            {
                Response.Write("<script>alert('Register SucessFully')</script><script>alert('Your Card Number is:"+cardNumber+"')</script><script>window.location.href ='../HRS_1.0/signin.aspx'</script>");
            }
            else
            {
                Label1.Text = "User Already Exists";
                Label1.ForeColor = System.Drawing.Color.Red;
            }

        }
        else 
        {
            Response.Write("<script></script><script>alert('PassWord Mismatch')window.location.href ='../HRS_1.0/signup.aspx'</script>");
        }
            
    }
}
