﻿function isNumber(evt) {

    var iKeyCode = (evt.which) ? evt.which : evt.keyCode

    if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))

        return false;
    return true;

}

var i = 1;
function addNewRow() {

    if ($('#name').val() != "" && $('age').val() != "" && $('#gender').val() != "") {
        $("#new_row").show();
        $('#DetailTable').append('<tr><td style="color:black;font-weight:bolder;font-size:20px;">Name</td><td><input  name="Name" id="student' + i + 'name" value="' + $('#name').val() + '" style="width:180px;background-color:floralwhite;color:black;font-size:15px;font-weight:bold;border-radius:30px; text-align:center;border:1px solid black;" ></td><td style="color:black;font-weight:bolder;font-size:20px;">Age</td><td><input name="Age" id="student' + i + 'age" value="' + $('#age').val() + '" style="width:180px;background-color:floralwhite;color:black;font-size:15px;font-weight:bold;border-radius:30px; border:1px solid black;text-align:center;" ></td><td style="color:black;font-weight:bolder;font-size:20px;">Gender</td><td><input name="Gender" id="student' + i + 'gender" value="' + $('#gender').val() + '" style="width:180px;background-color:floralwhite;color:black;font-size:15px;font-weight:bold;border-radius:30px; border:1px solid black;text-align:center;"></td><td><input type="button" style="background-color:#d63535;border-radius:30px;border:2px solid black;padding:15px;width:110px;color:black;font-weight:bolder;"value="Delete" onclick="deleteRow(this)"/></td></tr>');
        i++;
        $('#name').val(''); //Empty Feilds
        $('#age').val('');
        $('#gender').val('');


    }
    else {
        alert("PLEASE MAKE YOUR ENTRY FIRST");
        $("#new_row").hide();
    }
}

function deleteRow(bt) {
    var row = bt.parentNode.parentNode;
    row.parentNode.removeChild(row);
}