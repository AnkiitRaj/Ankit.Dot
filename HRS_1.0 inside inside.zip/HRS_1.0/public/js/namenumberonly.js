﻿function isNumber(evt) {

    var iKeyCode = (evt.which) ? evt.which : evt.keyCode

    if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))

        return false;



    return true;

}






function a(event) {

    var char = event.which;

    if (char > 31 && char != 32 && (char < 65 || char > 96) && (char < 97 || char > 122))

        return false;

}