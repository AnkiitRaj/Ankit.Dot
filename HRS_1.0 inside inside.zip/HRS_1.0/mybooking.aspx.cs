﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Collections;
using HotelBusinessLayer;
using HotelDataLayer;

public partial class mybooking : System.Web.UI.Page
{
    DataTable bookingDetails = null;
    DataTable hotelDetails = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["id"] != null)
            Label1.Text = Session["id"].ToString();


        if (Session["id"] != null)
        {
            Response.Write("<div class='navbar'>" +
                "<input type='hidden' id='hid' name='hid' runat='server' />" +
                 "<b><a class='active' href='Redirectfront_page.aspx'><i class='fa fa-fw fa-home'></i> Home</a></b>" +
                    "</div></div>");
        }
        else
        {
            Response.Write("<div class='navbar'>" +
                               "<input type='hidden' id='hid' name='hid' runat='server' />" +
                                "<b><a class='active' href='front_page.aspx'><i class='fa fa-fw fa-home'></i> Home</a></b>" +
                                   "<div style='float:right;'>" + "<a href='signin.aspx'><i class='fa fa-fw fa-user'></i> Sign In</a>" + "</div>" +
                                   "<a href='signup.aspx'><i class='fa fa-fw fa-user'></i> Sign Up</a>" + "</div></div>");
        }

        if (Session["id"] != null)
        {

            HotelBusinessLayer.MyBookingBL mbl = new HotelBusinessLayer.MyBookingBL();
            bookingDetails = mbl.UserBookingDetails(Session["id"].ToString()); // bid, hid, rid, btotalprice, pid
            int hid = int.Parse(bookingDetails.Rows[0][1].ToString());
            hotelDetails = mbl.SelectHotelBookingDetails(hid, Session["id"].ToString()); //hname,rating

                string hotelName = hotelDetails.Rows[0][0].ToString();
                int rating = Convert.ToInt32(hotelDetails.Rows[0][1].ToString());                
                double price = Math.Round(double.Parse(bookingDetails.Rows[0][3].ToString()),2);
                int bid = Convert.ToInt32(bookingDetails.Rows[0][0].ToString());
                Response.Write("<div class='card'><img src='../HRS_1.0/public/images/" + hid + ".jpg' alt='Image'>" +
                                    "<div  class='content'><p class='heading'>" + hotelName + "</p>");
                for (int j = 0; j < 5; j++)
                {
                    if (j < rating)
                        Response.Write("<span class='fa fa-star' style='color:#FEB201' checked></span>");
                    else
                        Response.Write("<span class='fa fa-star'></span>");
                }

                Response.Write("<p><i style='font-size:24px;color: blue;' class='fas'>&#xf09e;</i> Free-WIFI </p >" +
                                   "<p ><i style='font-size:24px' class='fas'>&#xf118;</i> No cancelation Fees</p >" +
                                   "<p ><i style='font-size:24px;color:green;' class='fas'>&#xf00c;</i> Booking Confirmed</p>" +
                                    "</div>" +
                                   "<div float='right'>" + "<div >" + "<p class='price' > <b> Refunded amount will be  </br> Rs. " + price + "</b></p>" +
                                   "</div></div></div>");
                

        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("../HRS_1.0/front_page.aspx");
    }
    protected void CancelBtn_Click(object sender, EventArgs e)
    {
        HotelBusinessLayer.MyBookingBL cbk = new HotelBusinessLayer.MyBookingBL();
        DataTable cardDetail = cbk.SelectCardDetails(Session["id"].ToString());
        double current_bal = Math.Round(double.Parse(cardDetail.Rows[0][1].ToString()), 2);

        int hid = int.Parse(bookingDetails.Rows[0][1].ToString());
        int bid = Convert.ToInt32(bookingDetails.Rows[0][0].ToString());
        int rid = Convert.ToInt32(bookingDetails.Rows[0][2].ToString());
        double amountCredited = Math.Round(double.Parse(bookingDetails.Rows[0][3].ToString()), 2);
        string userId = Session["id"].ToString();
        double current_balance = current_bal + amountCredited;
        Random random = new Random();
        long tran = 0;
        for (int i = 0; i < 16; i++)
        {
            tran += (long)(Math.Pow(10, i) * random.Next(1, 10));
        }
        string transactionID = tran.ToString();

        int pid = int.Parse(bookingDetails.Rows[0][4].ToString());
        string card_number = cardDetail.Rows[0][0].ToString();
        double AmountDebit = 0;
        
        bool res = cbk.UpdateAfterCancellation(hid, rid, bid, amountCredited, userId, current_balance, transactionID, pid, card_number, AmountDebit);
        if (res)
        {
            Response.Write("<script>alert('Cancellation Successfull ! please check your card balance')</script>");
            Response.Redirect("../HRS_1.0/projectuser/index.html");
        }
        else
        {
            Response.Write("<script>alert('Cancellation UNsuccessfull ! please check your card balance')</script>");
            Response.Redirect("../HRS_1.0/mybooking.aspx");
        }
    }
}