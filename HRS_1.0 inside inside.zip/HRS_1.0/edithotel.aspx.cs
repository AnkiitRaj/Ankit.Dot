﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessObject;
using HotelBusinessLayer;
using HotelDataLayer;
using System.Collections;

public partial class edithotel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Edit_Hotel_Click(object sender, EventArgs e)
    {
        int hid = int.Parse(Request.Params["hid"].ToString());
        string hname = Request.Params["hname"].ToString();
        string hrating = Request.Params["hrating"].ToString();
        string rtype = Request.Params["rtype"].ToString();
        double rprice = double.Parse(Request.Params["rprice"].ToString());
        string rcapacity = Request.Params["rcapacity"].ToString();


      
        HotelBusinessLayer.EditHotelBL ehl = new EditHotelBL();
        int res = ehl.EditHotelDetailsEntry(hid, hname, hrating);
        

        if (res > 0)
        {
            int result = ehl.EditHotelRoomDetails(hid, rcapacity, rtype, rprice);
            if (result > 0)
            {
                Response.Write("<script>alert('Updation Sucessfull')</script>");
                Response.Redirect("../HRS_1.0/projectuser/index.html");
            }
            else
            {
                Response.Write("<script>alert('Updation Unsucessfull')</script>");
                Response.Redirect("../HRS_1.0/edithotel.aspx");
            }
        }
        else 
        {
            Response.Write("<script>alert('Updation Unsucessfull')</script>");
            Response.Redirect("../HRS_1.0/edithotel.aspx");
        }
       
    }
}