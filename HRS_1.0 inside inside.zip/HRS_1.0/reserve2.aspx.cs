﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Collections;
using HotelBusinessLayer;
using HotelDataLayer;


public partial class reserve2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["id"] != null)
            Label1.Text = Session["id"].ToString();
        if (Session["id"] != null)
        {
            Response.Write("<div class='navbar'>" +
                "<input type='hidden' id='hid' name='hid' runat='server' />" +
                 "<b><a class='active' href='Redirectfront_page.aspx'><i class='fa fa-fw fa-home'></i> Home</a></b>" +
                    "</div></div>");
        }
        else
        {
            Response.Write("<div class='navbar'>" +
                               "<input type='hidden' id='hid' name='hid' runat='server' />" +
                                "<b><a class='active' href='front_page.aspx'><i class='fa fa-fw fa-home'></i> Home</a></b>" +
                                   "<div style='float:right;'>" + "<a href='signin.aspx'><i class='fa fa-fw fa-user'></i> Sign In</a>" + "</div>" +
                                   "<a href='signup.aspx'><i class='fa fa-fw fa-user'></i> Sign Up</a>" + "</div></div>");
        }
        ArrayList als = (ArrayList)Session["SearchHotel"];
        if (als != null)
        {
            
            string checkin = als[0].ToString();
            string checkout = als[1].ToString();
            string nop = als[2].ToString();
            string rtype = als[3].ToString();
            string chin = Convert.ToDateTime(checkin).ToString("dd-MM-yyyy");
            string chout = Convert.ToDateTime(checkout).ToString("dd-MM-yyyy");
            DateTime cin = DateTime.ParseExact(chin, "dd-MM-yyyy", null);
            DateTime cout = DateTime.ParseExact(chout, "dd-MM-yyyy", null);
            int numberOfDays = (int)((cout - cin).Days);

            HotelBusinessLayer.ReserveBL rbl = new HotelBusinessLayer.ReserveBL();
            DataTable dt = rbl.HotelSearchDetails(cin, cout, nop, rtype);


            ArrayList hlist = new ArrayList();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string str = "";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    str = str + dt.Rows[i][j].ToString()+"&";
                }
                hlist.Add(str);
            }

            
            for(int i=0;i<hlist.Count;i++)
            {
                string[] array = hlist[i].ToString().Split('&');
                string hid = array[0];
                string hotelName = array[1];
                int rating = Convert.ToInt32(array[2]);
                string roomAvailable = array[3];
                string price = (Math.Round(Convert.ToDouble(array[4]), 2) * numberOfDays).ToString();
                Response.Write("<div class='card'><img src='../HRS_1.0/public/images/" + (i + 1) + ".jpg' alt='Image'>" +
                                    "<div  class='content'><p class='heading'>" + hotelName + "</p>");
                for (int j = 0; j < 5; j++)
                {
                    if (j < rating)
                        Response.Write("<span class='fa fa-star' style='color:#FEB201' checked></span>");
                    else
                        Response.Write("<span class='fa fa-star'></span>");
                }
                                   
                 Response.Write("<p><i style='font-size:24px;color: blue;' class='fas'>&#xf09e;</i> Free-WIFI </p >" +
                                    "<p ><i style='font-size:24px' class='fas'>&#xf118;</i> No cancelation Fees</p >" +
                                    "<p><i style='font-size:24px;color: green' class='fas' id='nra'>&#xf560;</i> " + roomAvailable + " Rooms Available</p>" + "</div>" +
                                    "<div float='right'>" + "<div >" + "<p class='price' >For " + numberOfDays + " nights <b>" + price + "</b></p>" +
                                    "<p><input type='hidden' class='hid'  ><button type='button' class='booknowbtn' value =" + hid + "&" + price + " />BookNow</button></p>" +
                                    "</div></div></div>");
            }
          
        }
   }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("../HRS_1.0/projectuser/index.html");

    }
}

            
            

















































       