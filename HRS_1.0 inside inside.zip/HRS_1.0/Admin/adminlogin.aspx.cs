﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessLayer;
using HotelBusinessObject;
using HotelDataLayer;


public partial class Admin_adminlogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LoginBtn_Click(object sender, EventArgs e)
    {
        string aloginId = Request.Params["aloginId"].ToString();
        string aloginPw = Request.Params["aloginPw"].ToString();
        HotelBusinessLayer.adminloginBL alb = new HotelBusinessLayer.adminloginBL();
        bool res = alb.ValidateLogin(aloginId, aloginPw);

        if (res)
        {
            Response.Redirect("AdminAddEditBtn.aspx");
        }
        else
            Response.Redirect("adminlogin.aspx");


    }
}