﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessLayer;
using HotelBusinessObject;
using HotelDataLayer;

public partial class signin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void signin_btn(object sender, EventArgs e)
    {
        try
        {
            string userID = Request.Params["userId"].ToString();
            string pass = Request.Params["psw"].ToString();
            HotelBusinessLayer.signinBL sbl = new HotelBusinessLayer.signinBL();
            bool valid = sbl.ValidateUser(userID, pass);
            if (valid==true)
            {
                Session["id"] = userID;
                Response.Write("<script>window.location.href ='../HRS_1.0/Redirectfront_page.aspx'</script>");
            }
            else
            {
                
               
                Label1.Text = "Invalid Username or Password";
                Label1.ForeColor = System.Drawing.Color.Red;
            }
        }
        catch
        {
            Label1.Text = "Invalid Username or Password";
            Label1.ForeColor = System.Drawing.Color.Red;  
        }
    }
}