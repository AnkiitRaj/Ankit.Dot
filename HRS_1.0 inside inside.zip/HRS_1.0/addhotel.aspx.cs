﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessObject;
using HotelBusinessLayer;
using HotelDataLayer;
using System.Collections;

public partial class addhotel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string hname = Request.Params["hname"].ToString();
        string hlocation = Request.Params["hlocation"].ToString();
        string hrating = Request.Params["hrating"].ToString();
        string rtype = Request.Params["rtype"].ToString();
        double rprice = double.Parse(Request.Params["rprice"].ToString());
        string rcapacity = Request.Params["rcapacity"].ToString();

        HotelBusinessObject.AddHotelBO ahb = new AddHotelBO(hname,hlocation,hrating,rtype,rprice,rcapacity);
        HotelBusinessLayer.AddHotelBL abl = new AddHotelBL();
        int res = abl.AddHotelDetailsEntry(ahb);
        if (res > 0) 
        {

            int result = abl.HotelRoomDetails(ahb);
            if (result > 0)
            {
                Response.Redirect("../HRS_1.0/projectuser/index.html");
            }
        }
        

    }
}