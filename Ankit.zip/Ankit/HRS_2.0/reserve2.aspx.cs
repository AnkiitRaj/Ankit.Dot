﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Collections;

public partial class reserve2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["id"] != null)
        {
            SqlConnection con = new SqlConnection(@"data source=PC399122\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=HRS");
            SqlCommand com = new SqlCommand();

            com.Connection = con;
            string checkin = Request.Params["checkin"].ToString();
            string checkout = Request.Params["checkout"].ToString();
            string nop = Request.Params["nop"].ToString();
            string rtype = Request.Params["rtype"].ToString();
            string chin = Convert.ToDateTime(checkin).ToString("dd-MM-yyyy");
            string chout = Convert.ToDateTime(checkout).ToString("dd-MM-yyyy");
            DateTime cin = DateTime.ParseExact(chin, "dd-MM-yyyy", null);
            DateTime cout = DateTime.ParseExact(chout, "dd-MM-yyyy", null);

            com.CommandText = "select h.hid,h.hname,h.hrating, count(r.rid) as NoOfRoomsAvailable, r.rprice from RoomMaster r join HotelMaster h on r.hid = h.hid join BookingMaster b on h.hid=b.hid where (r.ravailable =1) and (b.bcheckin not between @cin and @cout) and (r.rtype=@rtype) group by h.hid,h.hname,r.rprice,h.hrating order by h.hid,h.hname,h.hrating;";
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@cin", SqlDbType.Date);
            param[1] = new SqlParameter("@cout", SqlDbType.Date);
            param[2] = new SqlParameter("@nop", SqlDbType.VarChar);
            param[3] = new SqlParameter("@rtype", SqlDbType.VarChar);
            param[0].Value = cin;
            param[1].Value = cout;
            param[2].Value = nop;
            param[3].Value = rtype;
            com.Parameters.AddRange(param);
            //com.CommandText = "select h.hid from HotelMaster h;";
            con.Open();
            SqlDataAdapter sdt = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            sdt.Fill(dt);
            con.Close();
            int numberOfDays = (int)((cout - cin).Days);

            ArrayList al = new ArrayList();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string s = "";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    s += dt.Rows[i][j] + "&";

                }

                al.Add(s);
            }



            //Response.Write("  <div class='navbar'>" +
            //               "<input type='hidden' id='hid' name='hid' runat='server' />" +
            //               "<b><a class='active' href='front_page.aspx'>Home <i style='font-size:24px' class='fas'>&#xf015;</i></a></b>" +
            //               "<div>" +
            //                   "<a  class='login' href='signup.aspx' onclick='document.getElementById('id02').style.display='block'' >Sign Up</a>" +
            //               "</div>" +
            //              "<div>" +
            //                  "<a class='login' href='signin.aspx' onclick='document.getElementById('id01').style.display='block'' >Sign In</a>" +
            //              "</div></div>" +
            //               "<div class='bookpage'>" + "<b><a class='active'>Search Results... </a></b><div >" +
            //                "<a  class='search' href='front_page.aspx'><i style='font-size:24px' class='fas'> &#xf002;</i> Modify Search</a>" +
            //               "</div></div>");
            Response.Write("<div class='navbar'>" +
                "<input type='hidden' id='hid' name='hid' runat='server' />" +
                 "<b><a class='active' href='projectuser/index.html'><i class='fa fa-fw fa-home'></i> Home</a></b>" +
                    "<div style='float:right;'>" + "<a href='signup.aspx'><i class='fa fa-fw fa-user'></i> Signup</a>" + "</div>" + "<div style='float:right;'>" +
          "<a href='signin.aspx'><i class='fa fa-fw fa-user'></i> Signin</a>" + "</div></div>");
            for (int i = 0; i < al.Count; i++)
            {
                string[] array = al[i].ToString().Split('&');
                string hotelName = array[1];
                int rating = Convert.ToInt32(array[2]);
                string roomAvailable = array[3];
                string price = (Math.Round(Convert.ToDouble(array[4]), 2) * numberOfDays).ToString();
                string nextPage = "personalDetails.aspx";

                Response.Write("<div class='card' id='divContainer' runat='server'><img src='http://localhost:65042/HRS_2.0/public/images/" + (i + 1) + ".jpg' alt='Image'>"
                    + "<div  class='content'><p class='heading' id='hname'>" + hotelName + "</p>");
                for (int j = 0; j < 5; j++)
                {
                    if (j < rating)
                        Response.Write("<span class='fa fa-star' style='color:#FEB201' checked></span>");
                    else
                        Response.Write("<span class='fa fa-star'></span>");
                }
                Response.Write("<p><i style='font-size:24px;color: blue;' class='fas'>&#xf09e;</i> Free-WIFI </p >" +
                "<p ><i style='font-size:24px' class='fas'>&#xf118;</i> No cancelation Fees</p >" +
                "<p><i style='font-size:24px;color: green' class='fas' id='nra'>&#xf560;</i> " + roomAvailable + " Rooms Available</p>" + "</div>" +
                "<div float='right'>" + "<div ><p class='price' >For " + numberOfDays + " nights <b>Rs." + price + "</b></p>" +
                "<p><a href='" + nextPage + "'><input type='button' class='booknowbtn' value='Book Now'/></a></p></div></div></div>");
            }

        }
    }
}