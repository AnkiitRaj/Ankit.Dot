﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class personalDetails : System.Web.UI.Page
{
    
    SqlConnection con = new SqlConnection(@"data source=PC399122\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=HRS");
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    public void refress()
    {
        name.Text = "";
        age.Text = "";
        gender.Text = "";
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["id"] != null)
        {
            string userId = (string)Session["id"];
            int cval = 10;
            string cid = cval.ToString();
            cval++;
            SqlCommand cmd = new SqlCommand("insert into CustomerMaster(cid,cname,cage,cgender,userId) values('" + cid + "','" + name.Text + "','" + age.Text + "','" + gender.Text + "','" + userId + "')", con);
            cmd.CommandType = CommandType.Text;
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                Literal1.Text = "Data inserted successfully";
                Response.Redirect("http://localhost:65042/HRS_2.0/payment.html");
                con.Close();
                refress();
            }
            catch (Exception ex)
            {
                Literal1.Text = ex.Message;
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        refress();
        Literal1.Text = "";
    }
}


     

