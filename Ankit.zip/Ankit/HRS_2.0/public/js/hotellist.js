﻿$(document).ready(function () {

    //number of rooms
    var rooms = [];
    var roomsEmpty = [];
    var roomsBooked = [];

    //new room constructor
    function Room(beds, status, price, name) {
        this.name = name;
        this.beds = beds;
        this.status = status;
        this.price = price;
    }

    //create the rooms
    rooms.push(new Room(2, "available", 200));
    rooms.push(new Room(2, "available", 400));
    rooms.push(new Room(1, "available", 100));
    rooms.push(new Room(1, "booked", 150, "Josh"));
    rooms.push(new Room(1, "available", 150));
    rooms.push(new Room(3, "booked", 850, "Britny"));
    rooms.push(new Room(1, "available", 100));
    rooms.push(new Room(2, "available", 550));
    rooms.push(new Room(2, "available", 400));
    rooms.push(new Room(3, "available", 750));
    //10 total rooms
    var roomLength = rooms.length;


    //SETTING UP INITIAL DOM *********

    //add available rooms to DOM
    function showRooms() {
        $('#rooms').html("");
        $('#takenRooms').html("");
        var x;
        for (x = 0; x < roomLength; x++) {
            //if the room is available
            if (rooms[x].status == "available") {
                //create element
                var e = $('<div class="room col-xs-12 col-md-6 col-md-4"> <p> <img class="img-thumbnail" src="https://palacestation.sclv.com/~/media/Images/Page%20Background%20Images/Palace/Hotel/PS_Hotel_KingRoom_new.jpg"> </p> <p> Beds: ' + rooms[x].beds + '</p> <p> $' + rooms[x].price + '</p> <button class="btn btn-primary book">Book</button> </div>');
                //add the id
                e.attr('id', x)
                //append to DOM
                $('#rooms').append(e);
            } else {
                //create element
                var a = $('<div class="room col-xs-12 col-md-6 col-md-4"> <p> <img class="img-thumbnail" src="https://prahandhuschwedding.files.wordpress.com/2015/03/hotelroom.jpg"> </p> <p> Renter: ' + rooms[x].name + '<p> Beds: ' + rooms[x].beds + '</p> <p> $' + rooms[x].price + '</p> <button class="btn btn-primary cancel">Cancel</button> </div>');
                //add the id
                a.attr('id', x)
                //append to DOM
                $('#takenRooms').append(a);
                roomsBooked.push(rooms[x]);
            }
        }
    }
    showRooms();




    //BOOK A ROOM *********

    //When a book button is clicked
    $('#rooms').on('click', '.book', function () {
        var roomNum = $(this).closest(".room").attr('id');
        $('.overlay').fadeIn();
        $('#roomNum').text(roomNum);
        return roomNum;
    });

    //when the overlay submit button is clicked
    $('.overlay').on('click', '.submit', function () {
        var roomNum = $('#roomNum').text();
        var name = $('#renter').val();
        rooms[roomNum].status = "booked";
        rooms[roomNum].name = name;
        $('.overlay').fadeOut("slow");
        showRooms();
        var alert = '<div class="alert bg-success"> <p>OK ' + name + ', you\'re room was booked!</p></div>';
        $('.container').append(alert).fadeIn("slow");
        setTimeout(function () {
            $('.alert').fadeOut("slow");
            $('#renter').val("");
            $('#roomNum').text("");
        }, 2000);
    });


    //CANCEL A ROOM ******

    //when cancel button is clicked
    $('.bookedRooms').on('click', '.cancel', function () {
        //get index of this room in ROOMS array
        var roomNum = $(this).closest(".room").attr('id');
        //remove this room from BOOKED array
        roomsBooked.splice(roomNum, 1);
        //change status of this room
        rooms[roomNum].status = "available";
        //add it to EMPTY array
        roomsEmpty.push(rooms[roomNum]);
        //update DOM
        showRooms();
    });


    //UI INTERACTION ******

    //show booked rooms when button is clicked
    $('.showBookings button').click(function () {
        $('.bookedRooms').fadeToggle("slow");
        var buttonText = $(".showBookings button").html();
        if (buttonText == 'Booked Rooms') {
            $(".showBookings button").html('Hide');
        } else {
            $(".showBookings button").html('Show Booked Rooms');
        }
    });

});