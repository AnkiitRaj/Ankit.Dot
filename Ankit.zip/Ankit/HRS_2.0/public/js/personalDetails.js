﻿function isNumber(evt) {

    var iKeyCode = (evt.which) ? evt.which : evt.keyCode

    if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))

        return false;
    return true;

}

var i = 1;
function addNewRow() {

    if ($('#name').val() != "" && $('age').val() != "" && $('#gender').val() != "") {
        $("#new_row").show();
        $('#DetailTable').append('<tr><td>Name</td><td><input name="Name" id="student' + i + 'name" value="' + $('#name').val() + '" style="width:180px" ></td><td>Age</td><td><input name="Age" id="student' + i + 'age" value="' + $('#age').val() + '" style="width:180px" ></td><td>Gender</td><td><input name="Gender" id="student' + i + 'gender" value="' + $('#gender :selected').text() + '" style="width:180px"></td><td><input type="button" value="Delete" onclick="deleteRow(this)"/></td></tr>');
        i++;
        $('#name').val(''); //Empty Feilds
        $('#age').val('');
        $('#gender').val('');


    }
    else {
        alert("PLEASE MAKE YOUR ENTRY FIRST");
        $("#new_row").hide();
    }
}

function deleteRow(bt) {
    var row = bt.parentNode.parentNode;
    row.parentNode.removeChild(row);
}