﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
namespace HotelReservation.UserView
{
    public partial class UserRoomSelectionPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UName"] == null)
            {
                Response.Redirect("../Views/Login.aspx");
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm3", "$('#loginbtn').hide();", true);

            }
            if (!IsPostBack)
            {
                DropDownList1.Enabled = false;
                int HotelId = int.Parse(Session["HotelId"].ToString());
                string HotelName = Session["HotelName"].ToString();
                string CheckIn = Session["CheckIn"].ToString();
                string CheckOut = Session["CheckOut"].ToString();
                int NoofGuests = int.Parse(Session["NoofGuests"].ToString());
                int NoofRooms = int.Parse(Session["NoofRooms"].ToString());
                string RoomTypeName = Session["RoomTypeName"].ToString();
                string Description1 = Session["Description1"].ToString();
                string Description2 = Session["Description2"].ToString();
                double Price = double.Parse(Session["Price"].ToString());
                string Location = Session["Location"].ToString();
                int RoomID = int.Parse(Session["RoomId"].ToString());
                double CGSTCost = (Price * 9) / 100;
                double SGSTCost = (Price * 9) / 100;
                double Cost = Price - (CGSTCost + SGSTCost);
                lblHotelName.Text = HotelName;
                lblLocation.Text = Location;
                DateTime CIn = DateTime.Parse(CheckIn);
                DateTime COut = DateTime.Parse(CheckOut);
                TimeSpan datediff = COut - CIn;
                lblDays.Text = datediff.Days.ToString();
                lblCheckIn.Text = CIn.ToString("dddd, dd MMMM yyyy");
                lblCheckOut.Text = COut.ToString("dddd, dd MMMM yyyy");
                lblRoomType.Text = RoomTypeName;
                lblGuests.Text = NoofGuests.ToString();
                lblDes1.Text = Description1;
                lblDes2.Text = Description2;
                lblRef.Text = Description1;
                lblBasePrice.Text = Cost.ToString();
                lblCGST.Text = CGSTCost.ToString();
                lblSGST.Text = SGSTCost.ToString();
                Session["FinalPriceCp"] = Price.ToString();
                lblTotalPrice.Text = Price.ToString();
                Session["AmountPayable"] = lblTotalPrice.Text;
                lblCoupon.Text = "0";
                if (Session["Gender"].ToString() == "Male")
                    DropDownList1.SelectedValue = "0";
                else
                    DropDownList1.SelectedValue = "1";
                txtName.Text = Session["Fullname"].ToString();
                txtEmail.Text = Session["EmailID"].ToString();
            }
        }
        protected void btnPay_Click(object sender, EventArgs e)
        {
            if (CheckBox1.Checked)
            {
                //Condition to check if the file uploaded or not   
                if (fuNationalID.HasFile)
                {
                    //getting length of uploaded file  
                    int length = fuNationalID.PostedFile.ContentLength;
                    //create a byte array to store the binary image data  
                    byte[] imgbyte = new byte[length];
                    //store the currently selected file in memeory  
                    HttpPostedFile img = fuNationalID.PostedFile;
                    //set the binary data  
                    img.InputStream.Read(imgbyte, 0, length);
                    Session["NationalID"] = imgbyte;
                    Response.Redirect("Payment.aspx");
                }
            }
            else
            {
                lblCheckBox.Text = "Please Accept Hotel Policy and Terms & Conditions.";
            }
            
        }

        protected void btnCoupon_Click(object sender, EventArgs e)
        {
            double Price = double.Parse(Session["FinalPriceCp"].ToString());
            DiscountBal cb = new DiscountBal();
            int Percent = cb.GetDiscount(txtCoupon.Value);
            double CouponPrice = (Price * Percent) / 100;
            lblCoupon.Text = CouponPrice.ToString();
            double FinalAmount = Price - CouponPrice;
            lblTotalPrice.Text = FinalAmount.ToString();
            Session["AmountPayable"] = lblTotalPrice.Text;
        }
    }
}