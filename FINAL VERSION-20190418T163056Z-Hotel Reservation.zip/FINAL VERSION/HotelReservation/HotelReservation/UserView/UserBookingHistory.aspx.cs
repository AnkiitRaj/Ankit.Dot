﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
using System.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

namespace HotelReservation.UserView
{
    public partial class UserBookingHistory : System.Web.UI.Page
    {
        int uid = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
           
           
            if (Session["UName"] == null)
            {
                Response.Redirect("../Views/Login.aspx");
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm3", "$('#loginbtn').hide();", true);
                uid = Convert.ToInt32(Session["UId"]);
            }
            if (!IsPostBack)
            {
                PopulateData(1, 5,uid);
            }
            AddpaggingButton();

        }
        //protected void logout_Click(object sender, EventArgs e)
        //{
        //    Session.Abandon();
        //    Response.Redirect("../Views/Login.aspx");
        //}
        private void PopulateData(int pageNo, int noOfRecord,int uid)
        {


            GridView1.DataSource = UserBookingBal.PopulateData(pageNo, noOfRecord,uid);
            GridView1.DataBind();
            ViewState["TotalRecord"] = UserBookingBal.getTotalRecord1();
            ViewState["NoOfRecord"] = UserBookingBal.getNoOfRecord1();

        }

        private void AddpaggingButton()
        {
            int totalRecord = 0;
            int noOfRecord = 0;
            totalRecord = ViewState["TotalRecord"] != null ? (int)ViewState["TotalRecord"] : 0;
            noOfRecord = ViewState["NoOfRecord"] != null ? (int)ViewState["NoOfRecord"] : 0;
            int pages = 0;
            if (totalRecord > 0 && noOfRecord > 0)
            {
                pages = (totalRecord / noOfRecord) + ((totalRecord % noOfRecord) > 0 ? 1 : 0);
                for (int i = 0; i < pages; i++)
                {
                    Button b = new Button();
                    b.Text = (i + 1).ToString();
                    b.CommandArgument = (i + 1).ToString();
                    b.ID = "Button_" + (i + 1).ToString();
                    b.CssClass = "btn btn-outline-warning";

                    b.Click += new EventHandler(this.b_click);
                    Panel1.Controls.Add(b);
                }
            }
        }
        private void b_click(object sender, EventArgs e)
        {
            //this is for get data from database from clicking button
            string pageNo = ((Button)sender).CommandArgument;
            PopulateData(Convert.ToInt32(pageNo), 5,uid);

        }
      
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.Equals("download"))
            {

                int index = Convert.ToInt32(e.CommandArgument);

                Session["BookingID"] =Convert.ToInt32(GridView1.DataKeys[index].Value);

                Session["totalPrice"] = UserBookingBal.getBookingAmt(Convert.ToInt32(Session["BookingID"]));
                Session["UID"] = uid;
                Response.Redirect("../Views/generatePDF.aspx",false);
             
            }

        }
    }
}