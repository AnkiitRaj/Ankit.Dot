﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
using System.Data;
namespace HotelReservation.UserView
{
    public partial class BookHotel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtInDate.Attributes["min"] = DateTime.Now.ToString("yyyy-MM-dd");
            txtInDate.Attributes["max"] = DateTime.Now.AddMonths(3).ToString("yyyy-MM-dd");
            txtOutDate.Attributes["min"] = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd");
            txtOutDate.Attributes["max"] = DateTime.Now.AddMonths(3).AddDays(1).ToString("yyyy-MM-dd");

            if (!Page.IsPostBack)
            {
                UserBookingBal b = new UserBookingBal();
                DataSet ds = b.GetHotelName();
                ddlHotel.DataSource = ds.Tables["Hotel"];
                ddlHotel.DataTextField = "HotelName";
                ddlHotel.DataValueField = "HotelId";
                ddlHotel.Items.Insert(0, "--- Select Hotel ---");
                ddlHotel.DataBind();
                if (Session["UName"] == null)
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm1", "$('#bookingHistory').hide();$('#cancelBooking').hide();$('#logoutbtn').hide();", true);
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm2", "$('#loginbtn').show();", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm3", "$('#loginbtn').hide();", true);
                }
            }
            else
            {

            }
        }
        protected void ddlHotel_SelectedIndexChanged(object sender, EventArgs e)
        {
            UserBookingBal b = new UserBookingBal();
            string Location = b.GetLocation(int.Parse(ddlHotel.SelectedValue));
            Session["Location"] = Location.ToString();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ddlHotel.SelectedIndex = 0;
            txtInDate.Text = "";
            txtOutDate.Text = "";
            txtGuests.Text = "1";
            txtRooms.Text = "1";
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Session["HotelId"] = ddlHotel.SelectedValue.ToString();
            Session["HotelName"] = ddlHotel.SelectedItem.ToString();
            Session["CheckIn"] = txtInDate.Text.ToString();
            Session["CheckOut"] = txtOutDate.Text.ToString();
            Session["NoofGuests"] = txtGuests.Text;
            Session["NoofRooms"] = txtRooms.Text;
            Response.Redirect("SearchRoom.aspx");
        }
    }
}