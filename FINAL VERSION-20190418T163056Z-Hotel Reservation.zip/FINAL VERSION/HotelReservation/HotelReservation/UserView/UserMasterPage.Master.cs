﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HotelReservation.UserView
{
    public partial class UserMasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void logout_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            
            
            Response.Redirect("BookHotel.aspx");
            

        }

        protected void loginbtn_ServerClick(object sender, EventArgs e)
        {
           
            Response.Redirect("../Views/Login.aspx");
        }

        
    }
}