﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
namespace HotelReservation.UserView
{
    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UName"] == null)
            {
                Response.Redirect("../Views/Login.aspx");
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm3", "$('#loginbtn').hide();", true);

            }
            if (!IsPostBack)
            {
                readOnlyInput.Value = Session["HotelId"].ToString();
                pay.Value = Session["AmountPayable"].ToString();
            }
        }
        protected void Unnamed_ServerClick(object sender, EventArgs e)
        {
            PaymentBal bal = new PaymentBal();
            string cardno = cardNumber.Value;
            //string expdate = expityMonth.Value;
            //string cv = cvCode.Value;
            int UId = int.Parse(Session["UId"].ToString());
            string Particulars = Convert.ToString("Book a Hotel");
            string date1 = Convert.ToString(DateTime.Now);
            string time1 = Convert.ToString(DateTime.Now);
            string Types = Convert.ToString("Dr.");
            double amt = double.Parse(Session["Price"].ToString());
            int HotelId = int.Parse(Session["HotelId"].ToString());
            int BookingStatus = 1;
            DateTime checkIn = DateTime.Parse(Session["CheckIn"].ToString());
            DateTime checkOut = DateTime.Parse(Session["CheckOut"].ToString());
            int Guests = int.Parse(Session["NoofGuests"].ToString());
            string RoomName = Session["RoomTypeName"].ToString();
            int RoomsID = int.Parse(Session["RoomId"].ToString());
            int NoofRooms = int.Parse(Session["NoofRooms"].ToString());
            byte[] NationalId = (byte[])Session["NationalID"];

            int res = bal.Select(cardno, amt, UId);
            if (res == 0)
            {
                //ScriptManager.RegisterStartupScript(this, GetType(), "YourUniqueScriptKey",
                //                " myalert();", true);
                if (bal.Insert(UId, Particulars, date1, time1, Types, amt, HotelId, BookingStatus, checkIn, checkOut, Guests, RoomName, NoofRooms, NationalId, RoomsID))
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "YourUniqueScriptKey",
                                " myalert();", true);
                    cardNumber.Value = "";
                    readOnlyInput.Value = "";
                    expityMonth.Value = "";
                    cvCode.Value = "";
                    pay.Value = "";
                    //Response.Redirect("https://www.random.org/strings/?num=10&len=16&digits=on&unique=on&format=html&rnd=new");
                }

            }
            else if (res == 1)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "YourUniqueScriptKey2",
                               " myalert2();", true);
            }
            else if (res == 2)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "YourUniqueScriptKey1",
                              " myalert3();", true);
            }
        }
    }
}