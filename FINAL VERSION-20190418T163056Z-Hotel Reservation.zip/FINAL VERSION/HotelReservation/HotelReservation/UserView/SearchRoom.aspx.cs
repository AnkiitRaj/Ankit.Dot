﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
namespace HotelReservation.UserView
{
    public partial class SearchRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UName"] == null)
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm1", "$('#bookingHistory').hide();$('#cancelBooking').hide();$('#logoutbtn').hide();", true);
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm2", "$('#loginbtn').show();", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepconfirm3", "$('#loginbtn').hide();", true);
            }
            if (!IsPostBack)
            {
                //lblLocation.Text = Session["Location"].ToString();
                if (Session["HotelName"] == null)
                {
                    Response.Redirect("../UserView/BookHotel.aspx");
                }
                lblHotelName.Text = Session["HotelName"].ToString();
                int HotelId = int.Parse(Session["HotelId"].ToString());
                string CheckIn = Session["CheckIn"].ToString();
                string CheckOut = Session["CheckOut"].ToString();
                int NoofGuests = int.Parse(Session["NoofGuests"].ToString());
                int NoofRooms = int.Parse(Session["NoofRooms"].ToString());
                string Location = Session["Location"].ToString();
                UserBookingBal b = new UserBookingBal();
                DataSet ds1 = b.GetRoomDetails1(HotelId, CheckIn, CheckOut);
                ListView1.DataSource = ds1;
                ListView1.DataBind();
                int av1 = int.Parse(ds1.Tables[0].Rows[0]["AvailableRooms"].ToString());
                if (NoofRooms > av1)
                {
                    ListView1.Visible = false;

                }
                DataSet ds2 = b.GetRoomDetails2(HotelId, CheckIn, CheckOut);
                ListView2.DataSource = ds2;
                ListView2.DataBind();
                int av2 = int.Parse(ds2.Tables[0].Rows[0]["AvailableRooms"].ToString());
                if (NoofRooms > av2)
                {
                    ListView2.Visible = false;
                }
                DataSet ds3 = b.GetRoomDetails3(HotelId, CheckIn, CheckOut);
                ListView3.DataSource = ds3;
                ListView3.DataBind();
                int av3 = int.Parse(ds3.Tables[0].Rows[0]["AvailableRooms"].ToString());
                if (NoofRooms > av3)
                {
                    ListView3.Visible = false;
                }
                DataSet ds4 = b.GetRoomDetails4(HotelId, CheckIn, CheckOut);
                ListView4.DataSource = ds4;
                ListView4.DataBind();
            }
        }

        protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (String.Equals(e.CommandName, "BookRoom"))
            {
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
                int RoomId = int.Parse(commandArgs[0]);
                string RoomTypeName = commandArgs[1];
                string Description1 = commandArgs[2];
                string Description2 = commandArgs[3];
                double Price = double.Parse(commandArgs[4]);
                DateTime CIn = DateTime.Parse(Session["CheckIn"].ToString());
                DateTime COut = DateTime.Parse(Session["CheckOut"].ToString());
                TimeSpan datediff = COut - CIn;
                double NoofDays = double.Parse(datediff.Days.ToString());
                double FinPrice = Price * int.Parse(Session["NoofRooms"].ToString()) * NoofDays;
                Session["RoomId"] = RoomId.ToString();
                Session["RoomTypeName"] = RoomTypeName.ToString();
                Session["Description1"] = Description1.ToString();
                Session["Description2"] = Description2.ToString();
                Session["Price"] = FinPrice.ToString();
                Response.Redirect("UserRoomSelectionPage.aspx");
            }
        }

        protected void ListView2_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (String.Equals(e.CommandName, "BookRoom"))
            {
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
                int RoomId = int.Parse(commandArgs[0]);
                string RoomTypeName = commandArgs[1];
                string Description1 = commandArgs[2];
                string Description2 = commandArgs[3];
                double Price = double.Parse(commandArgs[4]);
                DateTime CIn = DateTime.Parse(Session["CheckIn"].ToString());
                DateTime COut = DateTime.Parse(Session["CheckOut"].ToString());
                TimeSpan datediff = COut - CIn;
                double NoofDays = double.Parse(datediff.Days.ToString());
                double FinPrice = Price * int.Parse(Session["NoofRooms"].ToString()) * NoofDays;
                Session["RoomId"] = RoomId.ToString();
                Session["RoomTypeName"] = RoomTypeName.ToString();
                Session["Description1"] = Description1.ToString();
                Session["Description2"] = Description2.ToString();
                Session["Price"] = FinPrice.ToString();
                Response.Redirect("UserRoomSelectionPage.aspx");
            }
        }

        protected void ListView3_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (String.Equals(e.CommandName, "BookRoom"))
            {
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
                int RoomId = int.Parse(commandArgs[0]);
                string RoomTypeName = commandArgs[1];
                string Description1 = commandArgs[2];
                string Description2 = commandArgs[3];
                double Price = double.Parse(commandArgs[4]);
                DateTime CIn = DateTime.Parse(Session["CheckIn"].ToString());
                DateTime COut = DateTime.Parse(Session["CheckOut"].ToString());
                TimeSpan datediff = COut - CIn;
                double NoofDays = double.Parse(datediff.Days.ToString());
                double FinPrice = Price * int.Parse(Session["NoofRooms"].ToString()) * NoofDays;
                Session["RoomId"] = RoomId.ToString();
                Session["RoomTypeName"] = RoomTypeName.ToString();
                Session["Description1"] = Description1.ToString();
                Session["Description2"] = Description2.ToString();
                Session["Price"] = FinPrice.ToString();
                Response.Redirect("UserRoomSelectionPage.aspx");
            }
        }

        protected void ListView4_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (String.Equals(e.CommandName, "BookRoom"))
            {
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
                int RoomId = int.Parse(commandArgs[0]);
                string RoomTypeName = commandArgs[1];
                string Description1 = commandArgs[2];
                string Description2 = commandArgs[3];
                double Price = double.Parse(commandArgs[4]);
                DateTime CIn = DateTime.Parse(Session["CheckIn"].ToString());
                DateTime COut = DateTime.Parse(Session["CheckOut"].ToString());
                TimeSpan datediff = COut - CIn;
                double NoofDays = double.Parse(datediff.Days.ToString());
                double FinPrice = Price * int.Parse(Session["NoofRooms"].ToString()) * NoofDays;
                Session["RoomId"] = RoomId.ToString();
                Session["RoomTypeName"] = RoomTypeName.ToString();
                Session["Description1"] = Description1.ToString();
                Session["Description2"] = Description2.ToString();
                Session["Price"] = FinPrice.ToString();
                Response.Redirect("UserRoomSelectionPage.aspx");
            }
        }

    }
}