﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace HotelReservation.Views
{
    /// <summary>
    /// Summary description for ImageHandler
    /// </summary>
    public class ImageHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string imageid = context.Request.QueryString["bookingId"];
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {

                connection.Open();
                
                SqlCommand command = new SqlCommand("select NationalID from tblReservation where bookingid=" + imageid, connection);
                command.CommandType = CommandType.Text;
                SqlDataReader dr = command.ExecuteReader();
                dr.Read();
                context.Response.BinaryWrite((Byte[])dr[0]);
                connection.Close();
                context.Response.End();
              
            }
        
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}