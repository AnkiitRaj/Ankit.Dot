﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
using System.Data;
namespace HotelReservation.Views
{
    public partial class AdminViewDiscount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UName"].ToString() == null)
            {
                Response.Redirect("../Views/Login.aspx");
            }
            //GridView1.DataSource = DiscountBal.getAllDiscountDetails();
            //GridView1.DataBind();
            if (!IsPostBack)
            {
                PopulateData(1, 5);
            }
            AddpaggingButton();
        }
        protected void logout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("../Views/Login.aspx");
        }
        private void AddpaggingButton()
        {
            int totalRecord = 0;
            int noOfRecord = 0;
            totalRecord = ViewState["TotalRecord"] != null ? (int)ViewState["TotalRecord"] : 0;
            noOfRecord = ViewState["NoOfRecord"] != null ? (int)ViewState["NoOfRecord"] : 0;
            int pages = 0;
            if (totalRecord > 0 && noOfRecord > 0)
            {
                pages = (totalRecord / noOfRecord) + ((totalRecord % noOfRecord) > 0 ? 1 : 0);
                for (int i = 0; i < pages; i++)
                {
                    Button b = new Button();
                    b.Text = (i + 1).ToString();
                    b.CommandArgument = (i + 1).ToString();
                    b.ID = "Button_" + (i + 1).ToString();
                    b.CssClass = "btn btn-outline-warning";
                    b.Click += new EventHandler(this.b_click);
                    Panel1.Controls.Add(b);
                }
            }
        }

        private void b_click(object sender, EventArgs e)
        {
            //this is for get data from database from clicking button
            string pageNo = ((Button)sender).CommandArgument;
            PopulateData(Convert.ToInt32(pageNo), 5);

        }

        private void PopulateData(int pageNo, int noOfRecord)
        {
            GridView1.DataSource = DiscountBal.PopulateData(pageNo, noOfRecord);
            GridView1.DataBind();
            ViewState["TotalRecord"] = DiscountBal.getTotalRecord1();
            ViewState["NoOfRecord"] =DiscountBal.getNoOfRecord1();

            
        }

        

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.Equals("detail"))
            {
                int index = Convert.ToInt32(e.CommandArgument);

                string DiscountID = GridView1.DataKeys[index].Value.ToString();
                DataTable ds = DiscountBal.getAllDiscountDetails();
                var query = from row in ds.AsEnumerable()
                            where row.Field<int>("DiscountID") == (Convert.ToInt32(DiscountID))
                            select row
                            ;
                hiddenprimary.Value = DiscountID;
                foreach (var x in query)
                {
                    Discountprimary.Value = DiscountID;
                    DiscoutCode.Value = x[1].ToString();
                    DiscountPerc.Value = x[2].ToString();
                   
                }

                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "step1confirm", "$('#myModal').modal();", true);

            }
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            int discountID = int.Parse(hiddenprimary.Value);
            string discountCoder =DiscoutCode.Value;
            string discountPercr = DiscountPerc.Value;
            DiscountBal.UpdateDiscount(discountID, discountCoder, discountPercr);
            Response.Redirect("AdminViewDiscount.aspx");

            
        }

        protected void AddDiscount_ServerClick(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "step1confirm", "$('#add').modal();", true);
        }

        protected void ActualAddDiscount_Click(object sender, EventArgs e)
        {
            string discountCode = DiscountCode1.Value;
            string discountPerc = DiscountPerc1.Value;
            DiscountBal.AddDiscount(discountCode, discountPerc);
            Response.Redirect("AdminViewDiscount.aspx");
        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            int discountID = int.Parse(hiddenprimary.Value);
            DiscountBal.DeleteDiscount(discountID);
            Response.Redirect("AdminViewDiscount.aspx");
        }
    }
}