﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
namespace HotelReservation.Views
{
    public partial class UserPagePayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Unnamed_ServerClick(object sender, EventArgs e)
        {
            PaymentBal bal = new PaymentBal();
            string cardno = cardNumber.Value;
            //string expdate = expityMonth.Value;
            //string cv = cvCode.Value;
            double amt = Convert.ToDouble(4000);
            int res = bal.Select(cardno, amt,uid);
            if (res == 0)
            {
                //Response.Write("Payment Successfull");
                ScriptManager.RegisterStartupScript(this, GetType(), "YourUniqueScriptKey",
                                " myalert();", true);
            }
            else if (res == 1)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "YourUniqueScriptKey",
                               " myalert2();", true);
                
            }
            else if (res == 2)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "YourUniqueScriptKey",
                              " myalert3();", true);
            }
        }
    }
}