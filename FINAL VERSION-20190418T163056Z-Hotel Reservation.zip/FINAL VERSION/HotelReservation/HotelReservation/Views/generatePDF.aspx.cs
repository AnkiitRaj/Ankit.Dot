﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Data;

namespace HotelReservation.Views
{
    public partial class generatePDF : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int uid =Convert.ToInt32(Session["UID"]);
            int bookingId = Convert.ToInt32(Session["BookingID"]);
            int totalPrice = Convert.ToInt32(Session["totalPrice"]);

            BillDownloader(uid,bookingId,totalPrice);
            Response.Redirect("../UserView/UserBookingHistory.aspx");

            
        }
        public void BillDownloader(int uid, int bookingId,int totalPrice)
        {
            //PdfPTable pdfTable = 
            DataTable dt=FileUtilityBal.generatePDF(uid,bookingId);
            GridView objGV = new GridView();
            objGV.AutoGenerateColumns = false;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                BoundField boundField = new BoundField();
                boundField.DataField = dt.Columns[i].ColumnName.ToString();
                boundField.HeaderText = dt.Columns[i].ColumnName.ToString();
                objGV.Columns.Add(boundField);
                
            }
            objGV.DataSource = dt;
            objGV.DataBind();
            int columnsCount = objGV.Columns.Count;
            PdfPTable pdfTable = new PdfPTable(columnsCount);
            int numberOfColumns = dt.Columns.Count;
            foreach (TableCell gridViewHeaderCell in objGV.HeaderRow.Cells)
            {
                // Create the Font Object for PDF document
                Font font = new Font();
                // Set the font color to GridView header row font color
                font.Color = new BaseColor(objGV.HeaderStyle.ForeColor);

                // Create the PDF cell, specifying the text and font
                PdfPCell pdfCell = new PdfPCell(new Phrase(gridViewHeaderCell.Text, font));

              
                pdfTable.AddCell(pdfCell);
            }
            foreach (GridViewRow gridViewRow in objGV.Rows)
            {
               
                foreach (TableCell tableCell in gridViewRow.Cells)
                {
                   
                    PdfPCell pdfCell = new PdfPCell(new Phrase(tableCell.Text));
                    pdfTable.AddCell(pdfCell);
                }

            }

            //return pdfTable;
            Document pdfDocument = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
            PdfWriter.GetInstance(pdfDocument, Response.OutputStream);
            pdfDocument.Open();

            var FontColour = new BaseColor(192, 192, 192);
            var Calibri8 = FontFactory.GetFont("CALIBRI_BOLD", 35, FontColour);
            Paragraph paragraph = new Paragraph("Booking Details", Calibri8);
           
            paragraph.Alignment = Element.ALIGN_CENTER;
            paragraph.SpacingAfter = 10f;
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(Server.MapPath("../") + "/images/h-logo.jpg");



            //Give space before image
            jpg.ScaleToFit(150, 150);
            //jpg.SpacingBefore = 2f;

            //Give some space after the image

            //jpg.SpacingAfter = 1f;

            jpg.Alignment = Element.ALIGN_CENTER;





            pdfDocument.Add(jpg);

            pdfDocument.Add(paragraph);


            pdfDocument.Add(pdfTable);
            var FontColour1 = new BaseColor(192, 192, 192);
            var Calibri9 = FontFactory.GetFont("CALIBRI_BOLD", 35, FontColour1);
            Paragraph p7 = new Paragraph("Invoice", Calibri9);
            p7.Alignment = Element.ALIGN_CENTER;
            p7.SpacingAfter = 30f;
            pdfDocument.Add(p7);
            var FontColour2 = new BaseColor(255, 87, 51);
            var Calibri10 = FontFactory.GetFont("CALIBRI_BOLD", 15);
            var Calibri11 = FontFactory.GetFont("CALIBRI_BOLD", 15, FontColour2);
            Paragraph p2 = new Paragraph("                  Base Price      Rs." + (totalPrice - (totalPrice * 0.18)) + "                     ", Calibri10);
            Paragraph p3 = new Paragraph("                  CGST            Rs." + ((totalPrice * 0.09)) + "                     ", Calibri10);
            Paragraph p4 = new Paragraph("                  SGST            Rs." + ((totalPrice * 0.09)) + "                     ", Calibri10);
            Paragraph p5 = new Paragraph("------------------------------------------------------------------------------------------------", Calibri10);
            Paragraph p6 = new Paragraph("                  TOTAL           Rs." + ((totalPrice)) + "                     ", Calibri11);
            p2.Alignment = Element.ALIGN_CENTER;
            p2.SpacingBefore = 30f;
            pdfDocument.Add(p2);
            p3.Alignment = Element.ALIGN_CENTER;
            p3.SpacingBefore = 30f;
            pdfDocument.Add(p3);
            p4.Alignment = Element.ALIGN_CENTER;
            p4.SpacingBefore = 30f;
            pdfDocument.Add(p4);
            p5.Alignment = Element.ALIGN_CENTER;
            p5.SpacingBefore = 30f;
            pdfDocument.Add(p5);
            p6.Alignment = Element.ALIGN_CENTER;
            p6.SpacingBefore = 10f;
            pdfDocument.Add(p6);
            Paragraph p8 = new Paragraph("CANCELLATION POLICY\n• Reservations made over 11-16 Sep 2018, 28-31 Dec 2018, 1-4 Jan 2019, 8-10 Aug 2019 and 28 Dec 2019 - 4 Jan 2020 require full pre-payment and are non-cancellable, non-amendable and non-refundable. The entire period of your stay, inclusive of nights before and after the dates listed above, will be charged to your credit card upon reservation.\n• Cancellation of and/or amendments to your reservation must be made 48 hours (i.e., by 4pm Singapore time) prior to your arrival date.\n• Cancellation or amendment made within 48 hours of arrival will incur a cancellation fee of one night's room charge (inclusive of any applicable prevailing government tax).\n• In the event of no-show, a fee of one night's room charge (inclusive of any applicable prevailing government tax) will be charged to your credit card provided at the time of reservation.");
            p8.Alignment = Element.ALIGN_LEFT;
            p8.SpacingBefore = 20f;
            pdfDocument.Add(p8);
            pdfDocument.Close();
            Response.ContentType = "application/pdf";
            Response.AppendHeader("content-disposition", "attachment;filename=hotel.pdf");
            Response.Write(pdfDocument);
            Response.Flush();
            Response.End();
        }
    }
}