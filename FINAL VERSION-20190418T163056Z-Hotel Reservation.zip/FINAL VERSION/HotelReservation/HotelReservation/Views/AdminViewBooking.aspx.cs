﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
namespace HotelReservation.Views
{
    public partial class AdminViewBooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UName"].ToString() == null)
            {
                Response.Redirect("../Views/Login.aspx");
            }
            if (!IsPostBack)
            {
                PopulateData(1, 5);
            }
            AddpaggingButton();
        
        }
        protected void logout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("../Views/Login.aspx");
        }
        private void PopulateData(int pageNo, int noOfRecord)
        {
             
        
            GridView1.DataSource = BookingBal.PopulateData(pageNo, noOfRecord);
            GridView1.DataBind();
            ViewState["TotalRecord"] = BookingBal.getTotalRecord1();
            ViewState["NoOfRecord"] = BookingBal.getNoOfRecord1();
        
        }

        private void AddpaggingButton()
        {
            int totalRecord = 0;
            int noOfRecord = 0;
            totalRecord = ViewState["TotalRecord"] != null ? (int)ViewState["TotalRecord"] : 0;
            noOfRecord = ViewState["NoOfRecord"] != null ? (int)ViewState["NoOfRecord"] : 0;
            int pages = 0;
            if (totalRecord > 0 && noOfRecord > 0)
            {
                pages = (totalRecord / noOfRecord) + ((totalRecord % noOfRecord) > 0 ? 1 : 0);
                for (int i = 0; i < pages; i++)
                {
                    Button b = new Button();
                    b.Text = (i + 1).ToString();
                    b.CommandArgument = (i + 1).ToString();
                    b.ID = "Button_" + (i + 1).ToString();
                    b.CssClass = "btn btn-outline-warning";
                 
                    b.Click += new EventHandler(this.b_click);
                    Panel1.Controls.Add(b);
                }
            }
        }
        private void b_click(object sender, EventArgs e)
        {
            //this is for get data from database from clicking button
            string pageNo = ((Button)sender).CommandArgument;
            PopulateData(Convert.ToInt32(pageNo), 5);

        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }
    }
}