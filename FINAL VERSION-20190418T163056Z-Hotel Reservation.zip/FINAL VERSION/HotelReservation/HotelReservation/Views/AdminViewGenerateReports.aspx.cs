﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
using System.IO;
namespace HotelReservation.Views
{
    public partial class AdminViewGenerateReports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UName"].ToString() == null)
            {
                Response.Redirect("../Views/Login.aspx");
            }
        }
        protected void logout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("../Views/Login.aspx");
        } 
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedItem.Value == "0")
            {
                StreamWriter fileInfo=FileUtilityBal.generateReport();

                Response.ContentType = "application/octet-stream";
                Response.AppendHeader("content-disposition", "filename=HotelReport.csv");
                Response.TransmitFile(Server.MapPath("~/Reports/HotelReport.csv"));
                Response.End();
                
            }
            if (DropDownList1.SelectedItem.Value == "1")
            {
                StreamWriter fileInfo = FileUtilityBal.generateTransReport();

                    Response.ContentType = "application/octet-stream";
                    Response.AppendHeader("content-disposition", "filename=TransactionReport.csv");
                    Response.TransmitFile(Server.MapPath("~/Reports/TransactionReport.csv"));
                    Response.End();
                
                

            }
            if (DropDownList1.SelectedItem.Value == "2")
            {
                StreamWriter fileInfo = FileUtilityBal.generateBookingReport();

                Response.ContentType = "application/octet-stream";
                Response.AppendHeader("content-disposition", "filename=BookingReport.csv");
                Response.TransmitFile(Server.MapPath("~/Reports/BookingReport.csv"));
                Response.End();

            }
            if (DropDownList1.SelectedItem.Value == "3")
            {
                StreamWriter fileInfo = FileUtilityBal.generateRevenueReport();

                Response.ContentType = "application/octet-stream";
                Response.AppendHeader("content-disposition", "filename=RevenueReport.csv");
                Response.TransmitFile(Server.MapPath("~/Reports/RevenueReport.csv"));
                Response.End();

            }

        }
        protected void ShowGridView_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedItem.Value == "0")
            {
                GridView grd = new GridView();
                grd.ID = "GridView" + "1";
                grd.CssClass = "table table-bordered";
                grd.DataSource = HotelBal.getAllHotelDetails(); // some data source
                grd.DataBind();
                pnlResult.Controls.Add(grd);
            }
            if (DropDownList1.SelectedItem.Value == "1")
            {
                GridView grd = new GridView();
                grd.ID = "GridView" + "2";
                grd.CssClass = "table table-bordered";
                grd.DataSource = HotelBal.getAllTransactionlDetails(); // some data source
                grd.DataBind();
                pnlResult.Controls.Add(grd);
            }
            if (DropDownList1.SelectedItem.Value == "2")
            {
                GridView grd = new GridView();
                grd.ID = "GridView" + "3";
                grd.CssClass = "table table-bordered";
                grd.DataSource = HotelBal.getAllBookinglDetails(); // some data source
                grd.DataBind();
                pnlResult.Controls.Add(grd);
            }
            if (DropDownList1.SelectedItem.Value == "3")
            {
                GridView grd = new GridView();
                grd.ID = "GridView" + "4";
                grd.CssClass = "table table-bordered";
                grd.DataSource = HotelBal.getAllRevenuelDetails(); // some data source
                grd.DataBind();
                pnlResult.Controls.Add(grd);
            }
        }
    }
}