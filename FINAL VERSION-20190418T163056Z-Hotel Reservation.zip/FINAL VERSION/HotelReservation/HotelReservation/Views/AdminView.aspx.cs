﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelBAL;
using System.Data;
namespace HotelReservation.Views
{
    public partial class AdminView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //GridView1.DataSource = HotelBal.getAllHotelDetails();
            //GridView1.DataBind();
            if (Session["UName"]== null)
            {
                Response.Redirect("../Views/Login.aspx");
            }
            string uname = Session["UName"].ToString();
            string fullname = Session["Fullname"].ToString();
            string emailid = Session["EmailID"].ToString();
            string gender = Session["Gender"].ToString();
            int uid = Convert.ToInt32(Session["UId"]);
            bool status = Convert.ToBoolean(Session["Status"]);
            if (!IsPostBack)
            {
                PopulateData(1, 6);
            }
            AddpaggingButton();
        }


        private void PopulateData(int pageNo, int noOfRecord)
        {
            GridView1.DataSource = HotelBal.PopulateData(pageNo, noOfRecord);
            GridView1.DataBind();
            ViewState["TotalRecord"] = HotelBal.getTotalRecord1();
            ViewState["NoOfRecord"] = HotelBal.getNoOfRecord1();
        }
        private void AddpaggingButton()
        {
            int totalRecord = 0;
            int noOfRecord = 0;
            totalRecord = ViewState["TotalRecord"] != null ? (int)ViewState["TotalRecord"] : 0;
            noOfRecord = ViewState["NoOfRecord"] != null ? (int)ViewState["NoOfRecord"] : 0;
            int pages = 0;
            if (totalRecord > 0 && noOfRecord > 0)
            {
                pages = (totalRecord / noOfRecord) + ((totalRecord % noOfRecord) > 0 ? 1 : 0);
                for (int i = 0; i < pages; i++)
                {
                    Button b = new Button();
                    b.Text = (i + 1).ToString();
                    b.CommandArgument = (i + 1).ToString();
                    b.ID = "Button_" + (i + 1).ToString();
                    b.CssClass = "btn btn-outline-warning";
                    b.Click += new EventHandler(this.b_click);
                    Panel1.Controls.Add(b);
                }
            }
        }

        private void b_click(object sender, EventArgs e)
        {
            //this is for get data from database from clicking button
            string pageNo = ((Button)sender).CommandArgument;
            PopulateData(Convert.ToInt32(pageNo), 6);

        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.Equals("detail"))
            {

                int index = Convert.ToInt32(e.CommandArgument);

                string hotelID = GridView1.DataKeys[index].Value.ToString();
                DataTable ds = HotelBal.getAllHotelDetails();
                var query = from row in ds.AsEnumerable()
                            where row.Field<int>("ID") == (Convert.ToInt32(hotelID))
                            select row
                            ;
                hiddenprimary.Value = hotelID;
                foreach (var x in query)
                {
                    hotelprimary.Value = hotelID;
                    hotelname.Value = x[1].ToString();
                    location.Value = x[2].ToString();
                    RoomType.Value = x[3].ToString();
                    TotalCountOfRooms.Value = x[4].ToString();

                }
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "step1confirm", "$('#myModal').modal();", true);

            }

        }

        protected void addHotelModal_ServerClick(object sender, EventArgs e)
        {
            string hotelName = hotelname1.Value;
            string loc = location1.Value;
            string totalDeluxe = totalDeluxe1.Value;
            string totalSuperDeluxe = totalSuperDeluxe1.Value;
            string totalSuite = totalSuite1.Value;
            HotelBal.AddHotel(hotelName, loc, totalDeluxe, totalSuperDeluxe, totalSuite);
            Response.Redirect("AdminView.aspx");
        }

        protected void addHotel_ServerClick(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "stepConfirm2", "$('#add').modal();", true);
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            int id = int.Parse(hiddenprimary.Value);
            string hotelName = hotelname.Value;
            string loc = location.Value;
            string roomtype = RoomType.Value;
            int totalCountOfRooms = int.Parse(TotalCountOfRooms.Value);

            HotelBal.updateHotel(id, hotelName, loc, roomtype, totalCountOfRooms);

            Response.Redirect("AdminView.aspx");




        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            string hotelName = hotelname.Value;
            string roomtype = RoomType.Value;
            HotelBal.DeleteHotel(hotelName, roomtype);
            Response.Redirect("AdminView.aspx");
        }
        protected void logout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("../Views/Login.aspx");
        }

        protected void GridView1_DataBound(object sender, EventArgs e)
        {
            for (int rowIndex = GridView1.Rows.Count - 2; rowIndex >= 0; rowIndex--)
            {
                GridViewRow gvRow = GridView1.Rows[rowIndex];
                GridViewRow gvNextRow = GridView1.Rows[rowIndex + 1];

                // compare cell value if found duplicate value then marge cell 

                for (int cellIndex = 0; cellIndex < gvRow.Cells.Count; cellIndex++)
                {
                    //if (cellIndex == 0)
                    //{


                    //    if (gvNextRow.Cells[cellIndex].RowSpan < 2)
                    //    {
                    //        gvRow.Cells[cellIndex].RowSpan = 2;
                    //        gvNextRow.Cells[cellIndex].Visible = false;
                    //    }
                    //    else
                    //    {
                    //        if (rowIndex % 3 == 0)
                    //        {
                    //            gvRow.Cells[cellIndex].RowSpan = gvNextRow.Cells[cellIndex].RowSpan + 1;
                    //            gvNextRow.Cells[cellIndex].Visible = false;
                    //        }
                    //    }


                    //}
                    //else
                    //{
                    if (gvRow.Cells[cellIndex].Text == gvNextRow.Cells[cellIndex].Text && cellIndex != 5 && cellIndex != 3)
                    {
                        if (gvNextRow.Cells[cellIndex].RowSpan < 2)
                        {
                            gvRow.Cells[cellIndex].RowSpan = 2;
                        }
                        else
                        {
                            gvRow.Cells[cellIndex].RowSpan = gvNextRow.Cells[cellIndex].RowSpan + 1;
                        }
                        gvNextRow.Cells[cellIndex].Visible = false;
                    }
                    //}
                }
            }
        }
    }
}
