﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using HotelBAL;

namespace HotelReservation.Views
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Page.IsPostBack)
            error.InnerText = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
            string uName = exampleInputEmail1.Value;
            string passWord = exampleInputPassword1.Value;
            string fullname = string.Empty;
            
            if (UserBAL.GetUser(uName, passWord))
            {
                Session["UName"] = UserBAL.Getfullname(uName);
                Session["Fullname"] = UserBAL.GetUserDetails(uName).Name;
                Session["EmailID"] = UserBAL.GetUserDetails(uName).Uname;
                Session["Gender"] = UserBAL.GetUserDetails(uName).Gender;
                Session["UId"] = UserBAL.GetUserDetails(uName).UID;
                Session["Status"] = UserBAL.GetUserDetails(uName).Status;
                if (UserBAL.GetUserDetails(uName).Status == true)
                {
                    Response.Redirect("../Views/AdminView.aspx");
                }
                else
                {
                    if (Session["RoomId"] != null && Session["RoomTypeName"] != null && Session["Description1"] != null && Session["Description2"] != null && Session["Price"] != null)
                    {
                        Response.Redirect("../UserView/UserRoomSelectionPage.aspx");
                    }
                    else
                    Response.Redirect("../UserView/BookHotel.aspx");
                }
            }
            else
            {
                //if(!Page.IsPostBack)
                 error.InnerText= "Please enter Correct Credentials";
                 
            }
        }

        protected void Register_ServerClick(object sender, EventArgs e)
        {
            try
            {
                string name = fullname.Value;
                string Uuname = uname.Value;
                string pass = pwd.Value;
                string cityName = city.Value;
                string countryName = country.Value;
                string zipCode = Zip.Value;
                string date =dob.Value;
                bool gender1 = male.Checked;
                bool gender2 = female.Checked;
                string gender = string.Empty;
                if (gender1 == false)
                {
                    gender = "Female";
                }
                else
                {
                    gender = "Male";
                }
                DateTime dateOfbirth=DateTime.ParseExact(date,"yyyy-MM-dd",null);
                bool f = UserBAL.RegisterUser(name, Uuname,gender,pass, cityName, countryName, zipCode, dateOfbirth);
                if (f)
                {
                    Response.Write("<script>alert('You have successfully registered!');</script>");
                    Response.Redirect("./Login.aspx");
                   
                }
            }
            catch (Exception ex)
            {
                
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

        }
    }
}