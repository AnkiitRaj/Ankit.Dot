﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelDAL;
namespace HotelBAL
{
    public class CancelBookingBal
    {
        public int updateUser(int BookingID, int uid)
        {
            CancelBookingDal dal = new CancelBookingDal();
            return dal.updateData(BookingID, uid);
            
        }
    }
}
