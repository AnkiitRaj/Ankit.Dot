﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelDAL;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Data;
namespace HotelBAL
{
    public class FileUtilityBal
    {
        public static StreamWriter generateReport()
        {
           return FileUtilityDal.generateReport();
        }

        public static DataTable generatePDF(int uid, int bookingId)
        {
            return FileUtilityDal.generatePDF(uid,bookingId);
        }

        public static DataTable CancelgeneratePDF(int uid, int bookingId)
        {
            return FileUtilityDal.CancelgeneratePDF(uid, bookingId);
        }
        public static StreamWriter generateTransReport()
        {
            return FileUtilityDal.generateTransReport();
        }
        public static StreamWriter generateBookingReport()
        {
            return FileUtilityDal.generateBookingReport();
        }
        public static StreamWriter generateRevenueReport()
        {
            return FileUtilityDal.generateRevenueReport();
        }
    }
}
