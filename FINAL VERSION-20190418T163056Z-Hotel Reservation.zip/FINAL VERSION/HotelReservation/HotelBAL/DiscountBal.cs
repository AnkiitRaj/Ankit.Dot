﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelDAL;
using Common;
using System.Data;
namespace HotelBAL
{
    public class DiscountBal
    {
        public static DataTable getAllDiscountDetails()
        {
            return DiscountDal.getAllDiscountDetails();
        }

        public static DataTable PopulateData(int pageNo, int noOfRecord)
        {
            return DiscountDal.PopulateData(pageNo, noOfRecord);
        }
        public static int getTotalRecord1()
        {
            return DiscountDal.getTotalRecord1();

        }
        public static int getNoOfRecord1()
        {
           
            return  DiscountDal.getNoOfRecord1();
        }

        public static void AddDiscount(string discountCode, string discountPerc)
        {                             
            DiscountDal.AddDiscount(discountCode,discountPerc);
        }

        public static void UpdateDiscount(int discountID, string discountCoder, string discountPercr)
        {
            DiscountDal.UpdateDiscount(discountID,discountCoder,discountPercr);
        }

        public static void DeleteDiscount(int discountID)
        {
            DiscountDal.DeleteDiscount(discountID);
        }
        public int GetDiscount(string CouponCode)
        {
            DiscountDal cd = new DiscountDal();
            int Percent = cd.GetDiscount(CouponCode);
            return Percent;
        }
    }
}
