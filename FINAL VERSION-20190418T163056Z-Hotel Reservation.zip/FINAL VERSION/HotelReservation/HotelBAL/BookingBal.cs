﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelDAL;
using System.Data;
namespace HotelBAL
{
    public class BookingBal
    {

        public static DataTable PopulateData(int pageNo, int noOfRecord)
        {
            return BookingDal.PopulateData(pageNo, noOfRecord);

        }

        public static int getNoOfRecord1()
        {
            return BookingDal.getNoOfRecord1();
        }
        public static int getTotalRecord1()
        {
            return BookingDal.getTotalRecord1();
        }
        
    }
}
