﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using HotelDAL;
namespace HotelBAL
{
    public class UserBAL
    {
        public  static Boolean GetUser(string uName, string password)
        {
            bool f = false;
            if (UserDAL.GetUser(uName, password))
            {
                f = true;
            }
            else
            {
                f = false;
            }
            return f;
        }
        public static User GetUserDetails(string uName)
        {
            User user = UserDAL.GetUserDetails(uName);
            return user;
        }
        public static string Getfullname(string uName)
        {
            string name = UserDAL.Getfullname(uName);
            
            return name;
        }
        public static bool RegisterUser(string name, string uname, string gender, string pass, string cityName, string countryName, string zipCode, DateTime dateOfbirth)
        {
            
            User u = new User(name, uname,gender,pass, cityName, countryName, zipCode, dateOfbirth);
            bool f=UserDAL.RegisterUser(u);
            return f;             
        }                               
    }                                   
}                                      
                                        