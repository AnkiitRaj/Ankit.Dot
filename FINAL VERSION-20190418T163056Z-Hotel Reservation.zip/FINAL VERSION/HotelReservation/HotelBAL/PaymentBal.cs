﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelDAL;
namespace HotelBAL
{
    public class PaymentBal
    {
        public int Select(string cardnumber, double amount,int uid)
        {
            PaymentDal dal = new PaymentDal();
            return dal.Select(cardnumber, amount,uid);
        }
        public bool Insert(int UId, string Particulars, string date1, string time1, string types, double amt, int HotelId, int BookingStatus, DateTime checkIn, DateTime checkOut, int Guests, string RoomTypeName, int NoofRooms, byte[] NationalId, int RoomsID)
        {
            PaymentDal dal = new PaymentDal();
            return dal.Insert(UId, Particulars, date1, time1, types, amt, HotelId, BookingStatus, checkIn, checkOut, Guests, RoomTypeName, NoofRooms, NationalId, RoomsID);
        }
    }
}
