﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelDAL;

namespace HotelBAL
{
    public class UserBookingBal
    {
        UserBookingDal sr = new UserBookingDal();
        public DataSet GetRoomDetails1(int hid, string checkIn, string checkOut)
        {
            DataSet ds = sr.InsertDetails1(hid, checkIn, checkOut);
            return ds;
        }

        public DataSet GetRoomDetails2(int hid, string checkIn, string checkOut)
        {
            DataSet ds = sr.InsertDetails2(hid, checkIn, checkOut);
            return ds;
        }

        public DataSet GetRoomDetails3(int hid, string checkIn, string checkOut)
        {
            DataSet ds = sr.InsertDetails3(hid, checkIn, checkOut);
            return ds;
        }

        public DataSet GetRoomDetails4(int hid, string checkIn, string checkOut)
        {
            DataSet ds = sr.InsertDetails4(hid, checkIn, checkOut);
            return ds;
        }

        public DataSet GetHotelName()
        {
            DataSet ds = new DataSet();
            //SortedDictionary<int, string> sd = new SortedDictionary<int, string>();
            ds = sr.GetHotelName();
            return ds;
        }

        public string GetLocation(int hid)
        {
            return sr.GetLocation(hid);
        }
        public static DataTable PopulateData(int pageNo, int noOfRecord,int uid)
        {
            return UserBookingDal.PopulateData(pageNo, noOfRecord,uid);

        }

        public static int getNoOfRecord1()
        {
            return UserBookingDal.getNoOfRecord1();
        }
        public static int getTotalRecord1()
        {
            return UserBookingDal.getTotalRecord1();
        }

        public static int getBookingAmt(int BookingID)
        {
            return UserBookingDal.getBookingAmt(BookingID);
        }
    }
}
