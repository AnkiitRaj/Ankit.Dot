﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelDAL;
using Common;
using System.Data;
namespace HotelBAL
{
    public  class HotelBal
    {
        public static DataTable getAllHotelDetails()
        {
            return HotelDal.getAllHotelDetails();
        }

        public static DataTable getAllTransactionlDetails()
        {
            return HotelDal.getAllTransactionlDetails();
        }
        public static DataTable getAllBookinglDetails()
        {
            return HotelDal.getAllBookinglDetails();
        }
        public static DataTable getAllRevenuelDetails()
        {
            return HotelDal.getAllRevenuelDetails();
        }

       public static  DataTable PopulateData(int pageNo, int noOfRecord)
        {
            return HotelDal.PopulateData(pageNo, noOfRecord);
        }

        public static int getTotalRecord1()
        {
            return HotelDal.getTotalRecord1();
        }

        public static int getNoOfRecord1()
        {
            return HotelDal.getNoOfRecord1();
        }



        public static void updateHotel(int id, string hotelName, string loc, string roomtype,int totalCountOfRooms)
        {
            Hotel h = new Hotel(id,hotelName, loc, roomtype, totalCountOfRooms);
            HotelDal.updateHotel(h); 
        }

        public static void AddHotel(string hotelName, string loc, string totalDeluxe, string totalSuperDeluxe, string totalSuite)
        {
            HotelDal.AddHotel(hotelName, loc, totalDeluxe, totalSuperDeluxe, totalSuite);
        }

        public static void DeleteHotel(string hotelName, string roomtype)
        {
            HotelDal.DeleteHotel(hotelName,roomtype);
        }
    }
}
