﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    class Discount
    {
        string discountCode;

        public string DiscountCode
        {
            get { return discountCode; }
            set { discountCode = value; }
        }
        float discountPerc;

        public float DiscountPerc
        {
            get { return discountPerc; }
            set { discountPerc = value; }
        }
    }
}
