﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class User
    {
        bool status;



        public bool Status
        {
            get { return status; }
            set { status = value; }
        }
        int uid;

        public int UID
        {
            get { return uid; }
            set { uid = value; }
        }
        string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        string uname;

        public string Uname
        {
            get { return uname; }
            set { uname = value; }
        }
        string pass;

        public string Pass
        {
            get { return pass; }
            set { pass = value; }
        }
        string cityName;

        public string CityName
        {
            get { return cityName; }
            set { cityName = value; }
        }
        string countryName;

        public string CountryName
        {
            get { return countryName; }
            set { countryName = value; }
        }
        string zipcode;

        public string Zipcode
        {
            get { return zipcode; }
            set { zipcode = value; }
        }
        DateTime dateOfBirth;

        public DateTime DateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }
        public User() { }
        public User(string name, string uname, string gender, string pass, string cityName, string countryName, string zipCode, DateTime dateOfbirth)
        {
            this.Name = name;
            this.Uname = uname;
            this.Gender = gender;
            this.Pass = pass;
            this.CityName = cityName;
            this.CountryName = countryName;
            this.Zipcode = zipCode;
            this.DateOfBirth = dateOfbirth;
        }
    }
}
