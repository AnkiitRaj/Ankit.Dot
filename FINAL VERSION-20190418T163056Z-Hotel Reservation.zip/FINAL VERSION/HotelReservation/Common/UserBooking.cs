﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class UserBooking
    {
         private string hotelName;

        public string HotelName
        {
            get { return hotelName; }
            set { hotelName = value; }
        }

        private string roomType;

        public string RoomType
        {
            get { return roomType; }
            set { roomType = value; }
        }

        private string amenities;

        public string Amenities
        {
            get { return amenities; }
            set { amenities = value; }
        }

        private int availability;

        public int Availabilty
        {
            get { return availability; }
            set { availability = value; }
        }

        private double price;

        public double Price
        {
            get { return price; }
            set { price = value; }
        }


        public UserBooking()
        {
        }
        public UserBooking(string hotelName, string roomType, string amenities, int availability, double price)
        {
            this.HotelName = hotelName;
            this.RoomType = roomType;
            this.Amenities = amenities;
            this.Availabilty = availability;
            this.Price = price;
        }
    }
}
