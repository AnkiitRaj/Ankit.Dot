﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Hotel
    {
        int hotelid;

        public int Hotelid
        {
            get { return hotelid; }
            set { hotelid = value; }
        }
        string hotelName;

        public string HotelName
        {
            get { return hotelName; }
            set { hotelName = value; }
        }
        string location;

        public string Location
        {
            get { return location; }
            set { location = value; }
        }
        string totalDeluxe;

        public string TotalDeluxe
        {
            get { return totalDeluxe; }
            set { totalDeluxe = value; }
        }
        string priceOfDeluxe;

        public string PriceOfDeluxe
        {
            get { return priceOfDeluxe; }
            set { priceOfDeluxe = value; }
        }
        string totalSuperDeluxe;

        public string TotalSuperDeluxe
        {
            get { return totalSuperDeluxe; }
            set { totalSuperDeluxe = value; }
        }
        string priceOfSuperDeluxe;

        public string PriceOfSuperDeluxe
        {
            get { return priceOfSuperDeluxe; }
            set { priceOfSuperDeluxe = value; }
        }
        string totalSuite;

        public string TotalSuite
        {
            get { return totalSuite; }
            set { totalSuite = value; }
        }
        string priceOfSuite;

        public string PriceOfSuite
        {
            get { return priceOfSuite; }
            set { priceOfSuite = value; }
        }
        string roomType;

        public string RoomType
        {
            get { return roomType; }
            set { roomType = value; }
        }
        int totalCountOfRooms;
        private string loc;
        private string roomtype;

        public int TotalCountOfRooms
        {
            get { return totalCountOfRooms; }
            set { totalCountOfRooms = value; }
        }

        public Hotel() { }
        public Hotel(int hotelID, string hotelName, string loc, string totalDeluxer, string priceOfDeluxer, string totalSuperDeluxer, string priceOfSuperDeluxer, string totalSuiter, string priceOfSuiter)
        {
            this.Hotelid = hotelID;
            this.HotelName = hotelName;
            this.Location = loc;
            this.TotalDeluxe = totalDeluxer;
            this.PriceOfDeluxe = priceOfDeluxer;
            this.TotalSuperDeluxe = totalSuperDeluxer;
            this.PriceOfSuperDeluxe = priceOfSuperDeluxer;
            this.TotalSuite = totalSuiter;
            this.PriceOfSuite = priceOfSuiter;
        }
        int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public Hotel(int id,string hotelName,string loc,string roomType,int totalCountOfRooms)
        {
            this.Id=id;
            this.HotelName = hotelName;
            this.Location =loc ;
            this.RoomType= roomType;
            this.TotalCountOfRooms = totalCountOfRooms;
        }

      
    }
}
