﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelDAL
{
    public class CancelBookingDal
    {
        public int updateData(int BookingID, int uid)
        {
            object BookingStatus = 0;

            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = "select BookingStatus from tblReservation where BookingId=@BID";
                command.Parameters.AddWithValue("@BID", BookingID);
                //command.Parameters.AddWithValue("@uid", uid);
                BookingStatus = command.ExecuteScalar();
            }
            if (Convert.ToInt32(BookingStatus) == 1)
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
                {
                    try
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand();
                        command.Connection = connection;
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "sp_Cancel_Reservation";
                        command.Parameters.AddWithValue("@BID", BookingID);
                        command.Parameters.AddWithValue("@uid", uid);
                        command.ExecuteNonQuery();
                        return 1;
                    }
                    catch (Exception e)
                    {

                        System.Diagnostics.Debug.WriteLine(e.Message);
                        return 0;
                    }
                }
            }
            else
            {
                return 0;
            }
        }
    }
}

