﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace HotelDAL
{
    public class HotelDal
    {

        public static int totalRecord1=0;
        public static int noOfRecord1=0; 
        public static DataTable getAllHotelDetails()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_GetAllHotelDetails", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;

            }
        }
        public static DataTable getAllTransactionlDetails()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_getTransactionDetails", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;

            }
        }
        public static DataTable getAllBookinglDetails()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_getBookingReport", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;

            }
        }

        public static DataTable getAllRevenuelDetails()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_getAnnualRevenue", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;

            }
        }

        public static void updateHotel(Hotel h)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_update_tblDisplayRooms_ByHotel_ByRooms", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", h.Id);
                cmd.Parameters.AddWithValue("@HotelName", h.HotelName);
                cmd.Parameters.AddWithValue("@Location", h.Location);
                cmd.Parameters.AddWithValue("@RoomTypeName", h.RoomType);
                cmd.Parameters.AddWithValue("@totalRoomCount", h.TotalCountOfRooms);

                con.Open();
                int result = cmd.ExecuteNonQuery();
            }
        }

        public static DataTable PopulateData(int pageNo, int noOfRecord)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_getHotelByPageSize", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PageNo", pageNo);
                cmd.Parameters.AddWithValue("@NoOfRecord", noOfRecord);

                SqlParameter TotalRecordSP = new SqlParameter("@TotalRecord", System.Data.SqlDbType.Int);
                TotalRecordSP.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(TotalRecordSP);

                DataTable dt = new DataTable();
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                dt.Load(cmd.ExecuteReader());

                int totalRecord = 0;
                if (TotalRecordSP.Value != null)
                {
                    int.TryParse(TotalRecordSP.Value.ToString(), out totalRecord);
                }
                totalRecord1 = totalRecord;
                noOfRecord1 = noOfRecord;
                return dt;


            }
        }

        public static int getTotalRecord1()
        {
            return totalRecord1;
        }

        public static int getNoOfRecord1()
        {
            return noOfRecord1;
        }

        public static void AddHotel(string hotelName, string loc, string totalDeluxe, string totalSuperDeluxe, string totalSuite)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_add_tblHotel_tblDisplayRoom", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                
                cmd.Parameters.AddWithValue("@HotelName",hotelName);
                cmd.Parameters.AddWithValue("@Location",loc);
                cmd.Parameters.AddWithValue("@NoOfDeluxe",totalDeluxe);
                cmd.Parameters.AddWithValue("@NoOfSuperDeluxe",totalSuperDeluxe);
                cmd.Parameters.AddWithValue("@NoOfSuite", totalSuite);

                con.Open();
                int result = cmd.ExecuteNonQuery();
            }
        }

        public static void DeleteHotel(string hotelName, string roomtype)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_deleteHotel_By_RoomType", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@HotelName", hotelName);
                cmd.Parameters.AddWithValue("@roomType", roomtype);
              

                con.Open();
                int result = cmd.ExecuteNonQuery();
            }
        }
    }
}
