﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
namespace HotelDAL
{
    public class FileUtilityDal
    {
        public static StreamWriter generateReport()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_GetAllHotelDetails", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                ds.Tables[0].TableName = "Hotel";
                StringBuilder sb = new StringBuilder();
                string delimiter=",";
                foreach (DataRow hotelRow in ds.Tables["Hotel"].Rows)
                {
                    int hotelId = Convert.ToInt32(hotelRow["HotelID"]);
                    sb.Append(hotelId.ToString() + delimiter);
                    sb.Append(hotelRow["HotelName"].ToString() + delimiter);
                    sb.Append(hotelRow["Location"].ToString() + delimiter);
                    sb.Append(hotelRow["TotalDeluxe"].ToString() + delimiter);
                    sb.Append(hotelRow["PriceOfDeluxe"].ToString() + delimiter);
                    sb.Append(hotelRow["TotalSuperDeluxe"].ToString() + delimiter);
                    sb.Append(hotelRow["PriceOfSuperDeluxe"].ToString() + delimiter);
                    sb.Append(hotelRow["TotalSuite"].ToString() + delimiter);
                    sb.Append(hotelRow["PriceOfSuite"].ToString() + delimiter);
                    sb.Append("\r\n");
                }
                string strFileName = "HotelReport.csv";
                StreamWriter file = new StreamWriter(@"C:\Users\736470\Documents\Visual Studio 2012\Projects\HotelReservation\HotelReservation\Reports\" + strFileName);
                string line ="\"HotelID\",\"HotelName\",\"Location\",\"TotalDeluxe\",\"PriceOfDeluxe\",\"TotalSuperDeluxe\",\"PriceOfSuperDeluxe\",\"TotalSuite\",\"PriceOfSuite\"";
                file.WriteLine(line);
                file.WriteLine(sb.ToString());
                
                file.Close();
                return file;
               
            }
        }
        public static StreamWriter generateTransReport()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_getTransactionDetails", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                ds.Tables[0].TableName = "Transaction";
                StringBuilder sb = new StringBuilder();
                string delimiter = ",";
                foreach (DataRow hotelRow in ds.Tables["Transaction"].Rows)
                {
                    int UId = Convert.ToInt32(hotelRow["UID"]);
                    sb.Append(UId.ToString() + delimiter);
                    sb.Append(hotelRow["Fullname"].ToString() + delimiter);
                    int bookingId = Convert.ToInt32(hotelRow["bookingId"]);
                    sb.Append(bookingId.ToString() + delimiter);
                    sb.Append(hotelRow["Particulars"].ToString() + delimiter);
                    DateTime dt = DateTime.Parse(hotelRow["Date"].ToString());

                    sb.Append(dt.ToString() + delimiter);
                    sb.Append(hotelRow["Amount"].ToString() + delimiter);
                    sb.Append("\r\n");
                }
                string strFileName = "TransactionReport.csv";
                StreamWriter file = new StreamWriter(@"C:\Users\736470\Documents\Visual Studio 2012\Projects\HotelReservation\HotelReservation\Reports\" + strFileName);
                string line = "\"UID\",\"Name\",\"bookingId\",\"Particulars\",\"Date\",\"Amount\"";
                file.WriteLine(line);
                file.WriteLine(sb.ToString());

                file.Close();
                return file;

            }
        }
        public static StreamWriter generateBookingReport()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_getBookingReport", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                ds.Tables[0].TableName = "Booking";
                StringBuilder sb = new StringBuilder();
                string delimiter = ",";
                foreach (DataRow hotelRow in ds.Tables["Booking"].Rows)
                {
                    int UId = Convert.ToInt32(hotelRow["UID"]);
                    sb.Append(UId.ToString() + delimiter);
                    sb.Append(hotelRow["HotelName"].ToString() + delimiter);
                    DateTime dt = DateTime.Parse(hotelRow["Check_In"].ToString());
                    DateTime dt1 = DateTime.Parse(hotelRow["Check_Out"].ToString());

                    sb.Append(dt.ToString() + delimiter);
                    sb.Append(dt1.ToString() + delimiter);
                    int NoOfGuests = Convert.ToInt32(hotelRow["NoOfGuests"]);
                    sb.Append(NoOfGuests.ToString() + delimiter);
                    sb.Append("\r\n");
                }
                string strFileName = "BookingReport.csv";
                StreamWriter file = new StreamWriter(@"C:\Users\736470\Documents\Visual Studio 2012\Projects\HotelReservation\HotelReservation\Reports\" + strFileName);
                string line = "\"UID\",\"HotelName\",\"Check_In\",\"Check_Out\",\"NoOfGuests\"";
                file.WriteLine(line);
                file.WriteLine(sb.ToString());

                file.Close();
                return file;

            }
        }
        public static StreamWriter generateRevenueReport()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_getAnnualRevenue", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                ds.Tables[0].TableName = "Revenue";
                StringBuilder sb = new StringBuilder();
                string delimiter = ",";
                foreach (DataRow hotelRow in ds.Tables["Revenue"].Rows)
                {
                   
                    sb.Append(hotelRow["HotelName"].ToString() + delimiter);
                   
                    int Amount = Convert.ToInt32(hotelRow["Amount"]);
                    sb.Append(Amount.ToString() + delimiter);
                    sb.Append("\r\n");
                }
                string strFileName = "RevenueReport.csv";
                StreamWriter file = new StreamWriter(@"C:\Users\736470\Documents\Visual Studio 2012\Projects\HotelReservation\HotelReservation\Reports\" + strFileName);
                string line = "\"HotelName\",\"Amount\"";
                file.WriteLine(line);
                file.WriteLine(sb.ToString());

                file.Close();
                return file;

            }
        }
        public static DataTable generatePDF(int uid,int bookingId)
        {
            DataTable dt;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_GenerateBill", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@uid",uid);
                cmd.Parameters.AddWithValue("@bookingId", bookingId);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                
                sda.Fill(dt);
               
                dt.Columns[0].ColumnName = "Booking ID";
                dt.Columns[1].ColumnName = "Name";
                dt.Columns[2].ColumnName = "Check-In";
                dt.Columns[3].ColumnName = "Check-Out";
                dt.Columns[4].ColumnName = "Hotel Name";
               
                dt.TableName = "Hotel";
            }
            return dt;
            
        }

        public static DataTable CancelgeneratePDF(int uid, int bookingId)
        {
            DataTable dt;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_generatecancelbill", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UID", uid);
                cmd.Parameters.AddWithValue("@BID", bookingId);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                dt = new DataTable();

                sda.Fill(dt);

                dt.Columns[0].ColumnName = "Booking ID";
                dt.Columns[1].ColumnName = "Name";
                dt.Columns[2].ColumnName = "Check-In";
                dt.Columns[3].ColumnName = "Check-Out";
                dt.Columns[4].ColumnName = "Hotel Name";

                dt.TableName = "Hotel";
            }
            return dt;
        }
    }
}
