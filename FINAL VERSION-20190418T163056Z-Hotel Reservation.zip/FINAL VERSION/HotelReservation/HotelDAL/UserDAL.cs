﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Common;
namespace HotelDAL
{
    public class UserDAL
    {
        public static bool GetUser(string uName, string password)
        {
            bool f = false;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
                using (SqlCommand cmd = new SqlCommand("sp_GetUserByUserAndPass", con))
                {
                    System.Diagnostics.Debug.WriteLine("inside sql");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Uname", uName);
                    cmd.Parameters.AddWithValue("@Password", password);
                    con.Open();
                    SqlDataReader myReader = cmd.ExecuteReader();

                    System.Diagnostics.Debug.WriteLine("\t{0}\t{1}", myReader.GetName(0), myReader.GetName(1));
                    if (myReader.HasRows)
                    {
                        while (myReader.Read())
                            System.Diagnostics.Debug.WriteLine("\t{0}\t{1}", myReader[0], myReader[1]);
                        f = true;
                    }
                    
                }


            }
            catch (SqlException e)
            {

                Console.WriteLine(e.Message);
            }
            return f;
        }

        public static string Getfullname(string uName)
        {
            string user = string.Empty;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_GetFullName", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@uName", uName);
                
                con.Open();
                SqlDataReader myReader = cmd.ExecuteReader();

                System.Diagnostics.Debug.WriteLine("\t{0}", myReader.GetName(0));
                if (myReader.HasRows)
                {
                    while (myReader.Read())
                        user=myReader[0].ToString();
                   
                }

            }
            return user;
        }
        public static User GetUserDetails(string uName)
        {
            User user = new User();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_GetUserDetails", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@uName", uName);

                con.Open();
                SqlDataReader myReader = cmd.ExecuteReader();
                System.Diagnostics.Debug.WriteLine("\t{0}", myReader.GetName(0));
                if (myReader.HasRows)
                {
                    while (myReader.Read())
                    {
                        user.UID = int.Parse(myReader[0].ToString());
                        user.Name = myReader[3].ToString();
                        user.Gender = myReader[4].ToString();
                        user.Uname = myReader[1].ToString();
                        user.Status =Convert.ToBoolean(myReader[5].ToString());
                    }
                }
            }
            return user;
        }
        private static Random RNG = new Random();

        public static string Create16DigitString()
        {
            var builder = new StringBuilder();
            while (builder.Length < 16)
            {
                builder.Append(RNG.Next(10).ToString());
            }
            return builder.ToString();
        }
        public static bool RegisterUser(User u)
        {
            bool f = false;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
                using (SqlCommand cmd = new SqlCommand("sp_RegisterUser", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FullName", u.Name);
                    cmd.Parameters.AddWithValue("@Uname", u.Uname);
                    cmd.Parameters.AddWithValue("@Password", u.Pass);
                    cmd.Parameters.AddWithValue("@gender", u.Gender);
                    cmd.Parameters.AddWithValue("@cardNumber", Create16DigitString());
                    cmd.Parameters.AddWithValue("@City", u.CityName);
                    cmd.Parameters.AddWithValue("@ZipCode", u.Zipcode);
                    cmd.Parameters.AddWithValue("@Country", u.CountryName);
                    cmd.Parameters.AddWithValue("@dater", u.DateOfBirth);
                    con.Open();
                    int result = cmd.ExecuteNonQuery();
                    f = (result == 1) ? true : false;

                }
            }
            catch (Exception ex)
            {

                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            return f; 
        }
    }
}
