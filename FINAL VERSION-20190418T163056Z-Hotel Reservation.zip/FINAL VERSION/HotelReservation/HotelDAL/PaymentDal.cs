﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace HotelDAL
{
    public class PaymentDal
    {
        public int Select(string cardnumber, double amount,int uid)
        {
            object TotalBalance = 0;
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString;
                connection.Open();
                string selectQuery = "select balance from Wallet where cardnumber=@cardnumber and userid=@uid";
                SqlCommand cmd = new SqlCommand(selectQuery, connection);
                cmd.Parameters.AddWithValue("@cardnumber", cardnumber);
                cmd.Parameters.AddWithValue("@amount", amount);
                cmd.Parameters.AddWithValue("@uid", uid);
                //cmd.Parameters.AddWithValue("@expirydate", expirydate);
                //cmd.Parameters.AddWithValue("@cv", cv);

                TotalBalance = cmd.ExecuteScalar();
            }
            if (Convert.ToDouble(TotalBalance) == 0)
            {
                return 2;
            }
            else if (Convert.ToDouble(TotalBalance) < amount)
            {
                return 1;
            }
            else
            {
                using (SqlConnection connection = new SqlConnection())
                {
                    connection.ConnectionString = ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString;
                    connection.Open();
                    string insertQuery = "update wallet set balance=balance-@amount where cardnumber=@cardnumber and userid=@uid";
                    SqlCommand cmd = new SqlCommand(insertQuery, connection);
                    cmd.Parameters.AddWithValue("@cardnumber", cardnumber);
                    cmd.Parameters.AddWithValue("@amount", amount);
                    cmd.Parameters.AddWithValue("@uid", uid);
                    //cmd.Parameters.AddWithValue("@expirydate", expirydate);
                    //cmd.Parameters.AddWithValue("@cv", cv);
                    //cmd.ExecuteNonQuery();
                    double result = cmd.ExecuteNonQuery();
                }
                return 0;
            }
        }
        public bool Insert(int UId, string Particulars, string date1, string time1, string types, double amt, int HotelId, int BookingStatus, DateTime checkIn, DateTime checkOut, int Guests, string RoomTypeName, int NoofRooms, byte[] NationalId, int RoomsID)
        {
            //DateTime Date1 = DateTime.ParseExact(Convert.ToString(Date), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            //DateTime Time1 = DateTime.ParseExact(Convert.ToString(Time), "hh:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
            using (SqlConnection connection = new SqlConnection())
            {
                DateTime Date1 = DateTime.Parse(date1);
                DateTime Time1 = DateTime.Parse(time1);
                connection.ConnectionString = ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString;
                connection.Open();
                string insertQuery = "insert into tblReservation(HotelId,UId,BookingStatus,Check_In,Check_Out,NoOfGuests,RoomType,NoOfRoomsBooked,Amount,NationalID)values (@HotelId,@UId,@BookingStatus,@CheckIn,@CheckOut,@NoofGuests,@RoomId,@NoofRooms,@amount,@imagedata)";
                //string insertQuery = "insert into tblReservation(HotelId,UId,BookingStatus,Check_In,Check_Out,NoOfGuests,RoomType,NoOfRoomsBooked,Amount)values (@HotelId,@UId,@BookingStatus,@CheckIn,@CheckOut,@NoofGuests,@RoomName,@NoofRooms,@amount)";
                SqlCommand cmd = new SqlCommand(insertQuery, connection);
                cmd.Parameters.AddWithValue("@UId", UId);
                cmd.Parameters.AddWithValue("@Particulars", Particulars);
                cmd.Parameters.AddWithValue("@Date1", Date1);
                cmd.Parameters.AddWithValue("@Time1", Time1);
                cmd.Parameters.AddWithValue("@amount", amt);
                cmd.Parameters.AddWithValue("@Type", types);
                cmd.Parameters.AddWithValue("@HotelId", HotelId);
                cmd.Parameters.AddWithValue("@BookingStatus", BookingStatus);
                cmd.Parameters.AddWithValue("@CheckIn", checkIn);
                cmd.Parameters.AddWithValue("@CheckOut", checkOut);
                cmd.Parameters.AddWithValue("@NoofGuests", Guests);
                cmd.Parameters.AddWithValue("@RoomId", RoomsID);
                cmd.Parameters.AddWithValue("@NoofRooms", NoofRooms);
                cmd.Parameters.Add("@imagedata", SqlDbType.Image).Value = NationalId;
                cmd.ExecuteNonQuery();

                string insertQuery3 = "insert into tblAvailability(CheckInDate,CheckOutDate,HotelID,RoomID,NoOfRoomsBooked) values (@CheckIn,@CheckOut,@HotelId,@RoomId,@NoofRooms)";
                SqlCommand cmd4 = new SqlCommand(insertQuery3, connection);
                cmd4.Parameters.AddWithValue("@CheckIn", checkIn);
                cmd4.Parameters.AddWithValue("@CheckOut", checkOut);
                cmd4.Parameters.AddWithValue("@HotelId", HotelId);
                cmd4.Parameters.AddWithValue("@RoomId", RoomsID);
                cmd4.Parameters.AddWithValue("@NoofRooms", NoofRooms);
                cmd4.ExecuteNonQuery();


                string selectQuery = "select top 1 BookingId from tblReservation order by 1 desc";
                SqlCommand cmd2 = new SqlCommand(selectQuery, connection);
                int BookingId = (int)cmd2.ExecuteScalar();

                string insertQuery2 = "insert into tblTransaction(UId,BookingId,Particulars,Date,Time,amount,Type)values (@UId,@BookingId,@Particulars,@Date1,@Time1,@amount,@Type)";
                SqlCommand cmd3 = new SqlCommand(insertQuery2, connection);
                cmd3.Parameters.AddWithValue("@UId", UId);
                cmd3.Parameters.AddWithValue("@BookingId", BookingId);
                cmd3.Parameters.AddWithValue("@Particulars", Particulars);
                cmd3.Parameters.AddWithValue("@Date1", Date1);
                cmd3.Parameters.AddWithValue("@Time1", Time1);
                cmd3.Parameters.AddWithValue("@amount", amt);
                cmd3.Parameters.AddWithValue("@Type", types);
                cmd3.ExecuteNonQuery();
                return true;
            }
        }
    }
}
