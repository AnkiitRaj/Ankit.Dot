﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace HotelDAL
{
    public class RoomsDal
    {
        public static DataTable GetAllRooms()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_GetAllRoomsDetails", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;

            }
        }
    }
}
