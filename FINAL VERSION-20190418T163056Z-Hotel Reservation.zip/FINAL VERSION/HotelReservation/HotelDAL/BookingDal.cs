﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace HotelDAL
{
    public class BookingDal
    {
        public static int totalRecord1;
        public static int noOfRecord1;
        public static DataTable PopulateData(int pageNo, int noOfRecord)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_BookingByPageSize", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PageNo", pageNo);
                cmd.Parameters.AddWithValue("@NoOfRecord", noOfRecord);

                SqlParameter TotalRecordSP = new SqlParameter("@TotalRecord", System.Data.SqlDbType.Int);
                TotalRecordSP.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(TotalRecordSP);

                DataTable dt = new DataTable();
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
               // dt.Load(cmd.ExecuteReader());
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);

                int totalRecord = 0;
                if (TotalRecordSP.Value != null)
                {
                    int.TryParse(TotalRecordSP.Value.ToString(), out totalRecord);
                }
                totalRecord1 = totalRecord;
                noOfRecord1 = noOfRecord;
                return dt;


            }
        }



        public static int getNoOfRecord1()
        {
            return noOfRecord1;
        }

        public static int getTotalRecord1()
        {
            return totalRecord1;
        }
    }
}
