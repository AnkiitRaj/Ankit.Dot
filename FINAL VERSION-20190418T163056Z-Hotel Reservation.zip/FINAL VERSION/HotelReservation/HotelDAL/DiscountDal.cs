﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelDAL
{
    public class DiscountDal
    {
        public static int totalRecord1;
        public static int noOfRecord1;
        public static DataTable getAllDiscountDetails()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            using (SqlCommand cmd = new SqlCommand("sp_getAllDiscount", con))
            {
                System.Diagnostics.Debug.WriteLine("inside sql");
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;

            }
        }

        public static DataTable PopulateData(int pageNo, int noOfRecord)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetAllDiscountByPageSize", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PageNo", pageNo);
                cmd.Parameters.AddWithValue("@NoOfRecord", noOfRecord);

                SqlParameter TotalRecordSP = new SqlParameter("@TotalRecord", System.Data.SqlDbType.Int);
                TotalRecordSP.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(TotalRecordSP);

                DataTable dt = new DataTable();
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                dt.Load(cmd.ExecuteReader());

                int totalRecord = 0;
                if (TotalRecordSP.Value != null)
                {
                    int.TryParse(TotalRecordSP.Value.ToString(), out totalRecord);
                }
                totalRecord1 = totalRecord;
                noOfRecord1 = noOfRecord;
                return dt;
              

            }

        }
        public static int getTotalRecord1()
        {
            return totalRecord1;

        }
        public static int getNoOfRecord1()
        {
            return noOfRecord1;
            
        }

        public static void AddDiscount(string discountCode, string discountPerc)
        {
            int result;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_AddDiscount", con))
                {
                    con.Open();
                    System.Diagnostics.Debug.WriteLine("inside sql");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DiscountCode", discountCode);
                    cmd.Parameters.AddWithValue("@DiscountPerc", discountPerc);
                    result = cmd.ExecuteNonQuery();

                }
            }
            catch (Exception e)
            {

                System.Diagnostics.Debug.WriteLine(e.Message);
            }
        }

        public static void UpdateDiscount(int discountID, string discountCoder, string discountPercr)
        {
           int result;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_UpdateDiscount", con))
                {
                    con.Open();
                    System.Diagnostics.Debug.WriteLine("inside sql");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DiscountID", discountID);
                    cmd.Parameters.AddWithValue("@DiscountCode", discountCoder);
                    cmd.Parameters.AddWithValue("@DiscountPerc", discountPercr);
                    result = cmd.ExecuteNonQuery();

                }
            }
            catch (Exception e)
            {

                System.Diagnostics.Debug.WriteLine(e.Message);
            }
        }


        public static void DeleteDiscount(int discountID)
        {
            int result;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString);
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_Delete_Discount", con))
                {
                    con.Open();
                    System.Diagnostics.Debug.WriteLine("inside sql");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DiscountID", discountID);
                  
                    result = cmd.ExecuteNonQuery();

                }
            }
            catch (Exception e)
            {

                System.Diagnostics.Debug.WriteLine(e.Message);
            }
        }
        public int GetDiscount(string CouponCode)
        {
            int Percent = 0;
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@CouponCode", CouponCode);
                command.CommandText = "select DiscountPerc from tblDiscount where DiscountCode=@CouponCode";
                Percent = Convert.ToInt32(command.ExecuteScalar());
            }
            return Percent;
        }
    }
}
