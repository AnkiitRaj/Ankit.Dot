﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace HotelDAL
{
    public class UserBookingDal
    {
        public static int totalRecord1;
        public static int noOfRecord1;
        public DataSet InsertDetails1(int hid, string checkIn, string checkOut)
        {
            UserBooking sroom = new UserBooking();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@hid", hid);
                command.Parameters.AddWithValue("@checkin", checkIn);
                command.Parameters.AddWithValue("@checkout", checkOut);
                command.CommandText = "select r.RoomTypeName,r.RoomsId,r.Price,dr.ImageId,r.Amenities,r.Description,(select isnull(((sum(totalRoomCount))-(select sum(NoOfRoomsBooked) as booked_rooms from tblAvailability where CheckInDate between @checkin  and @checkout and HotelID=@hid and RoomID=1)),sum(totalRoomCount)) from tblDisplayRoom where HotelID=@hid and RoomID=1 group by Hotelid,RoomID) as AvailableRooms from tblRooms r join tblDisplayRoom dr on r.RoomsID=dr.RoomID join tblHotel h on h.HotelId=dr.HotelID where h.HotelId=@hid and r.RoomsId=1";
                SqlDataAdapter sda = new SqlDataAdapter(command);
                sda.Fill(ds, "RoomDetails");
            }
            return ds;
        }

        public DataSet InsertDetails2(int hid, string checkIn, string checkOut)
        {
            UserBooking sroom = new UserBooking();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@hid", hid);
                command.Parameters.AddWithValue("@checkin", checkIn);
                command.Parameters.AddWithValue("@checkout", checkOut);
                command.CommandText = "select r.RoomTypeName,r.RoomsId,r.Price,dr.ImageId,r.Amenities,r.Description,(select isnull(((sum(totalRoomCount))-(select sum(NoOfRoomsBooked) as booked_rooms from tblAvailability where CheckInDate between @checkin  and @checkout and HotelID=@hid and RoomID=2)),sum(totalRoomCount)) from tblDisplayRoom where HotelID=@hid and RoomID=2 group by Hotelid,RoomID) as AvailableRooms from tblRooms r join tblDisplayRoom dr on r.RoomsID=dr.RoomID join tblHotel h on h.HotelId=dr.HotelID where h.HotelId=@hid and r.RoomsId=2";
                SqlDataAdapter sda = new SqlDataAdapter(command);
                sda.Fill(ds, "RoomDetails");
            }
            return ds;
        }

        public DataSet InsertDetails3(int hid, string checkIn, string checkOut)
        {
            UserBooking sroom = new UserBooking();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@hid", hid);
                command.Parameters.AddWithValue("@checkin", checkIn);
                command.Parameters.AddWithValue("@checkout", checkOut);
                command.CommandText = "select r.RoomTypeName,r.RoomsId,r.Price,dr.ImageId,r.Amenities,r.Description,(select isnull(((sum(totalRoomCount))-(select sum(NoOfRoomsBooked) as booked_rooms from tblAvailability where CheckInDate between @checkin  and @checkout and HotelID=@hid and RoomID=3)),sum(totalRoomCount)) from tblDisplayRoom where HotelID=@hid and RoomID=3 group by Hotelid,RoomID) as AvailableRooms from tblRooms r join tblDisplayRoom dr on r.RoomsID=dr.RoomID join tblHotel h on h.HotelId=dr.HotelID where h.HotelId=@hid and r.RoomsId=3";
                SqlDataAdapter sda = new SqlDataAdapter(command);
                sda.Fill(ds, "RoomDetails");
            }
            return ds;
        }

        public DataSet InsertDetails4(int hid, string checkIn, string checkOut)
        {
            UserBooking sroom = new UserBooking();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@hid", hid);
                command.Parameters.AddWithValue("@checkin", checkIn);
                command.Parameters.AddWithValue("@checkout", checkOut);
                command.CommandText = "select r.RoomTypeName,r.RoomsId,r.Price,dr.ImageId,r.Amenities,r.Description,(select isnull(((sum(totalRoomCount))-(select sum(NoOfRoomsBooked) as booked_rooms from tblAvailability where CheckInDate between @checkin  and @checkout and HotelID=@hid and RoomID=4)),sum(totalRoomCount)) from tblDisplayRoom where HotelID=@hid and RoomID=4 group by Hotelid,RoomID) as AvailableRooms from tblRooms r join tblDisplayRoom dr on r.RoomsID=dr.RoomID join tblHotel h on h.HotelId=dr.HotelID where h.HotelId=@hid and r.RoomsId=4";
                SqlDataAdapter sda = new SqlDataAdapter(command);
                sda.Fill(ds, "RoomDetails");
            }
            return ds;
        }

        public DataSet GetHotelName()
        {
            DataSet ds = new DataSet();
            //SortedDictionary<int, string> sd = new SortedDictionary<int, string>();
            //Dataset preferred due to inavailability
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = "select HotelId,HotelName from tblHotel";
                SqlDataAdapter sda = new SqlDataAdapter(command);
                sda.Fill(ds, "Hotel");
            }
            return ds;
        }

        public string GetLocation(int hid)
        {
            string Location = string.Empty;
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@hid", hid);
                command.CommandText = "select Location from tblHotel where HotelId=@hid";
                Location = command.ExecuteScalar().ToString();

            }
            return Location;
        }
         
        public static DataTable PopulateData(int pageNo, int noOfRecord,int uid)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_BookingHistoryByPageSizeUser", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PageNo", pageNo);
                cmd.Parameters.AddWithValue("@NoOfRecord", noOfRecord);
                cmd.Parameters.AddWithValue("@uid", uid);
                SqlParameter TotalRecordSP = new SqlParameter("@TotalRecord", System.Data.SqlDbType.Int);
                TotalRecordSP.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(TotalRecordSP);

                DataTable dt = new DataTable();
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // dt.Load(cmd.ExecuteReader());
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);

                int totalRecord = 0;
                if (TotalRecordSP.Value != null)
                {
                    int.TryParse(TotalRecordSP.Value.ToString(), out totalRecord);
                }
                totalRecord1 = totalRecord;
                noOfRecord1 = noOfRecord;
                return dt;


            }
        }
        public static int getNoOfRecord1()
        {
            return noOfRecord1;
        }

        public static int getTotalRecord1()
        {
            return totalRecord1;
        }

        public static int getBookingAmt(int BookingID)
        {
            int amount = 0;
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyProjectConnection"].ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@BookingID", BookingID);
                command.CommandText = "select amount from tblReservation where BookingId=@BookingID";
                amount = Convert.ToInt32(command.ExecuteScalar());

            }
            return amount;
        }
    }
}
