﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class signin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(@"data source=PC399122\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=HRS");
            SqlCommand com = new SqlCommand();
            string userID = Request.Params["userId"].ToString();
            com.CommandText = "select upassword from UserMaster where userId=@userID";
            SqlParameter[] search = new SqlParameter[1];
            search[0] = new SqlParameter("@userid", userID);
            string pass = Request.Params["psw"].ToString();
            com.Parameters.AddRange(search);
            com.Connection = con;
            con.Open();
            string password = System.Text.ASCIIEncoding.ASCII.GetString((byte[])com.ExecuteScalar());
            if (password.Equals(pass))
            {
                Response.Write("<script>alert('You're Logged In!!')</script><script>window.location.href ='http://localhost:58122/front_page.aspx'</script>");
            }
            else
            {
                Label1.Text = "Invalid Username or Password";
                Label1.ForeColor = System.Drawing.Color.Red;  
               
            }
            con.Close();
        }
        catch
        {
            Label1.Text = "Invalid Username or Password";
            Label1.ForeColor = System.Drawing.Color.Red;  
            //Response.Write("<script>alert('Incorrect User ID PASSWORD')</script><script>window.location.href ='signin.aspx'</script>");
        }
    }
}