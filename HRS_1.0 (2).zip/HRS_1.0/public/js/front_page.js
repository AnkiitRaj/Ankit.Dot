﻿$(document).ready(function () {
    $("#checkin").datepicker({
        numberOfMonths: 1,
        minDate: 0,
        onSelect: function (selected) {
            $("#checkout").datepicker("option", "minDate", selected)
        }
    });

    $("#checkout").datepicker({
        numberOfMonths: 1,
        onSelect: function (selected) {
            $("#checkin").datepicker("option", "maxDate", selected)
        }
    });
});

        $(function () {
            $("#checkin").datepicker();
        });
