﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class signup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    
  }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"data source=PC399122\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=HRS");
        string userID = Request.Params["userID"].ToString();
        SqlCommand com = new SqlCommand();
        com.CommandText = "select count(userId) from UserMaster where userId=@userID";
        SqlParameter[] search = new SqlParameter[1];
        search[0] = new SqlParameter("@userid", userID);
        com.Parameters.AddRange(search);
        com.Connection = con;
        con.Open();
        int count = Convert.ToInt32(com.ExecuteScalar());
            
            if (count == 0)
            {
                com.Parameters.Clear();
                com.CommandText = "insert into UserMaster values(@fname,@lname,@phoneNumber,@userId,@upassword)";
                com.Connection = con;
                SqlParameter[] param = new SqlParameter[5];
                param[0] = new SqlParameter("@fname", SqlDbType.VarChar);
                param[1] = new SqlParameter("@lname", SqlDbType.VarChar);
                param[2] = new SqlParameter("@phoneNumber", SqlDbType.VarChar);
                param[3] = new SqlParameter("@userId", SqlDbType.VarChar);
                param[4] = new SqlParameter("@upassword", SqlDbType.VarBinary);
                param[0].Value = Request.Params["fname"].ToString();
                param[1].Value = Request.Params["lname"].ToString();
                param[2].Value = Request.Params["phoneNumber"].ToString();
                param[3].Value = Request.Params["userID"].ToString();
                string sp = Request.Params["psw"].ToString();
                string s1 = Request.Params["psw-repeat"].ToString();
                if (sp.Equals(s1))
                {
                    byte[] array = System.Text.Encoding.ASCII.GetBytes(sp);
                    param[4].Value = array;
                    com.Parameters.AddRange(param);                    
                    com.ExecuteNonQuery();                   
                    Response.Write("<script>alert('Register SucessFully')</script><script>window.location.href ='http://localhost:58122/front_page.aspx'</script>");
                }

                else
                {
                    con.Close();
                    Response.Write("<script></script><script>alert('PassWord Mismatch')window.location.href ='http://localhost:58122/signup.aspx'</script>");
                }
            }

            else
            {
                con.Close();
                Label1.Text = "User Already Exists";
                Label1.ForeColor = System.Drawing.Color.Red;
            }
        
    }
}
