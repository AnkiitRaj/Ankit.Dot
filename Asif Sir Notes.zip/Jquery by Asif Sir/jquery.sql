use sales_proj;

create table myuser
(
userid int identity primary key,
name varchar(100) not null,
gender varchar(10) not null,
dob datetime not null
);
alter table myuser
add city varchar(100) not null

select * from myuser;