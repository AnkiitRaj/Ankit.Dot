use sales_proj;

select * from customer;
select * from item;

GO
ALTER PROC InsertItem(@name varchar(30), @rate money, @qoh int=10)
AS
BEGIN
BEGIN TRY
INSERT INTO item(iname,irate,iqoh) values(@name,@rate,@qoh)
declare @id int
SELECT @id=max(iid) FROM item
print 'product added successfully'
print 'product id is '+convert(varchar(10),@id)
end try
begin catch
print 'item not added due to the following reason'
print error_message()
end catch
end