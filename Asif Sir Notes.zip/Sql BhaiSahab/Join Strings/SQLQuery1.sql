CREATE TABLE customer
(
cid int identity primary key,
cname varchar(50) not null,
cdob datetime not null,
check(round(DATEDIFF(dd,cdob,getdate())/365.25,0)>=18),
cstatus varchar(3) check(cstatus in ('sc','nsc')) not null,
ccity varchar(50) default 'kolkata' not null,
cout money default 0 not null
);

INSERT INTO CUSTOMER(CNAME,CDOB,CSTATUS)
VALUES('RAVI','10/12/1999','NSC');

SELECT * FROM CUSTOMER
GO
ALTER PROC INSERTCUST @NAME VARCHAR(30),@DOB DATETIME, @CITY VARCHAR(30)='KOLKATA'
AS
BEGIN
DECLARE @STATUS VARCHAR(30)
IF(round(DATEDIFF(dd,@DOB,getdate())/365.25,0)>=60)
 SET @STATUS='SC'
 ELSE
 SET @STATUS='NSC'
 BEGIN TRY
 INSERT INTO  CUSTOMER(CNAME,CDOB,CSTATUS,CCITY)
 VALUES(@NAME,@DOB,@STATUS,@CITY);
 PRINT 'CUSTOMER ADDED SUCCESSFULLY!!'
 END TRY
 BEGIN CATCH
 PRINT 'CUSTOMER NOT ADDED DUE TO THE FOLLOWING REASON'
 PRINT ERROR_MESSAGE();
 END CATCH
END;

EXEC INSERTCUST 'AMITAVA','01-01-2004';

CREATE TABLE item
(
iid int identity primary key,
iname varchar(50) not null,
irate money not null check(irate>0),
iqoh int not null default 10 check(iqoh>=0)
);

go
ALTER PROC INSERTITEM(@NAME VARCHAR(30), @RATE MONEY, @QOH INT=10)
AS
BEGIN
BEGIN TRY
INSERT INTO item(iname,irate,iqoh) VALUES (@NAME, @RATE, @QOH)
declare @id int
SELECT @id=max(iid) FROM item
PRINT 'PRODUCT ADDED SUCCESSFULLY!!'
PRINT 'PRODUCT ID IS ' +convert(varchar(10),@id)
END TRY
BEGIN CATCH
PRINT 'ITEM NOT ADDED DUE TO THE FOLLOWING REASON'
PRINT ERROR_MESSAGE();
END CATCH
END;

EXEC INSERTITEM 'pen',160.66,15
EXEC INSERTITEM 'towel',0,-2

SELECT * FROM ITEM;

CREATE TABLE SALES
(
inv INT IDENTITY PRIMARY KEY,
cid INT REFERENCES customer(cid) not null,
dos datetime not null default getdate()
);

CREATE TABLE  sales_details
(
inv int references sales(inv) not null,
iid int references item(iid) not null,
qsold int not null check(qsold>0),
primary key (inv,iid)
);
GO
alter PROC MyTrans(@cid int, @iid int, @quantity int)
AS
BEGIN
DECLARE @q int
SELECT @q=iqoh FROM item WHERE iid=@iid;
if(@q<@quantity)
BEGIN
PRINT 'Out of Stock'
END
ELSE
BEGIN
BEGIN TRY
INSERT INTO sales(cid) VALUES(@cid);
DECLARE @sid int
SELECT @sid = max(inv) FROM sales
INSERT INTO sales_details(inv,iid,qsold) VALUES(@sid,@iid,@quantity)
UPDATE item SET iqoh=iqoh-@quantity WHERE iid=@iid;
UPDATE customer SET cout=cout+((SELECT irate FROM item WHERE iid=@iid)*@quantity) WHERE cid=@cid
PRINT 'Transaction Successfully Completed...';
PRINT 'Your Invoice Number is ' +Convert(char(3),@sid)
END TRY
BEGIN CATCH
PRINT 'Transaction not successfull because ...'
PRINT ERROR_MESSAGE()
END CATCH
END
END;

SELECT * FROM sales;
SELECT * FROM sales_details;
SELECT * FROM item;
SELECT * FROM customer;

EXEC MyTrans 1,2,3;

SELECT * FROM customer;


ALTER PROC usp_GETCustomerOutstanding (@id int)
AS
BEGIN
DECLARE @out money
SELECT @out  = cout FROM customer WHERE cid=@id;
PRINT 'Customer OutStanding: '+ Convert(varchar(30),@out);
END


EXEC usp_GETCustomerOutstanding 1;

ALTER PROC usp_GETCustomerOutstanding (@id int, @r money output)
-- with ENCRYPTION
AS
BEGIN
SELECT @r  = cout FROM customer WHERE cid=@id;
if @r is null
PRINT 'no such customer exists'
END

DECLARE @K int
EXEC usp_GetCustomerOutstanding 1, @k output
PRINT @k

SELECT * FROM sales;

SELECT TEXT FROM syscomments WHERE
id=(SELECT id FROM sysobjects WHERE name='usp_GetCustomerOutstanding');

ALTER FUNCTION Tax(@i money) RETURNS money
AS
BEGIN
RETURN round(0.1*@i,2)
END
GO
PRINT dbo.Tax(500)

SELECT cid,cname,cout,dbo.tax(cout) Tax FROM customer;

SELECT cid,cdob,dbo.age(cdob) age FROM customer
SELECT * FROM customer;

ALTER FUNCTION Age(@i date) returns int
AS
BEGIN
DECLARE @a int
SET @a = DATEDIFF(year,@i,getdate());
RETURN @a
END


ALTER FUNCTION Age(@dob datetime) returns int
AS
BEGIN
return round(datediff(dd,@dob,getdate())/365.25,0)
END
GO
SELECT cid,cdob,dbo.age(cdob) age FROM customer
SELECT * FROM customer;

ALTER PROC usp_GetDiscount(@id int, @cid int)
AS
BEGIN
DECLARE @cout money
SELECT @cout = cout FROM customer WHERE cid=@cid;
SET @cout = @cout-((@cout*@id)/100);
UPDATE customer SET cout = @cout WHERE cid=@cid;
SELECT * FROM customer WHERE cid=@cid;
END

EXEC usp_GetDiscount 5,6;

select * from customer;
UPDATE customer SET cout=30 where cid=5;


go
CREATE FUNCTION getCustomerByCity(@city varchar(30))
returns table
as
return
(
SELECT * FROM customer WHERE ccity=@city
);
GO
SELECT * FROM dbo.getCustomerByCity('Kolkata');


ALTER function checkcustomer(@cid int) returns bit
as
begin
declare @id int
select @id=cid from customer where cid=@cid
if @id is null 
return 0

return 1
end

print dbo.checkcustomer(15);

select * from item;

ALTER FUNCTION checkitem(@iid int) returns bit
AS
BEGIN
DECLARE @id int
SELECT @id=iid FROM item WHERE iid=@iid
if @id is null
return 0

return 1
END

print dbo.checkitem(1);


CREATE FUNCTION checkstock(@iid int, @quantity int) returns bit
AS
BEGIN
DECLARE @q int
select @q=iqoh FROM item WHERE iid=@iid
if @q<@quantity
return 0

return 1
end

PRINT (dbo.checkstock(4,100))

select * from item;


ALTER PROC MyTrans(@cid int, @iid int, @quantity int)
AS
BEGIN 
	if(dbo.checkcustomer(@cid)=0)
	BEGIN
	PRINT 'Not a valid customer'
	RETURN
	END
	if(dbo.checkitem(@iid)=0)
	BEGIN
	PRINT 'Not a valid Item'
	RETURN
	END
	if(dbo.checkstock(@iid,@quantity)=0)
	BEGIN
	PRINT 'Out of stock'
	RETURN
	END
	BEGIN TRY
INSERT INTO sales(cid) VALUES(@cid);
DECLARE @sid int
SELECT @sid = max(inv) FROM sales
INSERT INTO sales_details(inv,iid,qsold) VALUES(@sid,@iid,@quantity)
UPDATE item SET iqoh=iqoh-@quantity WHERE iid=@iid;
UPDATE customer SET cout=cout+((SELECT irate FROM item WHERE iid=@iid)*@quantity) WHERE cid=@cid
PRINT 'Transaction Successfully Completed...';
PRINT 'Your Invoice Number is ' +Convert(char(3),@sid)
END TRY
BEGIN CATCH
PRINT 'Transaction not successfull because ...'
PRINT ERROR_MESSAGE()
END CATCH
END;

SELECT * FROM sales;
SELECT * FROM sales_details;
SELECT * FROM item;
SELECT * FROM customer;


EXEC MyTrans 1,1,1;

-- trigger

ALTER TRIGGER testTrigger ON customer AFTER INSERT, update, delete
AS
PRINT 'Trigger Fired...'
SELECT * FROM inserted
SELECT * FROM deleted
GO

DROP TRIGGER testTrigger;
INSERT INTO customer(cname, cdob, cstatus,ccity,cout)
VALUES('ABC','12-12-1998','sc',DEFAULT,default)

UPDATE customer SET cout=cout+10

DELETE FROM customer WHERE cid=16
EXEC MyTrans 5,2,3

GO
CREATE TRIGGER InsertTrigger ON Customer AFTER INSERT
AS
DECLARE @status char(3)
DECLARE @dob datetime
SELECT @dob=cdob FROM inserted;
IF(round(DATEDIFF(dd,@dob,getdate())/365.25,0)>=60)
 update customer SET cstatus='sc' WHERE cid=(SELECT cid from inserted)
 ELSE
 update customer SET cstatus='nsc' WHERE cid=(SELECT cid FROM inserted)
GO
INSERT INTO customer(cname, cdob, cstatus,ccity,cout)
VALUES('YASH','12-12-1998','sc',DEFAULT,default)

select * from customer;

UPDATE customer SET cstatus='nsc';

GO
create trigger UpdateTrigger ON customer AFTER update
AS
if(update(cstatus))
BEGIN
PRINT 'sorry!!! you cannot update cstatus directly'
PRINT 'Contact your system admin...'
RETURN
END

GO
ALTER TRIGGER UpdateTrigger ON customer AFTER update
AS
if(update(cstatus))
BEGIN 
RAISERROR('Update Invalid.. Contact SA', 16,1)
ROLLBACK TRAN
END

GO
ALTER TRIGGER UpdateTrigger ON customer AFTER update
AS
if(update(cstatus))
BEGIN 
RAISERROR('Update Invalid.. Contact SA', 16,1)
ROLLBACK TRAN
END
if(update(cdob))
DECLARE @dob datetime
SELECT @dob=cdob FROM inserted;
IF(round(DATEDIFF(dd,@dob,getdate())/365.25,0)>=60)
 update customer SET cstatus='sc' WHERE cid=(SELECT cid from inserted)
 ELSE
 update customer SET cstatus='nsc' WHERE cid=(SELECT cid FROM inserted)
GO

UPDATE customer SET cdob='01-01-1989' WHERE cid=12;

SELECT * FROM CUSTOMER;

GO
CREATE TRIGGER AfterOfficeHours ON customer FOR insert,update,delete
AS
DECLARE @d datetime
SET @d=GetDate()
if(DATEPART(MI,@d)>=54)
BEGIN
RAISERROR ('NO modification After Office Hours',16,1)
ROLLBACK TRAN
END

DELETE FROM customer WHERE cname='RAJ' cid=1;

SELECT * FROM customer;

create table empEarnings
(
empid int primary key,
salary int,
wage int,
comm int,
)
SELECT * FROM empEarnings;
INSERT INTO empEarnings values(1,10000,null,null);
INSERT INTO empEarnings values(2,null,5000,null);
INSERT INTO empEarnings values(3,null,null,1000);


select empid,case
WHEN salary is not null then salary
WHEN wage is not null then wage
WHEN comm is not null then comm
end earnings FROM empEarnings;

SELECT empid,coalesce(salary,wage,comm) earnings FROM empEarnings;

SELECT * FROM dept;

CREATE VIEW v1 AS
SELECT deptno, dname, loc
FROM dept WHERE loc="DALLAS'

-- VIEWS

CREATE TABLE t1
(
t1id int primary key,
tname varchar(10)
);

INSERT INTO t1 VALUES(1,'aaa');
INSERT INTO t1 VALUES(2,'bb');
INSERT INTO t1 VALUES(3,'cc');

SELECT * FROM t1;

CREATE TABLE t2
(
t2id int primary key,
t11id int,
t2name varchar(30),
foreign key(t11id) references t1(t1id)
);

INSERT INTO t2 VALUES(1,1,'KKK');
INSERT INTO t2 VALUES(2,1,'JJJ');
INSERT INTO t2 VALUES(3,2,'PPP');
INSERT INTO t2 VALUES(4,3,'ZZZ');

SELECT * from t1;
GO
CREATE VIEW myview as 
SELECT t1id, tname, t2id,t11id,t2name
FROM t1 JOIN t2 on t1.t1id=t2.t11id;
GO
INSERT INTO myview(t1id,tname,t2id,t11id,t2name) VALUES (5,'dd',6,5,'AXA')
GO
CREATE trigger viewTrig ON myview INSTEAD OF INSERT, update, delete
AS
INSERT INTO t1 SELECT t1id, tname from inserted;
INSERT INTO t2 SELECT t2id,t11id FROM inserted;
