select * from emp;
select hiredate,year(curdate())-year(hiredate) period from emp;
select hiredate, round(datediff(curdate(),hiredate)/365.25,0) lemp from emp;
select hiredate, adddate(hiredate,interval 1 day) newdate from emp;
select hiredate, adddate(hiredate,interval '1-1' year_month) from emp;

-- JOINS -------------------------------

select * from emp;
select e.name, d.name, e.sal, s.grade from
emp e join dept d on e.deptno=d.deptno join
salgrade s on e.sal between s.losal and s.hisal;

select * from emp;
insert into emp values(7000,'RAJ','MANAGER',
7839,'1986-12-12',3400,null,null);

select dname from dept;

select e.ename,d.dname from emp e left join dept d
on e.deptno=d.deptno
union
select e.ename,d.dname from emp e right join dept d
on e.deptno=d.deptno;

-- GROUP FUNCTIONS (its ignore null value except count(*)) 

select count(*), sum(sal), avg(sal), min(sal), max(sal)
from emp;

select count(*), count(sal), count(comm) from emp;

select job,sum(sal) from emp group by job
order by sum(sal) desc;

SELECT deptno, sum(sal) from emp
where deptno is not null
group by deptno having sum(sal)>9000 order by deptno;

select d.dname,sum(e.sal) from emp e join
dept d on e.deptno=d.deptno and d.dname is not null
group by d.dname having sum(e.sal)>9000
order by d.dname;

SET sql_mode = 'ONLY_FULL_GROUP_BY';

select * from emp;

select year(hiredate), monthname(hiredate), count(empno)
from emp group by year(hiredate), monthname(hiredate) having count(empno)>1
order by year(hiredate), monthname(hiredate);

select ename from emp
where sal=(select min(sal) from emp); -- nested query

select ename, sal from emp
    where sal >=(select max(sal) from emp
    where sal < (select max(sal) from emp))
    order by sal desc; -- highest two salary emp
    
select * from emp order by sal desc limit 2; -- sir method: hightest two salary emp

select * from emp where deptno in
(select deptno from dept where loc in ('DALLAS','CHICAGO'));

SELECT grade, ename from emp, salgrade group by grade, ename having grade in(1,2);

select e.* from emp e join salgrade s
on e.sal between s.losal and s.hisal
and s.grade in (2,3);

select * from emp where sal >=any
(select losal from salgrade where grade in (2,3))
and sal<=any
(select hisal from salgrade where grade in (2,3));

select job from emp group by job
order by sum(sal) asc limit 1;

select * from emp where
sal>(select avg(sal) from emp);

select * from emp where
sal>any(select avg(sal) from emp group by job);


SELECT * FROM dept;

CREATE VIEW v1 AS
SELECT deptno, dname, loc
FROM dept WHERE loc='DALLAS';

SELECT * FROM v1;

DROP VIEW v1;
CREATE TABLE dept1 as SELECT * FROM dept;
CREATE TABLE dept2 as SELECT * FROM dept
WHERE 1=2;

-- WITHOUT CHECK OPTION VIEW
CREATE VIEW dallasView
as
SELECT * FROM dept1 WHERE loc='dallas';

SELECT * FROM dallasView;
SELECT * FROM dept1;

INSERT INTO dallasview VALUES(50,'abc','dallas');
INSERT INTO dallasview VALUES(60,'def','boston');
INSERT INTO dallasview VALUES(70,'ghi','dallas');

-- WITH CHECK OPTION
ALTER VIEW dallasView
as
SELECT * FROM dept1 WHERE loc='dallas'
with check option;

CREATE VIEW v1 AS
SELECT e.ename,d.dname FROM emp e JOIN dept d
ON e.deptno=d.deptno;

SELECT * FROM v1;

INSERT INTO v1(ename,dname) VALUES('AAAA','RESEARCH');

CREATE TABLE t1
(
t1id int primary key,
tname varchar(10)
);

INSERT INTO t1 VALUES(1,'aaa');
INSERT INTO t1 VALUES(2,'bb');
INSERT INTO t1 VALUES(3,'cc');

SELECT * FROM t1;

CREATE TABLE t2
(
t2id int primary key,
t11id int,
t2name varchar(30),
foreign key(t11id) references t1(t1id)
);

INSERT INTO t2 VALUES(1,1,'KKK');
INSERT INTO t2 VALUES(2,1,'JJJ');
INSERT INTO t2 VALUES(3,2,'PPP');
INSERT INTO t2 VALUES(4,3,'ZZZ');

SELECT * from t2;

CREATE VIEW myview as 
SELECT t1id, tname, t2id,t11id,t2name
FROM t1 JOIN t2 on t1.t1id=t2.t11id;

SELECT * FROM myview;


-- INDIVIDUALLY WE CAN ADD INTO VIEW BUT CANNOT ADD TOGETHER
INSERT INTO myview(t1id, tname) VALUES(5,'dd');
INSERT INTO myview(t2id,t11id,t2name) VALUES(6,5,'AZAZ');

desc emp;
desc emp1;
CREATE TABLE emp1 as SELECT * FROM emp;

SELECT * FROM emp where ename='KING';

create index empind on emp(ename);