﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class rectangle
    {
        public void area(int x, int y)
        {
            Console.WriteLine("Area of Rectangle : "+ x*y);
        }
    }
    class square
    {
        public void area(int x)
        {
            Console.WriteLine("Area of Square : "+ x*x);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            rectangle r = new rectangle();
            r.area(2, 3);
            square s = new square();
            s.area(2);
        }
    }
}
