﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssociationDemo
{
    class Dependent
    {
        public Dependent(string n)
        {
            name = n;
        }
  
    }
    class Employee
    {
        public string empname { get; set; }
        public Event[] myevent;

        public int index = 0;
        public Employee()
        {
            myevent = new Event[3];
            mydependent = new Dependent[5];

        }
        public Employee(string name):this()
        {
            empname = name;
        }
        public Employee(string name, Event e):this(name)
        {
            AddToEvent(e);
        }
        public void AddDependent(string name)
        {
            if(countdep< mydependent.Length)
            {
                my dependent[countdep] = new Dependent(name);
            }
        }
        public void AddToEvent(Event e)
        {
            if (index < myevent.Length)
            {
                myevent[index] = e;
                index++;
            }
        }
    }
    class Event
    {
        public string eventName { get; set; }
        public Employee[] registeredEmployee; //Association
        int index = 0;
        public Event()
        {
            registeredEmployee = new Employee[3];
        }
        public Event(string name)
            : this()
        {
            eventName = name;
        }
        public Event(string name, Employee e)
            : this(name)
        {
            RegisteredEmployee(e);
        }
        public void RegisterEmployee(Employee e)
        {
            if (index < registeredEmployee.Length)
            {
                registeredEmployee[index] = e;
                index++;
            }
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Event[] AllEvents = new Event[5];
            AllEvents[0] = new Event("E1");
            AllEvents[1] = new Event("E2");
            AllEvents[2] = new Event("E3");
            AllEvents[3] = new Event("E4");
            AllEvents[4] = new Event("E5");

            Employee[] AllEmp = new Employee[5];
            AllEmp[0] = new Employee("Raj", AllEvents[0]);
            AllEmp[1] = new Employee("Rahul", AllEvents[1]);
            AllEmp[2] = new Employee("Amit", AllEvents[0]);
            AllEmp[3] = new Employee("Alisha", AllEvents[1]);
            AllEmp[4] = new Employee("Jeevan", AllEvents[2]);
            DisplayEmployeeAndThierEvents(AllEmp);
            Console.ReadKey();
        }

        static void DisplayEmployeeAndThierEvents(Employee[] AllEmp)
        {
            foreach (Employee emp in AllEmp)
            {
                Console.WriteLine(emp.empname);
                Console.WriteLine("*******************");
                foreach (Event e in emp.myevent)
                {
                    if (e != null)
                    {
                        Console.WriteLine(e.eventName);

                    }
                }
            }
        }
    }
}