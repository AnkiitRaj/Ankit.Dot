﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            /*ArrayList a1 = new ArrayList();
            for (int i = 0; i < 10; i++)
            {
                a1.Add(i + 10);
            }
            for (int i = 0; i < 10; i++)
            {
                a1.Add("A" +i);
            }
            for (int i = 0; i < a1.Count; i++)
            {
                Console.Write(a1[i] + ",");
            }
            Console.WriteLine("\n*************************");
            Console.WriteLine("\n*************************");
            Console.WriteLine("Enter name separated by Comma");
            string[] str = Console.ReadLine().Split(',');
            a1.AddRange(str);
            foreach(object i in a1)
            {
                string result = "";
                if (i is int)
                {
                    result = (((int)i) / 2).ToString();
                }
                else if (i is string)
                {
                    result = ((string)i).ToString();
                   // result = ((string)i) + "B";
                }
                Console.Write(result + ",");
            }
            Console.WriteLine("\n*****************************");
            Console.Write("Enter a value to search :");
            object s = Console.ReadLine();
            if (a1.Contains(s))
            {
                Console.WriteLine("Found" + a1.IndexOf(s));
                a1.Remove(s);
            }
            else
                Console.WriteLine("Not Found");
            Console.WriteLine("Capacity:" + a1.Capacity);
            Console.WriteLine("Count:" + a1.Count);
            a1.Clear();
            Console.WriteLine("Capacity:" + a1.Capacity);
            Console.WriteLine("Count:" + a1.Count);*/
            string str = Console.ReadLine();
            IEnumerable ie = str.Distinct();
            IEnumerator ien = ie.GetEnumerator();
            while (ien.MoveNext())
            {
                Console.Write(ien.Current);
            }
        }
        static void DisplayList(ArrayList list)
        {
            foreach (object o in list)
            {
                Console.Write(o + ",");
            }
            Console.WriteLine();
        }
    }
}
