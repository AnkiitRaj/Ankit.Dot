﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeDependentConsoleApp
{
   public abstract class Employee
    {
       public string name { get; set; }
       public int age { get; set; }
       public Employee()
       {
           Console.WriteLine("Employee 0 arg . . . ");
       }
       public Employee(string name, int age)
       {
           Console.WriteLine("Employee 2 arg... ");
           this.name = name;
           this.age = age;
           this.salary = salary;
       }

    }
   public class SalaryEmployee : Employee
   {
       public SalaryEmployee()
       {
           Console.WriteLine("SEMployee 0 arg.. ");
       }
       public SalaryEmployee(string name, int age, double Salary):base(name,age) //Note: (IMPORTANT)
       {
           Console.WriteLine("SEMPloyee 3 arg.. ");
           this.earnings = salary;
       }
       //public double salary { get; set; }
       private double Earnings;
       public override double earnings
       {
           get { return Earnings; }
           set { earnings = value; }
       }
   }
   public class WagedEmployee : Employee
   {
       public WagedEmployee()
       {
           Console.WriteLine("WEmployee 0 args.... ");
       }
       public WagedEmployee(string name, int age, double wage):base(name,age) //Note.. (IMPORTANT)
       {
           Console.WriteLine("WEMploye 1 arg.. ");
           this.earnings = wage;
       }
      // public double wage { get; set; }
       private double Earnings;
       public override double earnings
       {
           get { return Earnings; }
           set { earnings = value; }
       }
   }

}
