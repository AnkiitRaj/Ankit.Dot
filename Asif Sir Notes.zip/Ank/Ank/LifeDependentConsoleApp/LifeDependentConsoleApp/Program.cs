﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeDependentConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. Animal ");
            Console.WriteLine("2. Dog ");
            Console.WriteLine("3. Cat ");
            Console.Write("Enter the animal choice : ");
            int choice = int.Parse(Console.ReadLine());
            Animal a = null;
            switch (choice)
            {
                case 1:
                    a = new Animal();
                    break;
                case 2:
                    a = new Dog();
                    break;
                case 3:
                    a = new Cat();
                    break;
            }
            Console.WriteLine(a.name());
            Console.WriteLine(a.food());
            Console.WriteLine(a.shelter());
       }
    }
}