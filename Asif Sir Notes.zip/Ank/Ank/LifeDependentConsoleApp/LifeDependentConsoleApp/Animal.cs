﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeDependentConsoleApp
{
    public class Animal
    {
        public virtual string name() { return "Animal"; } // virtual --->>> overriding
        public virtual string shelter() { return "Animal Shelter"; }
        public virtual string food() { return "Animal Food"; }

    }
    public class Dog : Animal {
        public override string name() { return "Dog"; }
        public override string shelter() { return "Kennel"; }
        public override string food() { return "Pedigree"; }
    
    }
    public class Cat : Animal {
        public override string name() { return "Cat"; }
        public override string shelter() { return "Someone's Home"; }
        public override string food() { return "Fish"; }
    }
}
