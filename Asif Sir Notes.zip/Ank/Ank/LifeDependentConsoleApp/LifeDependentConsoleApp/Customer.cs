﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeDependentConsoleApp
{
    class Customer
    {
        private static int customerCount;
        private int cid;
        // property procedure
        public int Cid
        {
            get { return cid; }
            //set { cid = value; }
        }

        private string name;
        // property procedure
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string city;
        // property procedure
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        private DateTime dob;
        // property procedure
        public DateTime Dob
        {
            get { return dob; }
            set
            {
                DateTime minAge = DateTime.MinValue;
                TimeSpan ts = DateTime.Today - value;
                DateTime age = minAge.Add(ts);
                if (age.Year - 1 < 18 || age.Year - 1 > 60)
                    dob = DateTime.MinValue;
                else
                dob = value;
            }
        }

        private string email;
        // property procedure
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        private double outstanding;
        // property procedure
        public double Outstanding
        {
            get { return outstanding; }
            //set { outstanding = value; }
        }
        private Customer()
        {
            Console.WriteLine("0 arg Constructor");
            customerCount++;
            cid = customerCount;
        }
        public Customer(string name, string city, DateTime dob, string email):this()
        {
            Console.WriteLine("4 args Constructor");
            Name = name;
            City = city;
            Dob = dob;
            Email = email;
        }
        public Customer(string name, DateTime dob, string email) :
            this(name, "Kol", dob, email)
        {
            Console.WriteLine("3 args Constructor");
        }


    }
}
