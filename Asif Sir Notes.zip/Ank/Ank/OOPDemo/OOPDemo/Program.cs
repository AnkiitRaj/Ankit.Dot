﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo
{
    public class Employee : IComparable
    {
        public string name { get; set; }
        public DateTime dob { get; set; }
        public double sal { get; set; }
        public Employee(string name, DateTime dob, double sal)
        {
            this.name = name;
            this.dob = dob;
            this.sal = sal;
        }

        public int CompareTo(object obj)
        {
            if ((this.name.CompareTo(((Employee)obj).name) == -1))
                return 1;
            else if ((this.name.CompareTo(((Employee)obj).name) == 1))
                return -1;

            return 0;
            //return this.name.CompareTo(((Employee)obj).name);
        }
    }
    class SortByDob : IComparer
    {
        public int Compare(object x, object y)
        {
            return ((Employee)x).dob.CompareTo(((Employee)y).dob);
        }
    }
    class SortBySal : IComparer
    {
        public int Compare(object x, object y)
        {
            return ((Employee)x).sal.CompareTo(((Employee)y).sal);
        }
    }
        class Program
        {
            static void Main(string[] args)
            {
                Employee[] emp = new Employee[3];
                emp[0] = new Employee("Raj", DateTime.Parse("12/12/1998"), 5000);
                emp[1] = new Employee("Ank", DateTime.Parse("12/10/1995"), 6000);
                emp[2] = new Employee("Ravi", DateTime.Parse("11/10/1993"), 2000);
               // Array.Sort(emp);
                DisplayEmployee(emp);
                Console.WriteLine("1. Sort By Name: ");
                Console.WriteLine("2. Sort By Dob: ");
                Console.WriteLine("3. Sort By Salary: ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Array.Sort(emp);
                        DisplayEmployee(emp);
                        break;
                    case 2:
                        Array.Sort(emp, new SortByDob());
                        DisplayEmployee(emp);
                        break;
                    case 3:
                        Array.Sort(emp, new SortBySal());
                        DisplayEmployee(emp);
                        break;
                }
            }
            static void DisplayEmployee(Employee[] emp)
            {
                foreach (Employee e in emp)
                {
                    Console.WriteLine(e.name + "\t" + e.dob + "\t" + e.sal);
                }
            }
        }
    }