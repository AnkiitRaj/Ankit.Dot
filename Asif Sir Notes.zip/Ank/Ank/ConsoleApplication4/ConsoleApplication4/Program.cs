﻿using System;
class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        int x = int.Parse(Console.ReadLine());
        int c = 0;
        for (int i = 1; i > 0; i++)
        {
            string a = Console.ReadLine();
            if (i % x == 0 || i % (x * x) == 0)
            {
                if (a == "Bus")
                {
                    c = i - 1;
                    continue;
                }
                else
                    break;
            }
        }
        Console.WriteLine(c);
    }
}