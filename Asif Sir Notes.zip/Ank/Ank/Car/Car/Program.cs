﻿using System;
    class car
    {
        int price;
        string carname, carcolor, carmodel;
        public void carData()
        {
            Console.WriteLine("Enter Car Name : ");
            carname = Console.ReadLine();
            Console.WriteLine("Enter Car Color : ");
            carcolor = Console.ReadLine();
            Console.WriteLine("Enter Car Model : ");
            carmodel = Console.ReadLine();
            Console.WriteLine("Enter Car Price : ");
            price = int.Parse(Console.ReadLine());
        }
        public void carDetails()
        {
            Console.WriteLine("Your Car Name is {0}",carname);
            Console.WriteLine("Your Car Color is {0}",carcolor);
            Console.WriteLine("Your Car Model is {0}",carmodel);
            Console.WriteLine("Your Car Price is {0}",price);
        }
        static void Main(string[] args)
        {
            car c = new car();
            c.carData();
            c.carDetails();
        }
    }