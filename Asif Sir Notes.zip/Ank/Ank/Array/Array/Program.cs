﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    public class Employee : IComparable
    {
        public string name { get; set; }
        public DateTime dob { get; set; }
        public double sal { get; set; }
        public Employee(string name, DateTime dob, double sal)
        {
            this.name = name;
            this.dob = dob;
            this.sal = sal;
        }

        public int CompareTo(object obj)
        {
            return this.name.CompareTo(((Employee)obj).name);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[3];
            emp[0] = new Employee("Raj", DateTime.Parse("12/12/1997"), 2000);
            emp[1] = new Employee("Amir", DateTime.Parse("1/1/1998"), 3000);
            emp[2] = new Employee("Akshay", DateTime.Parse("3/31/1995"), 5000);
            Array.Sort(emp);
            DisplayEmployee(emp);
        }
        static void DisplayEmployee(Employee[] emp)
        {
            foreach (Employee e in emp)
            {
                Console.WriteLine(e.name + "\t" + e.dob + "\t" + e.sal);
            }
        }
    }
}