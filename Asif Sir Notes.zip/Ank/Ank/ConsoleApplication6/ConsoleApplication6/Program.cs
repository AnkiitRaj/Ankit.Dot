﻿using System;
public class Program
{
    public static void Main(string[] args)
    {
        int i, j;
        int[,] mat = new int[4, 4];
        for (i = 0; i <4; i++)
        {
            string s = Console.ReadLine();
            string[] s1 = s.Split(' ');
            for (j = 0; j <4; j++)
            {
                mat[i, j] = Convert.ToInt32(s1[j]);
            }
        }
        int result = findCommon(mat);
        if (result == -1)
            Console.Write("-1");
        else
            Console.Write(result);
    }
    public static int findCommon(int[,] mat)
    {
        int M = 4;
        int N = 4;
        int[] column = new int[M];
        int min_row;
        int i;
        for (i = 0; i < M; i++)
            column[i] = N - 1;
        min_row = 0;
        while (column[min_row] >= 0)
        {
            for (i = 0; i < M; i++)
            {
                if (mat[i, column[i]] < mat[min_row, column[min_row]])
                    min_row = i;
            }
            int eq_count = 0;
            for (i = 0; i < M; i++)
            {
                if (mat[i, column[i]] > mat[min_row, column[min_row]])
                {
                    if (column[i] == 0)
                        return -1;
                    column[i] -= 1;
                }
                else
                    eq_count++;
            }
            if (eq_count == M)
                return mat[min_row, column[min_row]];
        }
        return -1;
    }
}