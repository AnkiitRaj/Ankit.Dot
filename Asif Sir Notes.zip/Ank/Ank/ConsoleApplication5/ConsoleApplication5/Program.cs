﻿using System;
class Program
{

    public static bool checkPangram(string str)
    {
        bool[] mark = new bool[26];
        int index = 0;
        for (int i = 0; i < str.Length; i++)
        {
            if ('A' <= str[i] && str[i] <= 'Z')
                index = str[i] - 'A';

            else if ('a' <= str[i] && str[i] <= 'z')
                index = str[i] - 'a';

            mark[index] = true;
        }
        for (int i = 0; i <= 25; i++)
            if (mark[i] == false)
                return (false);

        return (true);
    }
    
    public static void Main()
    {
        string str = Console.ReadLine();
        int[] ch_fre = new int[255];
        int i = 0, max, l;
        int ascii;
        l = str.Length;

        for (i = 0; i < 255; i++)
        {
            ch_fre[i] = 0;
        }
        i = 0;
        while (i < l)
        {
            ascii = (int)str[i];
            ch_fre[ascii] += 1;

            i++;
        }
        max = 0;
        for (i = 0; i < 255; i++)
        {
            if (i != 32)
            {
                if (ch_fre[i] > ch_fre[max])
                    max = i;
            }
        }

        if (checkPangram(str) == true)
        {
            Console.WriteLine("Yes", str);
            Console.WriteLine("{0}", (char)max);
        }
        else
        {
            Console.WriteLine("No", str);

        }
    }
}