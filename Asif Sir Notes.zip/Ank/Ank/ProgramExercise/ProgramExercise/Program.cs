﻿
using System;
class GFG
{

    public static bool checkPangram(string str)
    {
        bool[] mark = new bool[26];

        // For indexing in mark[] 
        int index = 0;

        // Traverse all characters 
        for (int i = 0; i < str.Length; i++)
        {
            // If uppercase character, subtract 'A' 
            // to find index. 
            if ('A' <= str[i] &&
                    str[i] <= 'Z')

                index = str[i] - 'A';

                // If lowercase character, 
            // subtract 'a' to find 
            // index. 
            else if ('a' <= str[i] &&
                        str[i] <= 'z')

                index = str[i] - 'a';

            // Mark current character 
            mark[index] = true;
        }

        // Return false if any 
        // character is unmarked 
        for (int i = 0; i <= 25; i++)
            if (mark[i] == false)
                return (false);

        // If all characters 
        // were present 
        return (true);
    }

    // Driver Code 
    public static void Main()
    {
        string str = "The quick brown fox jumps over the lazy dog";

        if (checkPangram(str) == true)
            Console.WriteLine(str + " is a pangram.");
        else
            Console.WriteLine(str + " is not a pangram.");

    }
}

// This code is contributed by nitin mittal. 
