﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwentyFour
{
    interface ISouth
    {
        string Dosa();
        string Idli();
        string Biryani();
    }
    interface INorth
    {
        string PavBhaji();
        string CholaBatura();
        string Biryani();
    }
    public class Rest1 : ISouth, INorth
    {
        public string Dosa()
        {
            return "Dosa";
        }

        public string Idli()
        {
            return "Idli";
        }

        public string Biryani()
        {
            return "Biryani";
        }

        public string PavBhaji()
        {
            return "PavBhaji";
        }

        public string CholaBatura()
        {
            return "CholaBatura";
        }
    }
}