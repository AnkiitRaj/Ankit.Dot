﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwentyFour
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. North Menu");
            Console.WriteLine("2. South Menu");
            Console.WriteLine("3. Both Menu");
            int choice = int.Parse(Console.ReadLine());
            ISouth south = null;
            INorth north = null;
            Rest1 rest = null;
            switch (choice)
            {
                case 1:
                    north = new Rest1();
                    break;
                case 2:
                    south = new Rest1();
                    break;
                case 3:
                    rest = new Rest1();
                    break;
            }
            if (south != null)
            {
                Console.WriteLine(south.Dosa());
                Console.WriteLine(south.Idli());
                Console.WriteLine(south.Biryani());
            }
            else if (north != null)
            {
                Console.WriteLine(north.PavBhaji());
                Console.WriteLine(north.CholaBatura());
                Console.WriteLine(north.Biryani());
            }
            else if (rest != null)
            {
                Console.WriteLine(rest.Dosa());
                Console.WriteLine(rest.Idli());
                Console.WriteLine(rest.PavBhaji());
                Console.WriteLine(rest.CholaBatura());
                Console.WriteLine(rest.Biryani());
            }
        }
    }
}