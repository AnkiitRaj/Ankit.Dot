﻿/*using System;
public class Program
{
    static void Main(string[] args)
    {
        myStaticFun();
    }
    public static void myStaticFun()
    {
        string s = "INDIA";
        for (int i = 0; i < s.Length; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                Console.Write(s[j]);
            }

            Console.WriteLine();
        }
    }
} */
/*using System;
class Program
{
    static void Main(string[] args)
    {
        DateTime a = DateTime.Parse(Console.ReadLine());
        DateTime d1 = DateTime.Parse(Console.ReadLine());
        DateTime d2 = DateTime.Parse(Console.ReadLine());
        int a1 = int.Parse(Console.ReadLine());
        int b = int.Parse(Console.ReadLine());
        int c = int.Parse(Console.ReadLine());
        int count = 0, count1 = 0, count2 = 0;


        DateTime result1 = a.AddMinutes(a1);
        DateTime result2 = a.AddMinutes(b);
        DateTime result3 = a.AddMinutes(c);

        if (d1 < d2)
        {
            if (a < d1)
                Console.WriteLine("Completed");
            else if (a == d1)
                Console.WriteLine("Partial");
            else
                Console.WriteLine("No");
            if (a < d2)
                Console.WriteLine("Completed");
            else if (a == d2)
                Console.WriteLine("Partial");
            else
                Console.WriteLine("No");
        }
        if (d2 < d1)
        {
            if (a < d2)
                count++;
            else if (a == d2)
                count1++;
            else
                count2++;
            if (a == d1)
                Console.WriteLine("Partial");
            else if (a < d1)
                Console.WriteLine("Completed");
            else
                Console.WriteLine("No");
            if (count == 1)
                Console.WriteLine("Completed");
            if (count1 == 1)
                Console.WriteLine("Partial");
            if (count2 == 1)
                Console.WriteLine("No");
        }


    }
}*/
using System;
class Program
{
    static void Main(string[] args)
    {
        int n, m, sum, i = 1;
        Console.WriteLine("Enter n");
        n = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter m");
        m = int.Parse(Console.ReadLine());
        while(i<=m)
        {
            i++;
            sum = i*n;
            Console.WriteLine("The multiplication table of "+n+"is");
            Console.WriteLine(i + "*" + n + "=" + sum);
        }
    }
}