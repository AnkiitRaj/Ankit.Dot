﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVENODD
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("Enter any number: ");
            int a = int.Parse(Console.ReadLine());
            if (a % 2 == 0)
            {
                Console.WriteLine("Even Number",a);
            }
            else
            {
                Console.WriteLine("Odd Number",a);
             * */

           /* Console.WriteLine("Enter three numbers : ");
            int a= int.Parse(Console.ReadLine());
            int b= int.Parse(Console.ReadLine());
            int c= int.Parse(Console.ReadLine());

            if (a > b && a > c)
            {
                Console.WriteLine("{0} is greater. ", a);
            }
            else if (b > a && b > c)
            {
                Console.WriteLine("{0} is greater. ", b);
            }
            else
            {
                Console.WriteLine("{0} is greater. ", c);
            }
            */
           /* Console.WriteLine("Enter 10, 20, 30, 40 to check there position: ");
            int yn = int.Parse(Console.ReadLine());
            switch (yn)
            {
                case 10:
                        Console.WriteLine("Number 10 at Position 1.");
                        break;
                default:
                        Console.WriteLine("Invalid Input");
                        break; 
                case 20:
                        Console.WriteLine("Number 20 at Position 2.");
                        break;
                    
                case 30:
                        Console.WriteLine("Number 30 at Position 3.");
                        break;
                    
                case 40:
                        Console.WriteLine("Number 40 at Position 4.");
                        break;                    
            } */
            char Yes;
            do{
            Console.WriteLine("1. Addition\n2. Substraction.\n3. Multiplication\n4. Division");
            int calc = int.Parse(Console.ReadLine());
                  switch (calc)
                {
                    case 1:
                        Console.WriteLine("Enter two number for Additions: ");
                        int a = int.Parse(Console.ReadLine());
                        int b = int.Parse(Console.ReadLine());
                        int c = a + b;
                        Console.WriteLine("Number {0} + {1} = {2}", a, b, c);
                        break;
                    case 2:
                        Console.WriteLine("Enter two number for Substract: ");
                        int d = int.Parse(Console.ReadLine());
                        int e = int.Parse(Console.ReadLine());
                        int f = d - e;
                        Console.WriteLine("Number {0} - {1} = {2}", d, e, f);
                        break;
                    case 3:
                        Console.WriteLine("Enter two number for Multiplication: ");
                        int g = int.Parse(Console.ReadLine());
                        int h = int.Parse(Console.ReadLine());
                        int i = g * h;
                        Console.WriteLine("Number {0} * {1} = {2}", g, h, i);
                        break;
                    case 4:
                        Console.WriteLine("Enter two number for Division: ");
                        int j = int.Parse(Console.ReadLine());
                        int k = int.Parse(Console.ReadLine());
                        int l = j + k;
                        Console.WriteLine("Number {0} / {1} = {2}", j, k, l);
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        break;
                }
                Console.WriteLine("Do You Want To Continue : Y/N");
                Yes = Char.Parse(Console.ReadLine());

            } while (Yes == 'Y' || Yes == 'y');

        }
    }
}
