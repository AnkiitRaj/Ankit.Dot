﻿/*using System;
class Program
{
    public static void Main(string[] args)
    {
        int n, m, sum, i = 1;
        Console.WriteLine("Enter n");
        n = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter m");
        m = int.Parse(Console.ReadLine());
        while (i <= m)
        {
            sum = i * n;
            i++;
        }
            Console.WriteLine("The multiplication table of" + n + "is");
            Console.WriteLine(i + "*" + n + "=" +sum);


        
    }
} */
/*using System;
class Program
{
    static void Main(string[] args)
    {
        int n, m, sum, i = 1;
        Console.WriteLine("Enter n");
        n = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter m");
        m = int.Parse(Console.ReadLine());
        Console.WriteLine("The multiplication table of " + n + " is");
        while (i <= m)
        {
            sum = i * n;
            Console.WriteLine(i + "*" + n + "=" +sum);
            i++;
        }
        }
      } */

using System;
class Program
{
    static void Main(string[] args)
    {
        int i = 1, a, n, neg_count = 0, pos_count = 0;
        Console.WriteLine("Enter the value of n");
        n = int.Parse(Console.ReadLine());
        while (i <= n)
        {
            Console.WriteLine("Enter the number");
            a = int.Parse(Console.ReadLine());
            if (a >= 0)
            {
                pos_count++;
            }
            else
            {
                neg_count++;
            }
            i++;
        }
        Console.WriteLine("Number of positive numbers entered is " + pos_count + " and the number of negative numbers entered is " + neg_count);
    }
}
