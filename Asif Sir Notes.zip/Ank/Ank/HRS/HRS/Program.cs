﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRS
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the starting time(hh:mm:ss): ");
            DateTime sttime = DateTime.ParseExact(Console.ReadLine(), "HH:mm:ss", null);
            DateTime endtime = DateTime.ParseExact(Console.ReadLine(), "HH:mm:ss", null);

            Console.WriteLine("Start Time :" + sttime);
            Console.WriteLine("End Time : " + endtime);

           // Console.WriteLine(sttime.Subtract(endtime).TotalHours);
            TimeSpan difference = endtime - sttime;
            double diffInHours = difference.TotalHours;
            if (diffInHours > 0)
            {
               Console.WriteLine("Difference Between Start and End Time is :{0} Hours {1} Mins {2} Secs",  difference.Hours.ToString(),difference.Minutes.ToString(),difference.Minutes.ToString());
            }
            else 
            {
                Console.WriteLine("Invalid");
            }
        }
    }
}
