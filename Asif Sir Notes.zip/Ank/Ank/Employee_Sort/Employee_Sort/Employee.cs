﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeDependentConsoleApp
{
    public class Employee
    {
        public string name { get; set; }
        public int age { get; set; }
        public Employee()
        {
            Console.WriteLine("Employee 0 arg . . . ");
        }
        public Employee(string name, int age)
        {
            this.name = name;
            this.age = age;
            //  this.salary = salary;
        }

    }
    public class SalaryEmployee : Employee
    {
        public SalaryEmployee()
        {
            Console.WriteLine("SEMployee 0 arg.. ");
        }
        public double salary { get; set; }
    }
    public class WagedEmployee : Employee
    {
        public WagedEmployee()
        {
            Console.WriteLine("WEmployee 0 args.... ");
        }
        public double wage { get; set; }
    }

}
