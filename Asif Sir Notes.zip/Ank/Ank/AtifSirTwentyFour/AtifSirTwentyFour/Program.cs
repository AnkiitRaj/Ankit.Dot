﻿/* using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//CALL BY VALUE
namespace AtifSirTwentyFour
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program();
        }
        public Program()
        {
            int x = 10; int y = 20;
            Console.WriteLine("Before Swap (x,y)=>" + x + "," + y);
            swap(x, y);
            Console.WriteLine("After Swap (x,y)=>" + x + "," + y);
        }
        public void swap(int x, int y)
        {
            Console.WriteLine("In Swap Before (x,y) =>" + x + "," + y);
            int temp = x;
            x = y;
            y = temp;
            Console.WriteLine("In Swap After (x,y) =>" + x + "," + y);
        }
    }
} */
/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//CALL BY REFERENCE
namespace AtifSirTwentyFour
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program();
        }
        public Program()
        {
            int x = 10; int y = 20;
            Console.WriteLine("Before Swap (x,y)=>" + x + "," + y);
            swap(ref x, ref y);
            Console.WriteLine("After Swap (x,y)=>" + x + "," + y);
        }
        public void swap(ref int x,ref int y)
        {
            Console.WriteLine("In Swap Before (x,y) =>" + x + "," + y);
            int temp = x;
            x = y;
            y = temp;
            Console.WriteLine("In Swap After (x,y) =>" + x + "," + y);
        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Calculator Using Op: // Optional Parameters
namespace AtifSirTwentyFour
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program();
        }
        public Program()
        {
            //int r = calc(op:'*',x:15); //OPTIONAL PARAMETER
            int r;
            Console.WriteLine(calc(out r));
            Console.WriteLine(r);
        }
        public int calc(out int sum,int x=10, int y=20, char op='*')
        {
            int result = 0;
            sum = 0;
            switch (op)
            {
                case '+':
                    result = x + y;
                    break;
                case '-':
                    result = x - y;
                    break;
                case '*':
                    result = x * y;
                    break;
                case '/':
                    result = x / y;
                    break;
            }
            string s = result.ToString();
            for (int i = 0; i < s.Length; i++)
            {
                sum = 0;
            }
            return result;
        }
    }
}
