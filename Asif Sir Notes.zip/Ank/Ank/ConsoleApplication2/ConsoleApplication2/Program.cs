﻿/*using System;
namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, k;
            int p_height = 5;
 
           /*TOP PYRAMID 
            for (i = 1; i <= p_height; i++)
            {
                for (k = p_height - 1; k >= i; k--)
                {
                    Console.Write(" ");
                }
                for (j = 1; j <= i; j++)
                {
                    Console.Write(i + " ");
                }
                Console.WriteLine("");
            }

            /*BOTTOM PYRAMID 
            for (i = p_height - 1; i >= 1; i--)
            {
                for (k = p_height - 1; k >= i; k--)
                {
                    Console.Write(" ");
                }
                for (j = i; j >= 1; j--)
                {
                    Console.Write(i + " ");
                }
                Console.WriteLine("");
            }
        }
    }
} */
/*
using System;
class Program
{
    static void Main(string[] args)
    {
        int num, i=3, count, c;
        num = Convert.ToInt32(Console.ReadLine());
        if(num>=1)
        {
            Console.Write("2");
        }
        for(count =2; count <=num; )
        {
            for(c=2; c<=num; c++)
            {
                if(count != c && count % c ==0) 
                    break;
            }
            if(i%c==0)
            {
                Console.Write(" " +i);
                count++;
            }
            i++;
        }
    }
} */

//using System;
//class Program
//{
//    public static void Main(string[] args)
//    {
//        //string dateString = "Wed Dec 30, 2015";
//        //DateTime dateTime12 = DateTime.Parse(dateString);
//        //Console.WriteLine(dateTime12);
//        System.DateTime date1 = new System.DateTime(2015, 3, 10, 2, 15, 10);
//        Console.WriteLine(date1);
//    }
//}

using System;
public class Program
{
    public static void Main(string[] args)
    {
        //int n = Convert.ToInt32(Console.ReadLine());
        //int i,j;
        ////for (i = 1; i <= n; i++)
        ////{
        ////    Console.Write(Math.Pow(3,i)+" ");
        ////}
        //for (i = 1; i <= n; i++)
        //{
        //    for (j = 1; j <= i; j++)
        //    {
        //        Console.Write(((n-i)+j) + " ");
        //    }
        //    Console.WriteLine();
        int n = Convert.ToInt32(Console.ReadLine());
        int i,j;
        for (i=1; i<=n; i++)
        {
            for (j = 1; j <= i; j++)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        }
    }
}