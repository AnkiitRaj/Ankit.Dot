﻿/* CONSONANTS VOWELS PROGRAM -----------------------------------------------------------------------------------
 * Console.WriteLine("Input the string : ");
            string str = Console.ReadLine();
            int vowels = 0, consonants = 0, digits = 0, spaces = 0, specialChar = 0;

            for (int i = 0; i < str.Length; i++)
            {
                char ch = str[i];
                if (ch >= '0' && ch <= '9')
                {
                    digits++;
                }
                else if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
                        ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
                {
                    vowels++;
                }
                else if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
                {
                    consonants++;
                }
                else if (ch == ' ')
                {
                    spaces++;
                }
                else
                {
                    specialChar++;
                }
                Console.WriteLine("Total Vowels : {0}", vowels);
                Console.WriteLine("Total Consonants : {0}", consonants);
                Console.WriteLine("Total Spaces : {0}", spaces);
                Console.WriteLine("Total Symbols : {0}", specialChar);
            }
 * --------------------------------------------------------------------------------------------------------------------
            */

/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsonantVowel
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.square();
        }
        public void square()
        {
            Console.WriteLine("Enter any positive number : ");
            int numb = int.Parse(Console.ReadLine());
            int sum = numb * numb;
            Console.WriteLine("Square of {0} is {1}", numb,sum);
        }  
    }
} */

/*using System;
public class Program
{

    public static void Main()
    {
        int bNum, pwr;
        int result;
        Console.WriteLine("Calculate power of any number :");
       

        Console.Write(" Input the base  value : ");
        bNum = Convert.ToInt32(Console.ReadLine());

        Console.Write(" Input the exponent : ");
        pwr = Convert.ToInt32(Console.ReadLine());

        result = CalcuOfPower(bNum, pwr);

        Console.WriteLine(" The value of {0} to the power of {1} is : {2}", bNum, pwr, result);
    }

    public static int CalcuOfPower(int x, int y)
    {
        if (y == 0)
            return 1;
        else
            return x * CalcuOfPower(x, y - 1);
    }
}*/
/*using System;
public class Program
{
    public static void Main()
    {
        Program p = new Program();
        p.power(2, 3);
    }
    public void power(int num, int pwr)
    {
        int res = 1;
        for (int i = 1; i <= pwr; i++)
        {
            res = res * num;
        }
        Console.WriteLine("Power is {0}", res);
    }
} */
/*
using System;
class Program
{
    static void Main(string[] args)
    {
        DateTime traintime = DateTime.Parse(Console.ReadLine()); //s1
        DateTime train1 = DateTime.Parse(Console.ReadLine());//s2
        DateTime train2 = DateTime.Parse(Console.ReadLine()); //s3
        int depart1 = int.Parse(Console.ReadLine()); //a1
        int depart2 = int.Parse(Console.ReadLine()); //b
        int timebtwnstation = int.Parse(Console.ReadLine()); //c
        int count = 0, count1 = 0, count2 = 0;


        DateTime result1 = traintime.AddMinutes(depart1); //a
        DateTime result2 = traintime.AddMinutes(depart2); //d1
        DateTime result3 = traintime.AddMinutes(timebtwnstation);//d2


        if (result2 < result3)
        {
            if (result1 < result2)
            {
                Console.WriteLine("Completed");
            }
            else if (result1 == result2)
            {
                Console.WriteLine("Partial");
            }
            else
            {
                Console.WriteLine("No");
            }
            if (result1 < result3)
            {
                Console.WriteLine("Completed");
            }
            else if (result1 == result3)
            {
                Console.WriteLine("Partial");
            }
            else
            {
                Console.WriteLine("No");
            }
        }

        {
            if (result3 < result2)
            {
                if (result1 < result3)
                {
                    count++; //Console.WriteLine("Completed");
                }
                else if (result1 == result3)
                {
                    count1++; //Console.WriteLine("Partial");
                }
                else
                {
                    count2++;// Console.WriteLine("No");
                }
                if (result1 == result2)
                {
                    Console.WriteLine("Partial");
                }
                else if (result1 < result2)
                {
                    Console.WriteLine("Completed");
                }
                else
                    Console.WriteLine("No");
                if (count == 1)
                    Console.WriteLine("Completed");
                if (count == 1)
                    Console.WriteLine("Partial");
                if (count2 == 1)
                    Console.WriteLine("No");
            }
        }

    }
} */
/*
using System;
class Program
{
    static void SwapNum(ref int x, ref int y)
    {

        int temp = x;
        x = y;
        y = temp;

    }
    static void Main(string[] args)
    {
        int a = int.Parse(Console.ReadLine());
        int b = int.Parse(Console.ReadLine());

        Console.WriteLine("Value of a and b before swapping");
        Console.WriteLine();
        Console.WriteLine("a = {0}", a);
        Console.WriteLine("b = {0}", b);
        SwapNum(ref a, ref b);
        Console.WriteLine();
        Console.WriteLine("Value of a and b after swapping");
        Console.WriteLine();
        Console.WriteLine("a = {0}",a);
        Console.WriteLine("b = {0}",b);
        Console.ReadLine();

    }
} */
using System;
public class Program
{
    static void Main(string[] args)
    {
        myStaticFun();
    }
    public static void myStaticFun()
    {
        string s = "INDIA";
        for (int i = 0; i <s.Length; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                Console.Write(s[j]);
            } 
            
            Console.WriteLine();
        }
    }
}
