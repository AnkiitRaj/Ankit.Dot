﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TwentyFive
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program();
        }
        public Program()
        {
            int x = 10;
            Console.WriteLine("Enter a number");
            int y = int.Parse(Console.ReadLine());
            try
            {
                Console.WriteLine(x / y);
                int[] a = { 10, 20, 30 };
                Console.WriteLine(a[2]);
                //AnotherFunc();
                if (a[2] < 5)
                    throw new MyException("Value should be greater than 5");
                Console.WriteLine("Inside Try..");
            }
            catch (MyException me)
            {
                Console.WriteLine(me.Message);
            }
            catch (DivideByZeroException de)
            { Console.WriteLine(de.Message); }
            catch (IndexOutOfRangeException se)
            { Console.WriteLine(se.Message); }
            catch (Exception ex)
            { Console.WriteLine(ex.Message); }
            catch
            {
                Console.WriteLine("Error Occured");
            }
            finally
            {
                Console.WriteLine("Finally");
            }
            Console.WriteLine("Okkk.. Finee ! ");

        }
        public void AnotherFunc()
        {
            try
            {
                File.Open(@"D:\asif\a1.txt", FileMode.Open);
                Console.WriteLine("Another Func");
            }
            catch
            {
                Console.WriteLine("Another Func: Errrrorrr");
                throw;
            }
            finally
            {
                Console.WriteLine("Another Func: Finally");
            }
            Console.WriteLine("Another Func: After File Open");
        }
    }
}
