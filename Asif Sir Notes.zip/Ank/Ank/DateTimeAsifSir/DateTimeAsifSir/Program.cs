﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeAsifSir
{
    class Program
    {
        static void Main(string[] args)
        {
           // Console.WriteLine("Enter your date of birth(dd/MM/yyyy) Format : ");
           // DateTime mydate = DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null);
           //// Console.WriteLine(mydate);
           // TimeSpan ts = DateTime.Today - mydate;
           // DateTime mindate = DateTime.MinValue.Add(ts);
           // Console.WriteLine((mindate.Year-1)  +  "  Years "  + (mindate.Month-1)  +  "  Months "  + (mindate.Day-1)  +  "  Days ");

            Console.WriteLine("Enter the starting time(hh:mm:ss): ");
            DateTime sttime = DateTime.ParseExact(Console.ReadLine(), "HH:mm:ss", null);
            DateTime endtime = DateTime.ParseExact(Console.ReadLine(), "HH:mm:ss", null);

            Console.WriteLine("Start Time :" + sttime);
            Console.WriteLine("End Time : " + endtime);
           }
    }
}
