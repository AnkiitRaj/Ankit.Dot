﻿/* using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForegroundBackground
{
    class Program
    {
        static void Main(string[] args)
        {
            /*for (int x = 1; x <= 20; x++)
            {
                Console.WriteLine("My name is Ankit");
            }
                for (int i = 1; i <= 20; i++)
            {
                if (i%2 == 0)
                Console.WriteLine(i);
            } */

   /*         Console.WriteLine("Enter any number: ");
            int numb = int.Parse(Console.ReadLine());
            int no = 0;
            for (int i = 1; i <= numb; i++)
                if (numb % i == 0)
                    no++;
            if (no == 2)
            {
                Console.WriteLine("{0} is a prime Number. ", numb);
            }
            else
            {
                Console.WriteLine("{0} is not a prime Number. ", numb);
            }
        
        }
    }
}
*/

using System;
class Program
{
    static void Main(string[] args)
    {
        DateTime traintime = DateTime.Parse(Console.ReadLine());
        DateTime train1 = DateTime.Parse(Console.ReadLine());
        DateTime train2 = DateTime.Parse(Console.ReadLine());
        int depart1 = int.Parse(Console.ReadLine());
        int depart2 = int.Parse(Console.ReadLine());
        int timebtwnstation = int.Parse(Console.ReadLine());
        int totaltime = depart2 + timebtwnstation;
        
        DateTime result0 = traintime.AddMinutes(depart1);
        DateTime result1 = traintime.AddMinutes(depart2);
        DateTime result2 = traintime.AddMinutes(totaltime);
        {
            if(result0 < train1)
            {
                Console.WriteLine("Completed");
            }
            else if (result0 == train1)
            {
                Console.WriteLine("Partial");
            }
            else
            {
                Console.WriteLine("No");
            }
    }
            if(result2 < train2)
             {
                Console.WriteLine("Completed");
             }
            else if ((result0 >=train1) && (result2 >= train2))
            {
                Console.WriteLine("Partial");
            }
            else
            {
                Console.WriteLine("No");
            }
    }
} 

/*using System;
class Program
{
    static void Main(string[] args)
    {
        int i=1;
        do
        {
            Console.WriteLine("3 x {0} = {1}", i, 3 * i);
            i++;
        }
        while (i <= 10);
    }
} */

/*using System;
class Program
{
    static void Main(string[] args)
    {
        int i;
        double number, sum = 0.0;

        for (i = 1; i <= 5; i++)
        {
            Console.WriteLine("Enter a number: ", i);
            number = double.Parse(Console.ReadLine());

            if (number < 0.0)
            {
                continue;
            }

            sum += number; 
        }

        Console.WriteLine("Sum is = {0}", sum);
    }
}*/
