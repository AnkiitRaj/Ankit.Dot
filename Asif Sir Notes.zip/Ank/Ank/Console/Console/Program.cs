﻿//using System;
//class Program
//{
//     static void Main(string[] args)
//    {
//         /* ONE DIMENSION ARRAY
//        //int []marks= new int[5];
//        int[] marks = { 10, 20, 50, 69, 17 };
//         int sum = 0;
//        //marks[0] = 10;
//        //marks[1] = 20;
//        //marks[2] = 80;
//        //marks[3] = 30;
//        //marks[4] = 15;

//        for (int i = 0; i < marks.Length; i++)
//        {
//            sum = sum + marks[i];
//            Console.WriteLine(marks[i]);
//        }

//        Console.WriteLine("Sum of Marks : {0}", sum);
        
//          * */

//         /* TWO DIMENSION ARRAY */
//         int [,] marks = new int[2,3];
//         marks[0,0] = 5;
//         marks[0,1] = 10;
//         marks[0,2] = 11;
//         marks[1,0] = 20;
//         marks[1,1] = 25;
//         marks[1,2] = 55;
//         //marks[2,0] = 45;
//         //marks[2,1] = 13;
//         //marks[2,2] = 15;

//         //for(int i=0; i<=marks.GetUpperBound(0); i++)
//         //{
//         //    for(int j=0; j<=marks.GetUpperBound(1); j++)
//         //    {
//         //        Console.Write(" " + marks[i,j]);
//         //    }
             
//         //}
//         for (int r = 0; r < 2; r++)
//         {
//             for (int c = 0; c < 3; c++)
//             {
//                 Console.WriteLine(marks[r, c]);
//             }
//         }
//         Console.WriteLine();
//    }
//}

//using System;
//class Program
//{
//    static void Main(string[] args)
//    {
//        int n = Convert.ToInt32(Console.ReadLine());
//        int i, j;
//        for (i = n; i>=1; i--)
//        {
//            for (j = 0; j <= (n-i); j++)
//            {
//                Console.Write(i + " ");
//            }
//            Console.WriteLine();
//        }
//    }
//}
//using System;
//public class Program
//{
//    public static void Main(string[] args)
//    {
//        int i, sum = 1;
//        int n = Convert.ToInt32(Console.ReadLine());

//        for (i = 1; ; i++)
//        {
            
//            sum *= i;
//            if (sum == n)
//            {
//                Console.WriteLine("yes");
//                break;
//            }
//            else
//            {
//                if (sum >= n)
//                    break;
//                    Console.WriteLine("no");
                  
                
//            } 
            
//        }
        
//    }
//}

using System;
public class Program
{
    public static void Main(string[] args)
    {
        int n = Convert.ToInt32(Console.ReadLine());
        int sqrNum = n * n;
        int num1 = 0, num2 = 0;
        string n1 = "", n2 = "";
        num1 = Convert.ToInt32(n1);
        num2 = Convert.ToInt32(n2);

        if (sqrNum.ToString().Length > 1)
        {
            if (sqrNum.ToString().Length % 2 == 0)
            {
                n1 = sqrNum.ToString().Substring(0, sqrNum.ToString().Length / 2);
                n2 = sqrNum.ToString().Substring(sqrNum.ToString().Length / 2, (sqrNum.ToString().Length - sqrNum.ToString().Length / 2));
            }
            else
            {
                n1 = sqrNum.ToString().Substring(0, sqrNum.ToString().Length / 2);
                n2 = sqrNum.ToString().Substring(sqrNum.ToString().Length / 2, (sqrNum.ToString().Length - sqrNum.ToString().Length / 2));
            }
        }
        else
        {
            num1 = Convert.ToInt32(sqrNum);
        }
        if (num1 + num2 == n)
            Console.WriteLine("Kaprekar Number");
        else
            Console.WriteLine("Not A Kaprekar Number");
    }
}
