﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsifSirProgram1ArrayAPI
{
    class Program
    {
        string[] emp = new string[1];
        static void Main(string[] args)
        {
            new Program();
        }
        public Program()
        {
            string ans = "y";
            do
            {
                Console.Clear();
                Console.WriteLine("1.Add an Employee");
                Console.WriteLine("2.Remove an Employee");
                Console.WriteLine("3.Update an Employee");
                Console.WriteLine("4.Search an Employee");
                Console.WriteLine("5.Display All Employee");
                Console.WriteLine("6.Exit");
                Console.Write("Enter Your Choice:");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddEmployee(emp);
                        break;
                    case 2:
                        RemoveEmployee(emp);
                        break;
                    case 3:
                        break;
                    case 4:
                        SearchEmployee(emp);
                           break;
                    case 5:
                        DisplayEmployee(emp);
                        break;
                    case 6:
                        break;
                }
                Console.Write("do u wanna continue(y/n)");
                ans = Console.ReadLine();
            } while (ans == "y");
        }
        public void RemoveEmployee(string[] emp)
        {
            Console.WriteLine("Enter the Employee name to Remove ");
            string name = Console.ReadLine();
            Array.Clear(emp, 0, 2);
            Console.WriteLine("Deleted :: " + name);
        }

        public void SearchEmployee(string[] emp)
        {
            Console.Write("Enter the name ");
            string name = Console.ReadLine();
            Array.Sort(emp);
            int n = Array.BinarySearch(emp, name);
            if (n >= 0)
                Console.WriteLine("Found :: " + emp[n]);
            else
                Console.WriteLine("Not Found :: " + name);
        }
        public void AddEmployee(string[] emp1)
        {
            if (emp1[emp1.Length - 1] != null)
            {
                string[] temp = new string[emp.Length];
                Array.Copy(emp1, temp, emp1.Length);
                emp1 = new string[emp1.Length + 1];
                Array.Copy(temp, emp1, temp.Length);
                temp = null;
            }
            Console.Write("Enter Employee name ");
            string name = Console.ReadLine();
            Console.Write("Enter Employee DOB ");
            DateTime dob = DateTime.Parse(Console.ReadLine());
            Console.Write("Enter Employee Salary ");
            double sal = double.Parse(Console.ReadLine());
            Employee e = new Employee(name, dob, sal);
            emp1[emp1.Length - 1] = name;
            emp = emp1;
            Console.WriteLine("Employee added succesfully");
        }
        public void DisplayEmployee(string[] emp)
        {
            Console.WriteLine("Name \t Dob \t \t Salary");
            foreach(string e in emp)
            {
                Console.WriteLine(e);
            }
        }    
    }
 }

   //Employee[] emp = new Employee[1];
            //do
            //{
            //Console.WriteLine("Enter Your Choice\n 1. Add a employee.\n 2. Remove a employee.\n 3. Update Employee.\n 4. Search Employee.\n 5. Display All Employee.\n 6. Exit.\n ");
            //    int choice = int.Parse(Console.ReadLine());
            //    switch(choice)
            //    {
            //        case 1:
            //            Console.WriteLine("Enter Employee Name : ");
            //            string name = Console.ReadLine();

            //            Console.WriteLine("Enter Employee DOB : ");
            //            DateTime d = DateTime.Parse(Console.ReadLine());

            //            Console.WriteLine("Enter Employee Salary : ");
            //            double s = double.Parse(Console.ReadLine());

            //            Employee e = new Employee(name, d,s);
            //            Console.WriteLine("Name: {0} ", e.Name);
            //            Console.WriteLine("DOB: {0} ", e.Dob);
            //            Console.WriteLine("Salary: {0} ", e.Salary);
                        
            //        case 2:
                        
            //                break;
                        
            //        case 3:
                        
            //                break;
                        
            //        case 4:
                        
            //                break;
            //        case 5:
            //            break;
            //        case 6:
            //            break;
            //    }
            //    Console.WriteLine("Do you want to continue ? Press yes or no ");
            //    t = Console.ReadLine();

            //    while ( t =="yes" || t == "no")