﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsifSirProgram1ArrayAPI
{
    public class Employee
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private DateTime dob;
        public DateTime Dob
        {
            get { return dob; }
            set { dob = value; }
        }

        private double salary;
        public double Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        public Employee() { }
        public Employee(string name, DateTime dob, double salary)
        {
            Name = name;
            Dob = dob;
            Salary = salary;
        }
        
    }
}
