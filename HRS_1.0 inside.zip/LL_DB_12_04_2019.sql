create drop database ATS;
use ATS;
create table UserMaster
(
fname varchar(200) not null,
lname varchar(200) not null,
phoneNumber varchar(200) not null,
userId varchar(200) primary key,
upassword varbinary(max) not null
);

select * from UserMaster;

create table CustomerMaster
(
cid int identity primary key,
cname varchar(200) not null,
cage varchar(200) not null,
cgender varchar(200) not null,
userId varchar (200) null,
foreign key (userId) references UserMaster(userId)
);

Select * from CustomerMaster;

create table HotelMaster
(
hid int identity primary key,
hname varchar(200) not null,
hlocation varchar(200) not null,
hrating varchar(200) not null
);

Select * from HotelMaster;

create table RoomMaster
(
rid int identity primary key,
hid int not null,
rcapacity varchar(200) not null,
ravailable bit not null,
rwifi bit not null,
rtype  varchar(200) not null,
rprice money not null,
foreign key (hid) references HotelMaster(hid)
);

Select * from RoomMaster;

create table PaymentMaster
(
pid int identity primary key,
card_number varchar(200) not null,
name_on_card varchar(200) not null,
userId varchar(200) not null,
foreign key(userId) references UserMaster(userId)
);

Select * from PaymentMaster;

create table BookingMaster
(
bid int identity primary key,
bdate date not null, 
bcheckin date not null,
bcheckout date not null,
btotalprice money not null,
bstatus bit not null,
hid int not null,
rid int not null,
userId varchar(200) not null,
pid int not null,
foreign key (userId) references UserMaster(userId),
foreign key (hid) references HotelMaster(hid),
foreign key (rid) references RoomMaster(rid),
foreign key (pid) references PaymentMaster(pid)
);

Select * from BookingMaster;

Insert into HotelMaster values('Central Heritage Resort','Kolkata',3);
Insert into HotelMaster values('The Orchid London','Kolkata',4);
Insert into HotelMaster values('Hotel Oberoi Grand','Kolkata',3);
Insert into HotelMaster values('Hotel Hayatt Regency','Kolkata',3);
Insert into HotelMaster values('Hotel Novotel','Kolkata',2);
Insert into HotelMaster values('Hotel Pride Plaza','Kolkata',3);
Insert into HotelMaster values('Central Heritage Resort and Spa','Kolkata',3);

Insert into RoomMaster values(1,1,1,1,'Ac',1500);
Insert into RoomMaster values(1,2,1,1,'Ac',1950);
Insert into RoomMaster values(1,3,1,1,'Ac',2569);
Insert into RoomMaster values(1,1,1,1,'Non-Ac',800);
Insert into RoomMaster values(1,2,1,1,'Non-Ac',1200);
Insert into RoomMaster values(1,3,1,1,'Non-Ac',1600);
Insert into RoomMaster values(1,1,1,1,'Deluxe',5000);
Insert into RoomMaster values(1,2,1,1,'Deluxe',5000);
Insert into RoomMaster values(1,3,1,1,'Deluxe',5000);

Insert into RoomMaster values(2,1,1,1,'Ac',1200);
Insert into RoomMaster values(2,2,1,1,'Ac',1750);
Insert into RoomMaster values(2,3,1,1,'Ac',2300);
Insert into RoomMaster values(2,1,1,1,'Non-Ac',500);
Insert into RoomMaster values(2,2,1,1,'Non-Ac',900);
Insert into RoomMaster values(2,3,1,1,'Non-Ac',1200);
Insert into RoomMaster values(2,1,1,1,'Deluxe',3000);
Insert into RoomMaster values(2,2,0,1,'Deluxe',4000);
Insert into RoomMaster values(2,3,0,1,'Deluxe',5000);

Insert into RoomMaster values(3,1,1,1,'Ac',700);
Insert into RoomMaster values(3,2,1,1,'Ac',950);
Insert into RoomMaster values(3,3,1,1,'Ac',1269);
Insert into RoomMaster values(3,1,1,1,'Non-Ac',450);
Insert into RoomMaster values(3,2,1,1,'Non-Ac',550);
Insert into RoomMaster values(3,3,1,1,'Non-Ac',600);
Insert into RoomMaster values(3,1,1,1,'Deluxe',1800);
Insert into RoomMaster values(3,2,1,1,'Deluxe',2000);
Insert into RoomMaster values(3,3,0,1,'Deluxe',3000);

Insert into RoomMaster values(4,1,1,1,'Ac',1100);
Insert into RoomMaster values(4,2,1,1,'Ac',1250);
Insert into RoomMaster values(4,3,1,1,'Ac',1369);
Insert into RoomMaster values(4,1,1,1,'Non-Ac',650);
Insert into RoomMaster values(4,2,1,1,'Non-Ac',850);
Insert into RoomMaster values(4,3,1,1,'Non-Ac',950);
Insert into RoomMaster values(4,1,0,1,'Deluxe',2000);
Insert into RoomMaster values(4,2,0,1,'Deluxe',2500);
Insert into RoomMaster values(4,3,1,1,'Deluxe',3000);

Insert into RoomMaster values(5,1,1,1,'Ac',2500);
Insert into RoomMaster values(5,2,1,1,'Ac',3550);
Insert into RoomMaster values(5,3,1,1,'Ac',4500);
Insert into RoomMaster values(5,1,1,1,'Deluxe',6000);
Insert into RoomMaster values(5,2,1,1,'Deluxe',7000);
Insert into RoomMaster values(5,3,1,1,'Deluxe',9000);

Insert into RoomMaster values(6,1,1,1,'Ac',1500);
Insert into RoomMaster values(6,2,1,1,'Ac',1950);
Insert into RoomMaster values(6,3,1,1,'Ac',2569);
Insert into RoomMaster values(6,1,1,1,'Non-Ac',800);
Insert into RoomMaster values(6,2,1,1,'Non-Ac',1200);
Insert into RoomMaster values(6,3,1,1,'Non-Ac',1600);
Insert into RoomMaster values(6,1,1,1,'Deluxe',5000);
Insert into RoomMaster values(6,2,1,1,'Deluxe',5000);
Insert into RoomMaster values(6,3,1,1,'Deluxe',5000);

Insert into RoomMaster values(7,1,1,1,'Ac',1700);
Insert into RoomMaster values(7,2,1,1,'Ac',1950);
Insert into RoomMaster values(7,3,1,1,'Ac',2200);
Insert into RoomMaster values(7,1,1,1,'Non-Ac',900);
Insert into RoomMaster values(7,2,1,1,'Non-Ac',1100);
Insert into RoomMaster values(7,3,1,1,'Non-Ac',1200);
Insert into RoomMaster values(7,1,1,1,'Deluxe',4000);
Insert into RoomMaster values(7,2,0,1,'Deluxe',5000);
Insert into RoomMaster values(7,3,1,1,'Deluxe',5000);