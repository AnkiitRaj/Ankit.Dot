﻿using System;
using System.Collections;
using System.Xml;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using HotelBusinessObject;

namespace HotelDataLayer
{
    public  class personalDetailsDL
    {
        public personalDetailsDL()
        {
        }
     
        public int personalDetailsEntry(HotelBusinessObject.personalDetails Hbo) 
        {
      
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@cname",Hbo.cname);
            param[1] = new SqlParameter("@cage",Hbo.cage);
            param[2] = new SqlParameter("@cgender",Hbo.cgender);
            param[3] = new SqlParameter("@userId",Hbo.userId);

            param[0].Value=Hbo.cname;
            param[1].Value=Hbo.cage;
            param[2].Value=Hbo.cgender;
            param[3].Value=Hbo.userId;

            string commandText = "insert into CustomerMaster(cname,cage,cgender,userId) values(@cname,@cage,@cgender,@userId)";
            
            int k = SqlHelperDL.ExecuteNonQuery(commandText, CommandType.Text, param);
        if (k != 0)
        {
            return 1; 
        }  
        return 0;
        }
        public DataTable PersonalDetails(string userID) 
        {
            string commandText = "select max(cid) from CustomerMaster where userId=@UserID;";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@UserID", SqlDbType.VarChar);
            
            param[0].Value = userID;
            
            return SqlHelperDL.GetDataTable(commandText, CommandType.Text, param);
        }

        public DataTable HotelDetails(int hid)
        {
            string commandText ="select min(rid) from RoomMaster where hid=@hid;";
            SqlParameter[] param = new SqlParameter[1];
            
            param[0] = new SqlParameter("@hid", SqlDbType.Int);
            
            param[0].Value = hid;
            return SqlHelperDL.GetDataTable(commandText, CommandType.Text, param);
        }

    }
}
