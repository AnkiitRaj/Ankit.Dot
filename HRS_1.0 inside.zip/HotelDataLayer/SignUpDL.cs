﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace HotelDataLayer
{
    public class SignUpDL
    {
        public int SignUpUser(HotelBusinessObject.SignUp s,string cardNumber) 
        {
            string commandText = "insert into UserMaster(fname,lname,phoneNumber,userId,upassword) values(@fname,@lname,@phoneNumber,@userId,@upassword);"+
                                  "insert into PaymentMaster(card_number,name_on_card,userId,current_bal) values(@card_number,@name_on_card,@userId,@current_bal);";
            SqlParameter[] param = new SqlParameter[8];
            param[0] = new SqlParameter("@fname", SqlDbType.VarChar);
            param[1] = new SqlParameter("@lname", SqlDbType.VarChar);
            param[2] = new SqlParameter("@phoneNumber", SqlDbType.VarChar);
            param[3] = new SqlParameter("@userId", SqlDbType.VarChar);
            param[4] = new SqlParameter("@upassword", SqlDbType.VarBinary);
            param[5] = new SqlParameter("@card_number", SqlDbType.VarChar);
            param[6] = new SqlParameter("@current_bal", SqlDbType.Money);
            param[7] = new SqlParameter("@name_on_card", SqlDbType.VarChar);
            string name = s.fname + s.lname; 
            string password = s.upassword;
            byte[] array = System.Text.Encoding.ASCII.GetBytes(password);
            param[0].Value = s.fname;
            param[1].Value = s.lname;
            param[2].Value = s.phoneNo;
            param[3].Value = s.userId;
            param[4].Value = array;
            param[5].Value = cardNumber;
            param[6].Value = 40000;
            param[7].Value = name;
            return SqlHelperDL.ExecuteNonQuery(commandText, CommandType.Text, param);
               
            }

        public bool ValidateUser(string userID, string password)
        {
            string commandText = "select upassword from UserMaster where userId=@userID";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@userID", userID);
            string result = System.Text.ASCIIEncoding.ASCII.GetString((byte[])SqlHelperDL.ExecuteScalar(commandText,CommandType.Text,param));
            if (result.ToString() == password)
                return true;
            return false;
        }
        public DataTable UserInfo(string userID)
        {
            string commandText = "select fname,lname,phoneNumber,userId from UserMaster where userId=@userID";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@userID", userID);
            return SqlHelperDL.GetDataTable(commandText, CommandType.Text, param);

        }
    }
}

