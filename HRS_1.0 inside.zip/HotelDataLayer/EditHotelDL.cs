﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using HotelBusinessObject;

namespace HotelDataLayer
{
    public class EditHotelDL
    {
        public EditHotelDL()
        {
        }
        public int EditHotelDetailsEntry(int hid,string hname,string hrating)
        {
            string commandText = "update HotelMaster SET hname=@hname, hrating=@hrating Where hid=@hid";
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@hid", hid);
            param[1] = new SqlParameter("@hname",hname);        
            param[2] = new SqlParameter("@hrating",hrating);
            
                       
            int k = SqlHelperDL.ExecuteNonQuery(commandText, CommandType.Text, param);
            if (k != 0)
             {
                return 1; 
             }  
                return 0;
            }
        public int EditHotelRoomDetails(int hid, string  rcapacity, string rtype, double rprice) 
        {
            
            string commandText ="update RoomMaster set rcapacity=@rcapacity,rtype=@rtype,rprice=@rprice where hid=@hid AND rtype=@rtype";
            SqlParameter[] param1 = new SqlParameter[4];
            param1[0] = new SqlParameter("@hid",hid);
            param1[1] = new SqlParameter("@rcapacity",rcapacity);
            param1[2] = new SqlParameter("@rtype",rtype);
            param1[3] = new SqlParameter("@rprice",rprice);
            
            return SqlHelperDL.ExecuteNonQuery(commandText, CommandType.Text, param1);
            
            
        }
    }
}