﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace HotelDataLayer
{
    public static class SqlHelperDL
    {
        public static object ExecuteScalar(string commandText, CommandType commandType, SqlParameter[] param)
        {
            SqlConnection con = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["sqlConnectionString"].ToString());
                SqlCommand com = new SqlCommand();
                com.CommandText = commandText;
                com.CommandType = commandType;
                com.Connection = con;
                if (param != null)
                    com.Parameters.AddRange(param);
                con.Open();
                return com.ExecuteScalar();
            }
            catch
            {
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return null;
        }
        public static DataTable GetDataTable(string commandText, CommandType commandType, SqlParameter[] param)
        {
            SqlConnection con = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["sqlConnectionString"].ToString());
                SqlCommand com = new SqlCommand();
                com.CommandText = commandText;
                com.CommandType = commandType;
                com.Connection = con;
                if (param != null)
                    com.Parameters.AddRange(param);
                SqlDataAdapter sda = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
            catch
            {
                con.Close();
            }
            finally
            {
                con.Close();
            }
            return null;
        }
        public static int ExecuteNonQuery(string commandText, CommandType commandType, SqlParameter[] commandParameters)
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(ConfigurationManager.AppSettings["sqlConnectionString"].ToString());
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = commandType;
                command.CommandText = commandText;
                if (commandParameters != null)
                    command.Parameters.AddRange(commandParameters);
                connection.Open();
                return command.ExecuteNonQuery();
            }
            catch
            {
                connection.Close();
            }
            finally
            {
                connection.Close();
            }
            return 0;
        }

        //public static int ExecuteScalar(string commandText, CommandType commandType, SqlParameter[] commandParameters)
        //{
        //    SqlConnection connection = null;
        //    try
        //    {
        //        connection = new SqlConnection(ConfigurationManager.AppSettings["sqlConnectionString"].ToString());
        //        SqlCommand command = new SqlCommand();
        //        command.Connection = connection;
        //        command.CommandType = commandType;
        //        command.CommandText = commandText;
        //        if (commandParameters != null)
        //            command.Parameters.AddRange(commandParameters);
        //        connection.Open();
        //        int cid = Convert.ToInt32(command.ExecuteScalar());
        //        return cid;
        //    }
        //    catch
        //    {
        //        connection.Close();
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return 0;

        //}
    }
}
