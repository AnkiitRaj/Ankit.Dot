﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessObject;

namespace HotelDataLayer
{
    public class ReserveDL
    {

        public ReserveDL()
        {
           
        }
        public DataTable HotelSearchDetails(DateTime cin, DateTime cout, string nop, string rtype)
        {

            string CommandText = "select h.hid,h.hname,h.hrating,count(r.rid) as NoOfRoomsAvailable, r.rprice from RoomMaster r join HotelMaster h on r.hid = h.hid  where (r.ravailable =1)  and (r.rtype=@rtype) and (r.rcapacity=@nop) group by h.hid,h.hname,r.rprice,h.hrating,r.rtype order by h.hid,h.hname,h.hrating;";
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@cin", SqlDbType.Date);
            param[1] = new SqlParameter("@cout", SqlDbType.Date);
            param[2] = new SqlParameter("@nop", SqlDbType.VarChar);
            param[3] = new SqlParameter("@rtype", SqlDbType.VarChar);
            param[0].Value = cin;
            param[1].Value = cout;
            param[2].Value = nop;
            param[3].Value = rtype;

            return SqlHelperDL.GetDataTable(CommandText, CommandType.Text, param);

        }
    }
}
