﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace HotelDataLayer
{
    public class signinDL
    {
        public bool ValidateUser(string userID, string password)
        {
            string commandText = "select upassword from UserMaster where userId=@userID";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@userID", userID);
            string result = System.Text.ASCIIEncoding.ASCII.GetString((byte[])SqlHelperDL.ExecuteScalar(commandText, CommandType.Text, param));
            if (result.ToString() == password)
                return true;
            return false;
        }
    }
}
