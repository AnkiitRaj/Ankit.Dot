﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessObject;

namespace HotelDataLayer
{
    public class cancellationDL
    {
        static string userId;
        string name;
        public bool ValidateUser(long cancel, string userID, DateTime bdate)
        {
            try
            {
                string commandText = "select bid from BookingMaster where userId=@userID and bdate=@bdate";
                SqlParameter[] param = new SqlParameter[2];
                param[0] = new SqlParameter("@userID",userID);
                param[0].Value = userId;
                param[1] = new SqlParameter("@bdate", bdate);
                param[1].Value = bdate;
                name = userId;
                DataTable dt = SqlHelperDL.GetDataTable(commandText, CommandType.Text, param);
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    long bid = long.Parse(dt.Rows[i][0].ToString());
                    if (bid == cancel && userID == userId)
                        return true;
                }
                return false;

                }
            catch(Exception ex)
            {
                Console.WriteLine("Invalid User");
                return false;
            }            
        }
        public bool ValidateUser(string userID, string password)
        {
            string commandText = "select upassword from UserMaster where userId=@userID";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@userID", userID);
            string result = System.Text.ASCIIEncoding.ASCII.GetString((byte[])SqlHelperDL.ExecuteScalar(commandText, CommandType.Text, param));
            if (result.ToString() == password)
                return true;
            return false;
        }
        public DataTable CancelUser(long cancellation)
        {
            string commandText = "select * from UserMaster where userId=@userID";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@userID",cancellation);
            DataTable dt = SqlHelperDL.GetDataTable(commandText, CommandType.Text, param);
            return dt;
        }
      //  public bool CancelTicket(long cancellation)
      //  {
      //      //SqlConnection con = new SqlConnection();
      //      SqlTransaction mytrans = null;
      //      string book="Cancelled";
      //      string room=null;
      //      try
      //      {
      //          string commandTextCustomer = "delete FROM CustomerMaster WHERE userId=@canellation";

      //          string commandTextBooking = "Update BookingMaster set btotalprice@amount,bstatus=@book,rid=@rid where bid=@cancellation";
                
      //          string commandTextPayment = "Update transactionDetails set AmountDebit=@AmountDebit where bid=@cancellation ";

      //          string commandTextPaymentMaster = "Update PaymentMaster set ";

      //          //string 

      //      }
      //      catch
      //      {
      //          con.Close();
      //          mytrans.Rollback();
      //          return false;
      //      }
      //      finally
      //      {
      //          con.Close();
      //      }
      //}
    }
}
