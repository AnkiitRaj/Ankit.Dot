﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace HotelDataLayer
{
    public class adminloginDL
    {
        public bool ValidateAdmin(string aloginId, string aloginPw)
        {
            string commandText = "select aloginPw from AdminMaster where aloginId=@aloginId";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@aloginId", aloginId);
            string result =(string)SqlHelperDL.ExecuteScalar(commandText, CommandType.Text, param);
            if (result == aloginPw)
                return true;
            return false;
        }
    }
}
