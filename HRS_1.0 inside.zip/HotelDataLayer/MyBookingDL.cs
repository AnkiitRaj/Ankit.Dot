﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using HotelBusinessObject;

namespace HotelDataLayer
{
    public class MyBookingDL
    {
        public MyBookingDL()
        { }

        public DataTable UserBookingDetails(string userId)
        {

            string CommandText = "select bid, hid, rid, btotalprice, pid from BookingMaster where userId=@userId;";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@userId", SqlDbType.VarChar);
            param[0].Value = userId;
            return SqlHelperDL.GetDataTable(CommandText, CommandType.Text, param);

        }

        public DataTable SelectHotelBookingDetails(int hid, string userId)
        {
            string CommandText = "select hname, hrating from HotelMaster where hid=@hid;";
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@userId", SqlDbType.VarChar);
            param[1] = new SqlParameter("@hid", SqlDbType.Int);
            param[0].Value = userId;
            param[1].Value = hid;
            return SqlHelperDL.GetDataTable(CommandText, CommandType.Text, param);

        }

        public DataTable SelectCardDetails(string userId)
        {

            string CommandText = "select card_number, current_bal from PaymentMaster where userId=@userId;";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@userId", SqlDbType.VarChar);
            param[0].Value = userId;
            return SqlHelperDL.GetDataTable(CommandText, CommandType.Text, param);

        }

        public bool UpdateAfterCancellation(int hid, int rid, int bid, double amountCredited, string userId, double current_balance, string transactionID, int pid, string card_number,double AmountDebit)
        {
            string CommandText = "insert into transactionDetails(transactionID,pid,userID,card_number,AmountDebit,AmountCredit) values(@transactionID,@pid,@userId,@card_number,@amountDebit,@amountCredited);" +
                                  "Update RoomMaster set ravailable=1 where hid=@hid and rid=@rid;" +
                                  "Update PaymentMaster set current_bal=@current_balance where userId=@userId and pid=@pid;";
            SqlParameter[] param = new SqlParameter[10];
            param[0] = new SqlParameter("@userId", SqlDbType.VarChar);
            param[1] = new SqlParameter("@hid", SqlDbType.Int);
            param[2] = new SqlParameter("@rid", SqlDbType.Int);
            param[3] = new SqlParameter("@current_balance",SqlDbType.Money);
            param[4] = new SqlParameter("@bid", SqlDbType.Int);
            param[5] = new SqlParameter("@transactionID",SqlDbType.VarChar);
            param[6] = new SqlParameter("@pid",SqlDbType.Int);
            param[7] = new SqlParameter("@card_number",SqlDbType.VarChar);
            param[8] = new SqlParameter("@amountDebit",SqlDbType.Money);
            param[9] = new SqlParameter("@amountCredited",SqlDbType.Money);


            param[0].Value = userId;
            param[1].Value = hid;
            param[2].Value = rid;
            param[3].Value = current_balance;
            param[4].Value = bid;
            param[5].Value = transactionID;
            param[6].Value = pid;
            param[7].Value = card_number;
            param[8].Value = 0;
            param[9].Value = amountCredited;

            int res = SqlHelperDL.ExecuteNonQuery(CommandText, CommandType.Text, param);
            if (res > 0)
                return true;
            return false;
        }
    }
}
