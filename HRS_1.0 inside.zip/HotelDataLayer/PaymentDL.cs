﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using HotelBusinessObject;


namespace HotelDataLayer
{
    public class PaymentDL
    {
        public DataTable PaymentCurrentBalnce(string UserID) 
        {
            string commandText = "select pid, current_bal from PaymentMaster where userId = @UserID";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@UserID", SqlDbType.VarChar);
            param[0].Value = UserID;
            return SqlHelperDL.GetDataTable(commandText, CommandType.Text, param);
        }




        public int PaymentEntry(DateTime bdate, DateTime bcin, DateTime bcout, double brprice, int bstatus, int hid, int rid, string userID, int cid, string card_number, string name_on_card,double current_bal, int pid) 
        {
            string commandText = "insert into BookingMaster(bdate,bcheckin,bcheckout,btotalprice,bstatus,hid,rid,userId,cid,pid) values(@bdate,@bcheckin,@bcheckout,@btotalprice,@bstatus,@hid,@rid,@userId,@cid,@pid);" +
                                  "insert into transactionDetails(transactionID,pid,userID,card_number,AmountDebit,AmountCredit) values(@transactionID,@pid,@userId,@card_number,@AmountDebit,@AmountCredit);"+
                                  "update PaymentMaster set current_bal=@currentBal;"+
                                  "update RoomMaster set ravailable=0 where hid=@hid and rid=@rid;";
            
            SqlParameter[] param = new SqlParameter[16];
            param[0] = new SqlParameter("@bdate",SqlDbType.Date);
            param[1] = new SqlParameter("@bcheckin",SqlDbType.Date);
            param[2] = new SqlParameter("@bcheckout",SqlDbType.Date);
            param[3] = new SqlParameter("@btotalprice",SqlDbType.Money);
            param[4] = new SqlParameter("@bstatus",SqlDbType.Bit);
            param[5] = new SqlParameter("@hid", SqlDbType.Int);
            param[6] = new SqlParameter("@rid", SqlDbType.Int);
            param[7] = new SqlParameter("@userId", SqlDbType.VarChar);
            param[8] = new SqlParameter("@cid", SqlDbType.Int);
            param[9] = new SqlParameter("@card_number", SqlDbType.VarChar);
            param[10] = new SqlParameter("@name_on_card", SqlDbType.VarChar);            
            param[11] = new SqlParameter("@transactionID", SqlDbType.VarChar);
            param[12] = new SqlParameter("@AmountDebit", SqlDbType.Money);
            param[13] = new SqlParameter("@AmountCredit", SqlDbType.Money);
            param[14] = new SqlParameter("@currentBal", SqlDbType.Money);
            param[15] = new SqlParameter("@pid", SqlDbType.Int);
            Random random = new Random();
            long tran = 0;
            for (int i = 0; i < 16; i++)
            {
                tran += (long)(Math.Pow(10, i) * random.Next(1, 10));
            }
            string transactionID = tran.ToString();
            
            param[0].Value = bdate;
            param[1].Value = bcin;
            param[2].Value = bcout;
            param[3].Value = brprice;
            param[4].Value = 1;
            param[5].Value = hid;
            param[6].Value = rid;
            param[7].Value = userID;
            param[8].Value = cid;
            param[9].Value = card_number;
            param[10].Value = name_on_card;      
            param[11].Value = transactionID;
            param[12].Value = brprice;
            param[13].Value = 0;
            param[14].Value = (current_bal - brprice);
            param[15].Value = pid;
            return SqlHelperDL.ExecuteNonQuery(commandText, CommandType.Text, param);
            
        }
        }
    }
