﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using HotelBusinessObject;

namespace HotelDataLayer
{
    public class AddHotelDL
    {
        public AddHotelDL()
        { }

        public int AddHotelDetailsEntry(HotelBusinessObject.AddHotelBO Abo)
        {
            SqlParameter[] param = new SqlParameter[6];
            param[0] = new SqlParameter("@hname",Abo.hname);
            param[1] = new SqlParameter("@hlocation",Abo.hlocation);
            param[2] = new SqlParameter("@hrating",Abo.hrating);
            param[3] = new SqlParameter("@rtype",Abo.rtype);
            param[4] = new SqlParameter("@rprice",Abo.rprice);
            param[5] = new SqlParameter("@rcapacity",Abo.rcapacity);

           
            string commandText = "insert into HotelMaster(hname,hlocation,hrating) values(@hname,@hlocation,@hrating)";
            int k = SqlHelperDL.ExecuteNonQuery(commandText, CommandType.Text, param);
            if (k != 0)
             {
                return 1; 
             }  
                return 0;
            }
        public int HotelRoomDetails(HotelBusinessObject.AddHotelBO Abo) 
        {
            string commandText = "select max(hid) from HotelMaster Where hid!=@hid;";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@hid",SqlDbType.Int);
            param[0].Value = 0;
            DataTable dt = SqlHelperDL.GetDataTable(commandText,CommandType.Text,param);  
            int hid = int.Parse(dt.Rows[0][0].ToString());
            
            commandText ="insert into RoomMaster(hid,rcapacity,ravailable,rwifi,rtype,rprice) values(@hid,@rcapacity,@ravailable,@rwifi,@rtype,@rprice)";
            SqlParameter[] param1 = new SqlParameter[6];
            param1[0] = new SqlParameter("@hid",hid);
            param1[1] = new SqlParameter("@rcapacity",Abo.rcapacity);
            param1[2] = new SqlParameter("@ravailable",1);
            param1[3] = new SqlParameter("@rwifi",1);
            param1[4] = new SqlParameter("@rtype",Abo.rtype);
            param1[5] = new SqlParameter("@rprice",Abo.rprice);
            
            return SqlHelperDL.ExecuteNonQuery(commandText, CommandType.Text, param1);
            
            
        }

 
        }
    }

