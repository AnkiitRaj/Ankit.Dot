﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using HotelBusinessObject;
using HotelDataLayer;

namespace HotelBusinessLayer
{
    public class personalDetailsBL
    {
        public  int personalDetailsEntry(HotelBusinessObject.personalDetails Hbo)
        {
            
                HotelDataLayer.personalDetailsDL p = new personalDetailsDL();
                int res = p.personalDetailsEntry(Hbo);
                return res;
            
        }
        public DataTable PersonalDetails(string userID) 
        {
            personalDetailsDL pdl = new personalDetailsDL();
            return pdl.PersonalDetails(userID);
            
        }
        public DataTable HotelDetails(int hid) 
        {
            personalDetailsDL pdl = new personalDetailsDL();
            return pdl.HotelDetails(hid);
        }
       
    }
}
