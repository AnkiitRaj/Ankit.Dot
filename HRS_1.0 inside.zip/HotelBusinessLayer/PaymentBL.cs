﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using HotelBusinessObject;
using HotelDataLayer;


namespace HotelBusinessLayer
{
    public class PaymentBL
    {
        public PaymentBL()
        {
            // TODO:
        }

        public DataTable PaymentCurrentBalnce(string UserID) 
        {
            PaymentDL pdl = new PaymentDL();
            return pdl.PaymentCurrentBalnce(UserID);
        }
        public int PaymentEntry(DateTime bdate, DateTime bcin, DateTime bcout, double money, int bstatus, int hid, int rid, string userID, int cid, string card_number, string name_on_card,double current_bal, int pid) 
        {
            PaymentDL pbl = new PaymentDL();
            int res = pbl.PaymentEntry(bdate, bcin, bcout, money, bstatus, hid, rid, userID, cid, card_number, name_on_card,current_bal, pid);
            return res;
        }
    }
}
