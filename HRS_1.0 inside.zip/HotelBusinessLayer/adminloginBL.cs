﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelBusinessObject;
using HotelDataLayer;
using System.Data;

namespace HotelBusinessLayer
{
    public class adminloginBL
    {
        public bool ValidateLogin(string aloginId, string aloginPw)
        {
            adminloginDL ald = new adminloginDL();
            bool res = ald.ValidateAdmin(aloginId, aloginPw);
            return res;
        }
    }
}
