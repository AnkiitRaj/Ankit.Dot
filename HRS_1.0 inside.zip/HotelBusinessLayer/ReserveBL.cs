﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using HotelBusinessObject;
using HotelDataLayer;

namespace HotelBusinessLayer
{
    public class ReserveBL
    {
        public DataTable HotelSearchDetails(DateTime cin, DateTime cout, string nop, string rtype)
        {
            HotelDataLayer.ReserveDL rdl = new ReserveDL();
            return rdl.HotelSearchDetails(cin,cout,nop,rtype);
        }
    }
}
