﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelBusinessObject;
using HotelDataLayer;
using System.Data;

namespace HotelBusinessLayer
{
    public class SignUpBL
    {
        public int SignUpUser(HotelBusinessObject.SignUp s, string cardNumber) 
        {
            SignUpDL Dl = new SignUpDL();
            int res = Dl.SignUpUser(s, cardNumber);
            return res;
        }
    }
}
