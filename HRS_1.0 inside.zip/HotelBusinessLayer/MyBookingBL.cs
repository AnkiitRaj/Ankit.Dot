﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using HotelBusinessObject;
using HotelDataLayer;

namespace HotelBusinessLayer
{
    public class MyBookingBL
    {
        public DataTable UserBookingDetails(string userId)
        {
            HotelDataLayer.MyBookingDL mdl = new HotelDataLayer.MyBookingDL();
            return mdl.UserBookingDetails(userId);
        }
        public DataTable SelectHotelBookingDetails(int hid, string userId)
        {
            HotelDataLayer.MyBookingDL mbd = new HotelDataLayer.MyBookingDL();
            return mbd.SelectHotelBookingDetails(hid,userId);
        }

        public bool UpdateAfterCancellation(int hid, int rid, int bid, double amountCredited, string userId, double current_balance, string transactionID, int pid, string card_number, double AmountDebit)
        {
            HotelDataLayer.MyBookingDL mdu = new HotelDataLayer.MyBookingDL();
            return mdu.UpdateAfterCancellation(hid, rid, bid, amountCredited, userId, current_balance, transactionID, pid, card_number, AmountDebit);
        }

        public DataTable SelectCardDetails(string userId)
        {
            HotelDataLayer.MyBookingDL mcd = new HotelDataLayer.MyBookingDL();
            return mcd.SelectCardDetails(userId);
        }
    }
}
