﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelBusinessObject;
using HotelDataLayer;
using System.Data;

namespace HotelBusinessLayer
{
    public class signinBL
    {
        public bool ValidateUser(string userID, string upassword)
        {
            signinDL sdl = new signinDL();
            bool res = sdl.ValidateUser(userID,upassword);
            return res;

        }
        
    }
}
