﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using HotelBusinessObject;
using HotelDataLayer;

namespace HotelBusinessLayer
{
    public class AddHotelBL
    {
        public int AddHotelDetailsEntry(HotelBusinessObject.AddHotelBO Abo) 
        {
            HotelDataLayer.AddHotelDL adl = new AddHotelDL();
            return adl.AddHotelDetailsEntry(Abo);
        }
        public int HotelRoomDetails(HotelBusinessObject.AddHotelBO Abo) 
        {
            HotelDataLayer.AddHotelDL adl = new AddHotelDL();
            return adl.HotelRoomDetails(Abo);
        }
    }
}
