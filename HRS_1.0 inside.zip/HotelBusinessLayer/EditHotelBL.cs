﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using HotelBusinessObject;
using HotelDataLayer;

namespace HotelBusinessLayer
{
    public class EditHotelBL
    {
        public int EditHotelDetailsEntry(int hid, string hname, string hrating)
        {
            HotelDataLayer.EditHotelDL edl = new EditHotelDL();
            return edl.EditHotelDetailsEntry(hid, hname, hrating);
        }
        public int EditHotelRoomDetails(int hid, string  rcapacity, string rtype, double rprice)
        {
            HotelDataLayer.EditHotelDL edl = new EditHotelDL();
            return edl.EditHotelRoomDetails( hid,  rcapacity, rtype,  rprice);
        }
    }
}
