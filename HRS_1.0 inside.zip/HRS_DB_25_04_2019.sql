create database HRS2;
use HRS2;
create table UserMaster
(
fname varchar(200) not null,
lname varchar(200) not null,
phoneNumber varchar(200) not null,
userId varchar(200) primary key,
upassword varbinary(max) not null
);


create table CustomerMaster
(
cid int identity primary key,
cname varchar(200) not null,
cage varchar(200) not null,
cgender varchar(200) not null,
userId varchar (200) not null,
foreign key (userId) references UserMaster(userId)
);



create table HotelMaster
(
hid int identity primary key,
hname varchar(200) not null,
hlocation varchar(200) not null,
hrating varchar(200) not null
);


ALTER table HotelMaster
Alter column hid int;
hname varchar(200) not null,
hlocation varchar(200) not null,
hrating varchar(200) not null
);



create table RoomMaster
(
rid int identity primary key,
hid int not null,
rcapacity varchar(200) not null,
ravailable bit not null,
rwifi bit not null,
rtype  varchar(200) not null,
rprice money not null,
foreign key (hid) references HotelMaster(hid)
);


create table PaymentMaster
(
pid int identity primary key,
card_number varchar(200) not null,
name_on_card varchar(200) not null,
userId varchar(200) not null,
current_bal money default(40000),
foreign key(userId) references UserMaster(userId)
);

select * from BookingMaster;
select * from PaymentMaster;

select * from transactionDetails;
create table BookingMaster
(
bid int identity primary key,
bdate date not null, 
bcheckin date not null,
bcheckout date not null,
btotalprice money not null,
bstatus bit not null,
hid int not null,
rid int not null,
userId varchar(200) not null,
cid int not null,
pid int not null,
foreign key (cid) references CustomerMaster(cid),
foreign key (userId) references UserMaster(userId),
foreign key (hid) references HotelMaster(hid),
foreign key (rid) references RoomMaster(rid),
foreign key (pid) references PaymentMaster(pid)
);





Create table transactionDetails
(
transactionID varchar(50) primary key,
pid int not null,
userId varchar(200) not null,
card_number varchar(50) not null,
AmountDebit money not null,
AmountCredit Money not null,
foreign key (pid) references PaymentMaster(pid)
)

sp_Help PaymentMaster;

select * from PaymentMaster;
select * from  transactionDetails;

drop table PaymentMaster;


alter table PaymentMaster drop constraint [userId]

alter table PaymentMaster drop column cid;

select * from PaymentMaster;
select * from AdminMaster;
create table AdminMaster
(
aloginId varchar(200) not null,
aloginPw varchar(200) not null
);

insert into AdminMaster values('Admin@Sank.com','Admin@666');

select h.hid,r.rid from HotelMaster h join RoomMaster r on h.hid=r.rid  join BookingMaster b on b.rid=r.rid;

select h.hid, h.hname, count(r.rid) as NoOfRoomsAvailable from RoomMaster r 
join HotelMaster h on r.hid = h.hid
join BookingMaster b on h.hid=b.hid
where (r.ravailable =1) and (b.bcheckin not between '2019-10-05 11:00:00.000' and '2019-05-06 11:00:00.000') and h.hlocation='Kolkata'
group by h.hname,h.hid
order by h.hname;

select * from RoomMaster  order by hid;

select * from BookingMaster;

select * from UserMaster;

select * from CustomerMaster;

Insert into CustomerMaster values('Ankit Raj',24,'Male','Ankit@gmail.com');
Insert into CustomerMaster values('Divyanjali Sharma',22,'Female',9875632142,'divyanjali@gmail.com');
Insert into CustomerMaster values('Nilanjan  Nanda',35,'Male',7894561233,'nilanjan@gmail.com');
Insert into CustomerMaster values('Kshatriya Prabhu',21,'Male',9442693795,'Prabu@gmail.com');
Insert into CustomerMaster values('Pradeep Kumar',34,'Male',6541239873,'pradeep@gmail.com');
Insert into CustomerMaster values('Sanjeev Mishra',27,'Male',7866003513,'sanjiv@gmail.com');
Insert into CustomerMaster values('Soumen Chowdhury',32,'Male',8961413350,'soumen@gmail.com');
Insert into CustomerMaster values('Subham Chowdhury',45,'Male',9831254687,'subham@gmail.com');

select * from HotelMaster;

Insert into HotelMaster values('Central Heritage Resort','Kolkata',3);
Insert into HotelMaster values('The Orchid London','Kolkata',4);
Insert into HotelMaster values('Hotel Oberoi Grand','Kolkata',3);
Insert into HotelMaster values('Hotel Hayatt Regency','Kolkata',3);
Insert into HotelMaster values('Hotel Novotel','Kolkata',2);
Insert into HotelMaster values('Hotel Pride Plaza','Kolkata',3);
Insert into HotelMaster values('Central Heritage Resort and Spa','Kolkata',3);


select * from RoomMaster  where ravailable = 1 order by hid ;


-- old db
Insert into RoomMaster values(1,3,1,1,'Ac',8999);
Insert into RoomMaster values(1,2,1,1,'Non-Ac',7499);
Insert into RoomMaster values(1,3,0,1,'Deluxe',9799);
Insert into RoomMaster values(1,2,0,1,'Ac',89999);
Insert into RoomMaster values(1,2,1,1,'Deluxe',9799);
Insert into RoomMaster values(1,2,1,1,'Ac',8999);
Insert into RoomMaster values(1,2,0,1,'Deluxe',9799);

Insert into RoomMaster values(2,3,1,1,'Ac',7459);
Insert into RoomMaster values(2,2,0,1,'Non-Ac',5999);
Insert into RoomMaster values(2,3,1,1,'Deluxe',8999);
Insert into RoomMaster values(2,2,1,1,'Ac',7459);


Insert into RoomMaster values(3,2,0,1,'Non-Ac',5999);
Insert into RoomMaster values(3,3,1,1,'Deluxe',8999);
Insert into RoomMaster values(3,2,1,1,'Ac',7459);

Insert into RoomMaster values(4,3,1,1,'Non-Ac',5599);
Insert into RoomMaster values(4,2,0,1,'Deluxe',7799);
Insert into RoomMaster values(4,3,1,1,'Ac',6759);

Insert into RoomMaster values(5,3,1,1,'Non-Ac',4699);
Insert into RoomMaster values(5,2,0,1,'Deluxe',8899);
Insert into RoomMaster values(5,3,1,1,'Ac',7459);

Insert into RoomMaster values(6,2,0,1,'Deluxe',9899);
Insert into RoomMaster values(6,3,1,1,'Ac',7419);

Insert into RoomMaster values(7,2,0,1,'Ac',7419);
Insert into RoomMaster values(7,2,1,1,'Non-Ac',6699);

-- new db
Insert into RoomMaster values(1,1,1,1,'Ac',1500);
Insert into RoomMaster values(1,2,1,1,'Ac',1950);
Insert into RoomMaster values(1,3,1,1,'Ac',2569);
Insert into RoomMaster values(1,1,1,1,'Non-Ac',800);
Insert into RoomMaster values(1,2,1,1,'Non-Ac',1200);
Insert into RoomMaster values(1,3,1,1,'Non-Ac',1600);
Insert into RoomMaster values(1,1,1,1,'Deluxe',5000);
Insert into RoomMaster values(1,2,1,1,'Deluxe',5000);
Insert into RoomMaster values(1,3,1,1,'Deluxe',5000);

Insert into RoomMaster values(2,1,1,1,'Ac',1200);
Insert into RoomMaster values(2,2,1,1,'Ac',1750);
Insert into RoomMaster values(2,3,1,1,'Ac',2300);
Insert into RoomMaster values(2,1,1,1,'Non-Ac',500);
Insert into RoomMaster values(2,2,1,1,'Non-Ac',900);
Insert into RoomMaster values(2,3,1,1,'Non-Ac',1200);
Insert into RoomMaster values(2,1,1,1,'Deluxe',3000);
Insert into RoomMaster values(2,2,1,1,'Deluxe',4000);
Insert into RoomMaster values(2,3,1,1,'Deluxe',5000);

Insert into RoomMaster values(3,1,1,1,'Ac',700);
Insert into RoomMaster values(3,2,1,1,'Ac',950);
Insert into RoomMaster values(3,3,1,1,'Ac',1269);
Insert into RoomMaster values(3,1,1,1,'Non-Ac',450);
Insert into RoomMaster values(3,2,1,1,'Non-Ac',550);
Insert into RoomMaster values(3,3,1,1,'Non-Ac',600);
Insert into RoomMaster values(3,1,1,1,'Deluxe',1800);
Insert into RoomMaster values(3,2,1,1,'Deluxe',2000);
Insert into RoomMaster values(3,3,1,1,'Deluxe',3000);

Insert into RoomMaster values(4,1,1,1,'Ac',1100);
Insert into RoomMaster values(4,2,0,1,'Ac',1250);
Insert into RoomMaster values(4,3,1,1,'Ac',1369);
Insert into RoomMaster values(4,1,1,1,'Non-Ac',650);
Insert into RoomMaster values(4,2,1,1,'Non-Ac',850);
Insert into RoomMaster values(4,3,1,1,'Non-Ac',950);
Insert into RoomMaster values(4,1,1,1,'Deluxe',2000);
Insert into RoomMaster values(4,2,1,1,'Deluxe',2500);
Insert into RoomMaster values(4,3,1,1,'Deluxe',3000);

Insert into RoomMaster values(5,1,1,1,'Ac',2500);
Insert into RoomMaster values(5,2,1,1,'Ac',3550);
Insert into RoomMaster values(5,3,1,1,'Ac',4500);
Insert into RoomMaster values(5,1,1,1,'Deluxe',6000);
Insert into RoomMaster values(5,2,1,1,'Deluxe',7000);
Insert into RoomMaster values(5,3,1,1,'Deluxe',9000);

Insert into RoomMaster values(6,1,1,1,'Ac',1500);
Insert into RoomMaster values(6,2,1,1,'Ac',1950);
Insert into RoomMaster values(6,3,1,1,'Ac',2569);
Insert into RoomMaster values(6,1,1,1,'Non-Ac',800);
Insert into RoomMaster values(6,2,1,1,'Non-Ac',1200);
Insert into RoomMaster values(6,3,1,1,'Non-Ac',1600);
Insert into RoomMaster values(6,1,1,1,'Deluxe',5000);
Insert into RoomMaster values(6,2,1,1,'Deluxe',5000);
Insert into RoomMaster values(6,3,1,1,'Deluxe',5000);

Insert into RoomMaster values(7,1,1,1,'Ac',1700);
Insert into RoomMaster values(7,2,1,1,'Ac',1950);
Insert into RoomMaster values(7,3,1,1,'Ac',2200);
Insert into RoomMaster values(7,1,1,1,'Non-Ac',900);
Insert into RoomMaster values(7,2,1,1,'Non-Ac',1100);
Insert into RoomMaster values(7,3,1,1,'Non-Ac',1200);
Insert into RoomMaster values(7,1,1,1,'Deluxe',4000);
Insert into RoomMaster values(7,2,0,1,'Deluxe',5000);
Insert into RoomMaster values(7,3,1,1,'Deluxe',5000);

select * from RoomMaster;
drop table RoomMaster;
update RoomMaster set ravailable=1;


select * from BookingMaster;
Insert into BookingMaster values('2019-04-15','2019-04-16','2019-04-17',2569,1,1,3,'Ankit@gmail.com',1);
Insert into BookingMaster values('2019-04-15','2019-04-17','2019-04-18',800,1,1,4,'Ankit@gmail.com',1);
Insert into BookingMaster values('2019-04-16','2019-04-19','2019-04-21',10000,1,1,7,'Ankit@gmail.com',1);
Insert into BookingMaster values('2019-04-21','2019-04-22','2019-04-23',8999,1,2,9,'divyanjali@gmail.com',2);
Insert into BookingMaster values('2019-04-23','2019-04-24','2019-04-26',9799,1,3,12,'nilanjan@gmail.com',3);
Insert into BookingMaster values('2019-04-26','2019-04-27','2019-04-29',7499,1,4,16,'Prabu@gmail.com',4);
Insert into BookingMaster values('2019-04-29','2019-04-30','2019-05-02',7499,1,5,19,'pradeep@gmail.com',5);
Insert into BookingMaster values('2019-05-02','2019-05-03','2019-05-05',7499,1,6,21,'sanjiv@gmail.com',6);
Insert into BookingMaster values('2019-05-05','2019-05-06','2019-05-08',7499,1,7,23,'soumen@gmail.com',7);

delete from BookingMaster;

delete from BookingMaster
select h.hid,h.hname,h.hrating,r.rtype,count(r.rid) as NoOfRoomsAvailable, r.rprice from RoomMaster r join HotelMaster h on r.hid = h.hid  where (r.ravailable =1)  and (r.rtype='Deluxe') and (r.rcapacity=2) group by h.hid,h.hname,r.rprice,h.hrating,r.rtype order by h.hid,h.hname,h.hrating;
select  *  from PaymentMaster;

Insert into PaymentMaster values('4564 6798 2346 9567','Ankit Raj','Ankit@gmail.com');
Insert into PaymentMaster values('2019-04-15','4564 6798 2346 9567','Ankit Raj',2,1,'Ankit@gmail.com');
Insert into PaymentMaster values('2019-04-18','4564 6798 2346 9567','Ankit Raj',3,1,'Ankit@gmail.com');
Insert into PaymentMaster values(4,'2019-04-21','8697 5364 5768 2435','Divyanjali Sharma',4,2,'divyanjali@gmail.com');
Insert into PaymentMaster values(5,'2019-04-23','5746 6857 2456 3857','Nilanjan  Nanda',5,3,'nilanjan@gmail.com');
Insert into PaymentMaster values(6,'2019-04-26','9354 5769 2458 6735','Kshatriya Prabhu',6,4,'Prabu@gmail.com');
Insert into PaymentMaster values(7,'2019-04-29','1435 5739 5639 6846','Pradeep Kumar',7,5,'pradeep@gmail.com');
Insert into PaymentMaster values(8,'2019-05-02','3857 6753 9265 3857','Sanjeev Mishra',8,6,'sanjiv@gmail.com');
Insert into PaymentMaster values(9,'2019-05-05','7583 5648 6758 8674','Soumen Chowdhury',9,7,'soumen@gmail.com');


select r.hid,r.rid from RoomMaster r left join BookingMaster b on r.rid=b.rid where r.ravailable=1 group by r.hid,r.rid  order by r.hid;

select r.hid,count(r.rid) as NumberOfRoomsAvailable from RoomMaster r where r.ravailable=1 group by r.hid order by r.hid;

select * from RoomMaster where ravailable=1 order by hid;
select * from RoomMaster order by hid;
select * from BookingMaster;

select h.hid,h.hname, count(r.rid) as NoOfRoomsAvailable from RoomMaster r 
join HotelMaster h on r.hid = h.hid
join BookingMaster b on h.hid=b.hid
where (r.ravailable =1) and (b.bcheckin not between '2019-04-13 11:00:00 AM' and '2019-04-18 10:00:00 AM')
group by h.hid,h.hname
order by h.hid,h.hname;

Create Procedure ss_CustomerMaster
(
@cname VARCHAR(200),
@cage VARCHAR(200),
@cgender VARCHAR(200),
@userId VARCHAR(200),
@StatementType nvarchar(20) =''
)
AS
BEGIN
IF @StatementType = 'Insert'
BEGIN
insert into CustomerMaster(cname,cage,cgender,userId) values(@cname,@cage,@cgender,@userId)
END
IF @StatementType ='Select'
BEGIN
select * from CustomerMaster
END
IF @StatementType = 'Update'
BEGIN
UPDATE CustomerMaster SET
cname = @cname,cage = @cage,cgender = @cgender,userId = @userId
where userId = @userId
END
else IF @StatementType = 'Delete'
BEGIN
DELETE FROM CustomerMaster Where userId = @userId
END
end


select h.hid,h.hname,h.hrating,r.rtype, r.rprice, count(r.rid) as NoOfRoomsAvailable from RoomMaster r join HotelMaster h on r.hid = h.hid join BookingMaster b on h.hid=b.hid
where (r.ravailable = 1) and (b.bcheckin not between '2019-04-21' and '2019-04-22') and (r.rtype='Ac') 
group by h.hid,h.hname,r.rprice,h.hrating,r.rtype, r.rid order by h.hid,h.hname,h.hrating,r.rtype,NoOfRoomsAvailable;


select * from UserMaster;
select * from CustomerMaster;
select * from RoomMaster;
select * from BookingMaster;
select * from PaymentMaster;
select * from transactionDetails;
select * from HotelMaster;









delete from BookingMaster where bid=10;

select sum(AmountDebit) as "Earning Amounts" from transactionDetails


delete CustomerMaster where cid=(1);

update HotelMaster SET hname=@hname, hlocation=@hlocation, hrating=@hrating

alter table transactionDetails drop constraint FK__transaction__pid__4D94879B
alter table transactionDetails drop column pid;

alter table BookingMaster add column pid;

ALTER TABLE BookingMaster 
ADD FOREIGN KEY (pid) REFERENCES PaymetnMaster(pid);


select * from RoomMaster;

select rtype as "Room Type", count(*) as "Available Rooms" from RoomMaster where ravailable=1 group by rtype;