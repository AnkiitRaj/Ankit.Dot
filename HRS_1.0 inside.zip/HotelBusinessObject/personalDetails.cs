﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HotelBusinessObject
{
    public class personalDetails
    {
        public personalDetails()
        { }
        public string cname;
        public string cage;
        public string cgender;
        public string userId;
        
        public personalDetails(string cname, string cage, string cgender, string userId)
        {
            this.cname = cname;
            this.cage = cage;
            this.cgender = cgender;
            this.userId = userId;
        }

        
    }
}
