﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelBusinessObject
{
    public class SignUp
    {
        public string fname;
        public string lname;
        public string phoneNo;
        public string userId;
        public string upassword;

        public SignUp() { }
        public SignUp(string fname, string lname, string phoneNo, string userId, string upassword)
        {
            this.fname = fname;
            this.lname = lname;
            this.phoneNo = phoneNo;
            this.userId = userId;
            this.upassword = upassword;
        }
    }
}
