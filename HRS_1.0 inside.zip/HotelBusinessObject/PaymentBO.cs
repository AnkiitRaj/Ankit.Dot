﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelBusinessObject
{
    public class PaymentBO
    {
        public string card_number;
        public string name_on_card;
        public string userId;
        public double current_bal;

        public PaymentBO()
        {
 
        }

        public PaymentBO(string card_number, string name_on_card, string userId, double current_bal)
        {
            this.card_number = card_number;
            this.name_on_card = name_on_card;
            this.userId = userId;
            this.current_bal = current_bal;
        }

    }
}
