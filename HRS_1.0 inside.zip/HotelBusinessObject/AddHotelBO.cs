﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HotelBusinessObject
{
    public class AddHotelBO
    {
        public AddHotelBO()
        { }

        public string hname;
        public string hlocation;
        public string hrating;
        public string rtype;
        public double rprice;
        public string rcapacity;


        public AddHotelBO(string hname, string hlocation, string hrating,string rtype,double rprice,string rcapacity)
        {
            this.hname = hname;
            this.hlocation = hlocation;
            this.hrating = hrating;
            this.rtype = rtype;
            this.rprice = rprice;
            this.rcapacity = rcapacity;
        }
    }
}
