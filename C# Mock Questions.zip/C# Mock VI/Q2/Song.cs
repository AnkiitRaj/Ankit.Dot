using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Song
{
    //fill code here.
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private string _artist;

    public string Artist
    {
        get { return _artist; }
        set { _artist = value; }
    }
    private string _songType;

    public string SongType
    {
        get { return _songType; }
        set { _songType = value; }
    }
    private double _rating;

    public double Rating
    {
        get { return _rating; }
        set { _rating = value; }
    }
    private int _numberOfDownloads;

    public int NumberOfDownloads
    {
        get { return _numberOfDownloads; }
        set { _numberOfDownloads = value; }
    }
    private DateTime _dateDownloaded;

    public DateTime DateDownloaded
    {
        get { return _dateDownloaded; }
        set { _dateDownloaded = value; }
    }

    public Song() { }
    public Song(string _name, string _artist, string _songType, double _rating, int _numberOfDownloads, DateTime _dateDownloaded)
    {
        this._name = _name;
        this._artist = _artist;
        this._songType = _songType;
        this._rating = _rating;
        this._numberOfDownloads = _numberOfDownloads;
        this._dateDownloaded = _dateDownloaded;
    }

    public override string ToString()
    {
        return String.Format("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", this.Name, this.Artist, this.SongType, this.Rating, this.NumberOfDownloads, this.DateDownloaded.ToString("dd-MM-yyyy"));
    }

    public static Song CreateSong(string song)
    {
        
        //fill code here.
        string[] str = song.Split(',');
        DateTime dt = DateTime.ParseExact(str[5], "dd-MM-yyyy", null);
        double rating = Convert.ToDouble(str[3]);
        int nod = Convert.ToInt32(str[4]);
        return new Song(str[0], str[1], str[2], rating, nod, dt);
    }
}