using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        PlayList playList = new PlayList();
	    Console.WriteLine("Enter the Play list name:");
	    String name = Console.ReadLine();
        List<Song> _songList = new List<Song>();
        PlayList pl = new PlayList(name, _songList);
        //fill code here.
        while (true)
        {
            Console.WriteLine("1.Add Song\n2.Remove Song\n3.Display\n4.Exit\nEnter your choice:");
            int choice = Convert.ToInt32(Console.ReadLine());
            //fill code here.
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Enter the number of Songs:");
                    int nos = int.Parse(Console.ReadLine());
                    for (int i = 0; i < nos; i++)
                    {
                        Console.WriteLine("Enter song {0} detail:", (i + 1));
                        string str = Console.ReadLine();
                        Song song = Song.CreateSong(str);
                        pl.AddSongToPlaylist(song);
                    }
                    break;

                case 2:
                    Console.WriteLine("Enter the name of the song to be deleted:");
                    string songName = Console.ReadLine();
                    bool val = pl.RemoveSongFromPlaylist(songName);
                    if (val)
                        Console.WriteLine("Song successfully deleted");
                    else
                        Console.WriteLine("Song not found in the Play List");
                    break;

                case 3:
                    pl.DisplaySongs();
                    break;

                case 4:
                    Environment.Exit(0);
                    break;


            }
        }
    }
}