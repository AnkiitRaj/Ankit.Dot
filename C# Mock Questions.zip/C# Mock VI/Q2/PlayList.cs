using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class PlayList
{
    //fill code here.
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private List<Song> _songList;

    internal List<Song> SongList
    {
        get { return _songList; }
        set { _songList = value; }
    }

    public PlayList() { }

    public PlayList(string _name, List<Song> _songList)
    {
        this._name = _name;
        this._songList = _songList;
    }

    public void AddSongToPlaylist(Song song)
    {
        _songList.Add(song);
    }

    public bool RemoveSongFromPlaylist(String name)
    {
        //fill code here.

        foreach (Song s in _songList)
        {
            if (s.Name == name)
            {
                _songList.Remove(s);
                return true;
            }
        }
        return false;
    }
    public void DisplaySongs()
    {
            //fill code here.
        if (_songList.Count > 0)
        {
            Console.WriteLine("Songs in "+this._name);
            Console.WriteLine("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", "Name", "Artist", "Song Type", "Rating", "No of Download", "Date Downloaded"); 
            foreach (Song s in _songList)
            {
                Console.WriteLine(s.ToString());
            }
        }
        else
        {
            Console.WriteLine("No song to show");
        }
    }
}