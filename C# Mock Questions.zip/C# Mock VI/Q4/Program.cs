using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Song> list = new List<Song>();
        Console.WriteLine("Enter the number of the songs:");
        int n = Convert.ToInt32(Console.ReadLine());
        //fill code here.
        for (int i = 0; i < n; i++)
        {
            string split = Console.ReadLine();
            Song s = Song.CreateSong(split);
            list.Add(s);
        }
        Console.WriteLine("Enter a type to sort:\n1.Sort by name\n2.Sort by Rating\n3.Sort by Popularity");
        int ch = int.Parse(Console.ReadLine());
        switch (ch)
        {
            case 1:
                list.Sort();
                Console.WriteLine("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", "Name", "Artist", "Song Type", "Date of Download", "Rating", "No of Downloads");
                foreach (Song s in list)
                {
                    Console.WriteLine(s.ToString());
                }
                break;
            case 2:
                RatingComparer rc = new RatingComparer();
                list.Sort(rc);
                Console.WriteLine("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", "Name", "Artist", "Song Type", "Date of Download", "Rating", "No of Downloads");
                foreach (Song s in list)
                {
                    Console.WriteLine(s.ToString());
                }
                break;
            case 3:
                PopularityComparer pc = new PopularityComparer();
                list.Sort(pc);
                Console.WriteLine("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", "Name", "Artist", "Song Type", "Date of Download", "Rating", "No of Downloads");
                foreach (Song s in list)
                {
                    Console.WriteLine(s.ToString());
                }
                break;
        }
        Console.ReadKey();
    }
}