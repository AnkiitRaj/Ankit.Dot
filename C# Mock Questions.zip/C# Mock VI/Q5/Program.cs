/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Song []song = new Song[2];
	    for(int index = 0; index < 2; index++){
		    Console.WriteLine("Enter song "+(index+1)+" detail:");
            string str = Console.ReadLine();
            String[] split = str.Split(',') ;
            double rating = Convert.ToDouble(split[3]);
            int _number = Convert.ToInt32(split[4]);
            string date = split[5];           
            DateTime date1 = DateTime.ParseExact(date, "dd-MM-yyyy", null);
            song[index]=new Song(split[0],split[1],split[2],rating,_number,date1);
            //fill code here.
	    }
        //fill code here.
        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine("Song "+(i+1)+":");
            Console.WriteLine(song[i].ToString());
        }
        bool b = IsSame(song);
        if (b == true)
        {
            Console.WriteLine("Song 1 is same as Song 2");
        }
        else
        {
            Console.WriteLine("Song 1 and Song 2 are different");
        }
        Console.ReadKey();
    }

    public static bool IsSame(Song[] song)
    {
        if (song[0].Name == song[1].Name && song[0].Artist == song[1].Artist && song[0].SongType == song[1].SongType)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}*/

/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Song> list = new List<Song>();
        SongBO sb = new SongBO();
        Console.WriteLine("Enter the number of Songs:");
        int n = Convert.ToInt32(Console.ReadLine());
        //fill code here.
        for (int i = 0; i < n; i++)
        {
            string[]split = Console.ReadLine().Split(',');
            double rating = Convert.ToDouble(split[3]);
            int _number = Convert.ToInt32(split[4]);
            string date = split[5];
            DateTime date1 = DateTime.ParseExact(date, "dd-MM-yyyy", null);
            Song s = new Song(split[0], split[1], split[2], rating, _number, date1);
            list.Add(s);
        }
        Console.WriteLine("Enter a search type:\n1.Song Type\n2.Date of Download\n3.Rating");
        int choice = Convert.ToInt32(Console.ReadLine());
        //fill code here.
        SongBO bo=new SongBO();
        switch (choice)
        {
            case 1:
                Console.WriteLine("Enter the song type:");
                string type = Console.ReadLine();
                List<Song> list1 = bo.FindSong(list, type);
                Console.WriteLine("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", "Name", "Artist", "Song Type", "Rating", "No of Download", "Date of Download");

                foreach (var obj in list1)
                {
                    Console.WriteLine(obj.ToString());
                }
                break;
            case 2:
                Console.WriteLine("Enter the date:");
                DateTime date = DateTime.ParseExact(Console.ReadLine(), "dd-MM-yyyy", null);
                List<Song> list2 = bo.FindSong(list, date);
                Console.WriteLine("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", "Name", "Artist", "Song Type", "Rating", "No of Download", "Date of Download");

                foreach (var obj in list2)
                {
                    Console.WriteLine(obj.ToString());
                }
                break;
            case 3:
                Console.WriteLine("Enter the rating:");
                double dr = double.Parse(Console.ReadLine());
                List<Song> list5 = bo.FindSong(list, dr);
                Console.WriteLine("{0} {1,15} {2,15} {3,15} {4,15} {5,15}", "Name", "Artist", "Song Type", "Rating", "No of Download", "Date of Download");

                foreach (var obj in list5)
                {
                    Console.WriteLine(obj.ToString());
                }
                break;
            default :
                Console.WriteLine("Invalid choice");
                break;
        }
        Console.ReadKey();
    }
}*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        SortedDictionary<string, int> lst1 = new SortedDictionary<string, int>();
        List<Song> list = new List<Song>();
        Console.WriteLine("Enter the number of songs");
        int n1 = Convert.ToInt32(Console.ReadLine());
        //fill code here.
        for (int i = 0; i < n1; i++)
        {
            string[] split = Console.ReadLine().Split(',');
            double rating = Convert.ToDouble(split[4]);
            int _number = Convert.ToInt32(split[5]);
            string date = split[3];
            DateTime date1 = DateTime.ParseExact(date, "dd-MM-yyyy", null);
            Song s = new Song(split[0], split[1], split[2], rating, _number, date1);
            list.Add(s);
        }
        Console.WriteLine("{0} {1,15}", "Song type", "Count");
        //fill code here.
        lst1 =Song.CalculateTypeCount(list);      
        foreach (var obj in lst1)
        {

            Console.WriteLine("{0} {1,15}", obj.Key, obj.Value);
        }
        Console.ReadKey();

    }
}