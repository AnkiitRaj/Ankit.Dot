﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Song[] c = new Song[2];
        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine("Enter song {0} detail:", (i + 1));
            string s = Console.ReadLine();
            string[] s1 = s.Split(',');
            string name = s1[0];
            string artist = s1[1];
            string songtype = s1[2];
            double rating = double.Parse(s1[3]);
            int noofdownload = int.Parse(s1[4]);
            string date = s1[5];
            DateTime d = DateTime.ParseExact(date, "dd-MM-yyyy", null);
            c[i] = new Song(name,artist,songtype,rating,noofdownload,d);
        }
        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine("Song {0}:", (i + 1));
            Console.WriteLine(c[i].ToString());
        }
        if (c[0].Name.Equals(c[1].Name, StringComparison.OrdinalIgnoreCase) && c[0].Artist.Equals(c[1].Artist, StringComparison.OrdinalIgnoreCase)
            && c[0].SongType.Equals(c[1].SongType, StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine("Song 1 is same as Song 2");
        }
        else
        {
            Console.WriteLine("Song 1 and Song 2 are different");
        }
        Console.ReadKey();
    }
}
