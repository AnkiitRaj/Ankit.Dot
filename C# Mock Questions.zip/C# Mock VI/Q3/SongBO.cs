using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class SongBO
{
    public List<Song> FindSong(List<Song> SongList, string type)
    {
        //fill code here.
        List<Song> list3 = new List<Song>();
        foreach (var obj in SongList)
        {
            if (obj.SongType == type)
            {
                list3.Add(obj);
            }
        }
        return list3;
    }
    public List<Song> FindSong(List<Song> SongList, DateTime dateCreated)
    {
            //fill code here.
        List<Song> list4 = new List<Song>();
        foreach (var obj in SongList)
        {
            if (obj.DateDownloaded == dateCreated)
            {
                list4.Add(obj);
            }
        }
        return list4;
    }
    public List<Song> FindSong(List<Song> SongList, double rating)
    {
	    //fill code here.
        List<Song> list6 = new List<Song>();
        foreach (var obj in SongList)
        {
            if (obj.Rating == rating)
            {
                list6.Add(obj);
            }
        }
        return list6;
    }
}