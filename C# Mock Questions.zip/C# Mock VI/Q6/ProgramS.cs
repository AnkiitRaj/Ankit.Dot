using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Song> list=new List<Song>();
	    Console.WriteLine("Enter the number of songs");
	    int n1=Convert.ToInt32(Console.ReadLine());
        //fill code here.
        for (int i = 0; i < n1; i++)
        {
            string song = Console.ReadLine();
            string[] split = song.Split(',');
            double rating = Convert.ToDouble(split[4]);
            int _number = Convert.ToInt32(split[5]);
            DateTime d = DateTime.ParseExact(split[3], "dd-MM-yyyy", null);
            list.Add(new Song(split[0], split[1], split[2],d ,rating, _number));           
        }

        Dictionary<string, int> dt = Song.CalculateTypeCount(list);

        string str = Song.PredictState(dt);
        if (str == "Motivational")
            Console.WriteLine("The user is feeling energetic");
        else if(str == "Emotional")
            Console.WriteLine("The user is feeling depressed");
        else if (str == "Celebration")
            Console.WriteLine("The user is feeling happy");

    }
}