using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Song> list=new List<Song>();
	    Console.WriteLine("Enter the number of songs");
	    int n1=Convert.ToInt32(Console.ReadLine());
        for (int i = 0; i < n1; i++)
        {
            string s = Console.ReadLine();
            string[] arr = s.Split(',');
            string name = arr[0];
            string artist = arr[1];
            string st = arr[2];
            string date = arr[3];
            DateTime d = DateTime.ParseExact(date,"dd-MM-yyyy",null);
            double r = double.Parse(arr[4]);
            int nd = int.Parse(arr[5]);
            list.Add(new Song(name, artist, st, d, r,nd));
        }
        int c=0,e=0,m=0;
        foreach (Song s in list)
        {
            if (s.SongType == "Celebration")
                c++;
            else if (s.SongType == "Emotional")
                e++;
            else if (s.SongType == "Motivational")
                m++;
        }
        if(c>e && c>m)
            Console.WriteLine("The user is feeling happy");
        else if(e>c && e>m)
            Console.WriteLine("The user is feeling depressed");
        else if(m>c && m>e)
            Console.WriteLine("The user is feeling energetic");
        //fill code here.
        Console.ReadKey();
    }
}