using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Group
{
	//fill code here.    

    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private List<Contact> _contactList;

internal List<Contact> ContactList
{
  get { return _contactList; }
  set { _contactList = value; }
}
   
public Group()
{ }

public Group(string _name, List<Contact> _contactList)
{
    this._name = _name;
    this._contactList = _contactList;
}

	public void AddContactToGroup(Contact contact)
	{
	    //fill code here.
        ContactList.Add(contact);


	}
	public Boolean RemoveContactFromGroup(String name)
	{
	    //fill code here.
        foreach(Contact c in ContactList)
        {
            if (c.Name.Contains(name))
            {
                ContactList.Remove(c);
                return true;
            }
        }
        return false;
	}
	public void DisplayContacts() 
	{
	    //fill code here.

        if (ContactList.Count > 0)
        {
            Console.WriteLine();
            foreach (Contact c in ContactList)
            {
                Console.WriteLine();
            }
        }
	}

    
}
