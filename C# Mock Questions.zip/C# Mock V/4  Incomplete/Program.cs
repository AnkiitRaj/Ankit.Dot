using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
    	    Group group = new Group();
    	    Console.WriteLine("Enter the group name:");
            //fill code here.
    	    group.ContactList = (new List<Contact>());
    	    Console.WriteLine("1.Add Contact\n2.Delete Contact\n3.Display contacts\n4.Exit\nEnter your choice:");
    	    int choice=Convert.ToInt32(Console.ReadLine());
    	    //fill code here.
        }
    }
