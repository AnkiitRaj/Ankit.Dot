using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Contact
{
    //fill code here.
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private string _company;

    public string Company
    {
        get { return _company; }
        set { _company = value; }
    }
    private string _title;

    public string Title
    {
        get { return _title; }
        set { _title = value; }
    }
    private string _mobile;

    public string Mobile
    {
        get { return _mobile; }
        set { _mobile = value; }
    }
    private string _alternateMobile;

    public string AlternateMobile
    {
        get { return _alternateMobile; }
        set { _alternateMobile = value; }
    }
    private string _email;

    public string Email
    {
        get { return _email; }
        set { _email = value; }
    }
    private DateTime _dateCreated;

    public DateTime DateCreated
    {
        get { return _dateCreated; }
        set { _dateCreated = value; }
    }
    public Contact()
    { }

    public Contact(string _name, string _company, string _title, string _mobile, string _alternateMobile, string _email, DateTime _dateCreated)
    {
        this._name = _name;
        this._company = _company;
        this._title = _title;
        this._mobile = _mobile;
        this._alternateMobile = _alternateMobile;
        this._email = _email;
        this._dateCreated = _dateCreated;
    }


	public static Contact CreateContact(String detail) {
            //fill code here.
        string[] str = detail.Split(',');
        DateTime dt = DateTime.ParseExact(str[6], "dd-MM-yyyy", null);
        return new Contact(str[0],str[1],str[2],str[3],str[4],str[5],dt);
	}

    public override string ToString()
    {
        return String.Format("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", Name, Company, Title, Mobile, AlternateMobile, Email, DateCreated);
    }
}
