using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Contact[] c = new Contact[2];
        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine("Enter contact {0} detail:",(i+1));
            string s = Console.ReadLine();
            string[] s1 = s.Split(',');
            string name = s1[0];
            string company = s1[1];
            string title = s1[2];
            string mo = s1[3];
            string am = s1[4];
            string e = s1[5];
            string date = s1[6];
            DateTime d = DateTime.ParseExact(date, "dd-MM-yyyy",null);
            c[i] = new Contact(name, company, title, mo, am, e, d);
        }
        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine("Contact {0}:",(i+1));
            Console.WriteLine(c[i].ToString());
        }
        if(c[0].Name.Equals(c[1].Name,StringComparison.OrdinalIgnoreCase) && c[0].Mobile.Equals(c[1].Mobile,StringComparison.OrdinalIgnoreCase) && c[0].Email.Equals(c[1].Email,StringComparison.OrdinalIgnoreCase))
            Console.WriteLine("Contact 1 is same as Contact 2");
        else
            Console.WriteLine("Contact 1 and Contact 2 are different");
            Console.ReadKey();
    }
}
