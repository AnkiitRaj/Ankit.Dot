﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Contact> ls = new List<Contact>();
        Console.WriteLine("Enter the number of contact details:");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            string s = Console.ReadLine();
            string[] s1 = s.Split(',');
            string name = s1[0];
            string company = s1[1];
            string title = s1[2];
            string mo = s1[3];
            string am = s1[4];
            string e = s1[5];
            string date = s1[6];
            DateTime d = DateTime.ParseExact(date, "dd-MM-yyyy", null);
            ls.Add(new Contact(name, company, title, mo, am, e, d));
        }
        Console.WriteLine("Enter a search type:\n1.Name\n2.Date created\n3.Email domain");
        int ch = int.Parse(Console.ReadLine());
        if (ch == 1)
        {
            List<string> name = new List<string>();
            Console.WriteLine("Enter the names:");
            string[] s = Console.ReadLine().Split(',');
            for (int i = 0; i < s.Length; i++)
            {
                name.Add(s[i]);
            }
            List<Contact> Fc = new List<Contact>();
            ContactBO b = new ContactBO();
            Fc = b.FindContact(ls, name);
            Console.WriteLine("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", "Name", "Company", "Title", "Mobile", "Alternate Mobile", "Email", "Date Created");
            foreach (Contact c in Fc)
            {
                Console.WriteLine(c.ToString());
            }
        }
        else if (ch == 2)
        {
            Console.WriteLine("Enter the date to search contacts that were created on that date");
            DateTime d = DateTime.ParseExact(Console.ReadLine(), "dd-MM-yyyy", null);
            ContactBO b = new ContactBO();
            List<Contact> fcd = new List<Contact>();
            fcd = b.FindContact(ls, d);
            Console.WriteLine("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", "Name", "Company", "Title", "Mobile", "Alternate Mobile", "Email", "Date Created");
            foreach (Contact c in fcd)
            {
                Console.WriteLine(c.ToString());
            }
        }
        else if (ch == 3)
        {
            Console.WriteLine("Enter the Email domain to search contacts that have same email domain");
            string domain = Console.ReadLine();
            List<Contact> fcdo = new List<Contact>();
            ContactBO b = new ContactBO();
            fcdo = b.FindContact(ls, domain);
            Console.WriteLine("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", "Name", "Company", "Title", "Mobile", "Alternate Mobile", "Email", "Date Created");
            foreach (Contact c in fcdo)
            {
                Console.WriteLine(c.ToString());
            }
        }
        else
            Console.WriteLine("Invalid choice");
        Console.ReadKey();
    }
}
