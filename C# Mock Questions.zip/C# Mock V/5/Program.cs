﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Contact> ls = new List<Contact>();
        Console.WriteLine("Enter the number of the contacts:");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            string s = Console.ReadLine();
            ls.Add(Contact.CreateContact(s));
            //ls.Add(new Contact(name, company, title, mo, am, e, d));
        }
        Console.WriteLine("Enter a type to sort:\n1.Sort by name\n2.Sort by email domain\n3.Sort by date created");
        int ch = int.Parse(Console.ReadLine());
        if (ch == 1)
        {
            NameComparer nc = new NameComparer();
            ls.Sort(nc);
            Console.WriteLine("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", "Name", "Company", "Title", "Mobile", "Alternate Mobile", "Email", "Date Created");
            foreach (Contact c in ls)
            {
                Console.WriteLine(c.ToString());
            }
        }
        else if (ch == 2)
        {
            DomainComparer dc = new DomainComparer();
            Console.WriteLine("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", "Name", "Company", "Title", "Mobile", "Alternate Mobile", "Email", "Date Created");
            ls.Sort(dc);
            foreach (Contact c in ls)
            {
                Console.WriteLine(c.ToString());
            }
        }
        else if (ch == 3)
        {
            DateComparer dcc = new DateComparer();
            Console.WriteLine("{0} {1,20} {2,20} {3,20} {4,20} {5,20} {6,20}", "Name", "Company", "Title", "Mobile", "Alternate Mobile", "Email", "Date Created");
            ls.Sort(dcc);
            foreach (Contact c in ls)
            {
                Console.WriteLine(c.ToString());
            }
        }
        else
            Console.WriteLine("Invalid choice");
        Console.ReadKey();
    }
}
