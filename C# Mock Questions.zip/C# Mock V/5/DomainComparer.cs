﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class DomainComparer:IComparer<Contact>
    {
        public int Compare(Contact x, Contact y)
        {
            return x.Company.CompareTo(y.Company);
        }
    }
