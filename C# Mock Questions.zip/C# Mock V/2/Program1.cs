﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

 class Program
{
        static void Main(string[] args)
        {
            Console.WriteLine("1.Email Validation\n2.Service Provider Identification\nEnter your choice:");
            int ch = int.Parse(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    Console.WriteLine("Enter the email to be validated:");
                    string email = Console.ReadLine();
                    bool res1 = ValidateEmailId(email);
                    if (res1 == true)
                        Console.WriteLine("Email is valid");
                    else
                        Console.WriteLine("Email is invalid");
                    break;

                case 2:
                    Console.WriteLine("Enter the mobile number to identify the service provider:");
                    string mobile = Console.ReadLine();
                    string res2 = IdentifyServiceProvider(mobile);
                    Console.WriteLine(res2);
                    break;

            }
            Console.ReadKey();
        }
        public static bool ValidateEmailId(string email)
        {
            //fill code here.
            if (Regex.IsMatch(email, @"^[a-zA-Z][-a-zA-Z0-9._]+@([-a-zA-Z0-9]+\.)+[a-zA-Z]{2,6}$"))
                return true;
            return false;

        }
        public static string IdentifyServiceProvider(string mobile)
        {
            //fill code here.

            string str = mobile.Substring(0, 4);
            if (str == "9870")
                return "Mobile number belongs to Airtel";
            else if (str == "7012")
                return "Mobile number belongs to Jio";
            else if (str == "8180")
                return "Mobile number belongs to Vodafone";
            return "Mobile number is not identified";
        }
      
}

