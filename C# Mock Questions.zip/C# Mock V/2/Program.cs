using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
	static void Main(string[] args)
	{
		Console.WriteLine("1.Email Validation\n2.Service Provider Identification\nEnter your choice:");
      
        int choice = int.Parse(Console.ReadLine());
        switch (choice)
        {
            case 1:
                Console.WriteLine("Enter the email to be validated:");
                string email = Console.ReadLine();
                bool val = ValidateEmailId(email);
                if (val == true)
                {
                    Console.WriteLine("Email is valid");
                }
                else
                {
                    Console.WriteLine("Email is invalid");
                }
                break;
            case 2:
                Console.WriteLine("Enter the mobile number to identify the service provider:");
                string mobile = Console.ReadLine();
                string val1 = IdentifyServiceProvider(mobile);
                Console.WriteLine(val1);
                break;
        }
	}
	public static bool ValidateEmailId(string email)
    {
        int count = 0;
       email.ToCharArray();
       if (char.IsLetter(email[0]))
       {
           email.ToString();
           if (email.Contains('@'))
           {
               string[] s = email.Split('@');

               for (int i = 0; i < s[0].Length; i++)
               {
                   char[] c = s[0].ToCharArray();
                   if (char.IsLetter(c[i]) || c[i] == '_' || c[i] == '.' ||char.IsNumber(c[i]))
                   {
                       count++;
                   }
                   
               }
             
               if (count == s[0].Length)
               {
                   
                   int count1 = 0;
                   string ss = s[1];
                   if (ss.Contains('.'))
                   {
                       
                       string[] s1 = ss.Split('.');

                       for (int i = 0; i < s1[0].Length; i++)
                       {
                           char[] c1 = s1[0].ToCharArray();
                           if (char.IsLetter(c1[0]))
                           {
                               count1++;
                           }
                       }
                   
                       if (count1 == s1[0].Length)
                       {
                           int count2 = 0;
                            string f = s1[1].ToString();
                            for (int i = 0; i < f.Length; i++)
                            {
                                if (char.IsLetter(f[i]))
                                {
                                    count2++;
                                }
                            }
                            if (count2 == f.Length)
                            {
                                return true;
                            }

                       }
                       else
                       {
                           return false;
                       }
                   }
                   else
                   {
                       return false;

                   }
               }
               else
               {
                   return false;

               }
           }
           else
           {
               return false;

           }
       }
       else
       {
           return false;

       }
       return false;
	}
    public static string IdentifyServiceProvider(string mobile)
    {
        if (mobile[0] == '9' && mobile[1] == '8' && mobile[2] == '7' && mobile[3] == '0')
        {
            return "Mobile number belongs to Airtel";
        }
        else if (mobile[0] == '7' && mobile[1] == '0' && mobile[2] == '1' && mobile[3] == '2')
        {
            return "Mobile number belongs to Jio";
        }
        else if (mobile[0] == '8' && mobile[1] == '1' && mobile[2] == '8' && mobile[3] == '0')
        {
            return "Mobile number belongs to Vodafone";
        }
        else 
        {
           return "Mobile number is not identified";
        }
    }
}
