using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Booking
{
    long _bookingId;
    public long BookingId
    {
        get { return _bookingId; }
        set { _bookingId = value; }
    }
    string _dateTimeOfService;

    public string DateTimeOfService
    {
        get { return _dateTimeOfService; }
        set { _dateTimeOfService = value; }
    }
    string _paymentMode;
    public string PaymentMode
    {
        get { return _paymentMode; }
        set { _paymentMode = value; }
    }
    Customer _customerIns;
    public Customer CustomerIns
    {
        get { return _customerIns; }
        set { _customerIns = value; }
    }
    Car _carIns;
    public Car CarIns
    {
        get { return _carIns; }
        set { _carIns = value; }
    }
    double _amount;
    public double Amount
    {
        get { return _amount; }
        set { _amount = value; }
    }
    string _serviceEngineer;
    public string ServiceEngineer
    {
        get { return _serviceEngineer; }
        set { _serviceEngineer = value; }
    }
    public Booking()
    { }
    public Booking(long _bookingId, string _dateTimeOfService, string _paymentMode, Customer _customerIns, Car _carIns, double _amount, string _serviceEngineer)
    {
        BookingId = _bookingId;
        DateTimeOfService = _dateTimeOfService;
        PaymentMode = _paymentMode;
        CustomerIns = _customerIns;
        CarIns = _carIns;
        Amount = _amount;
        ServiceEngineer = _serviceEngineer;
    }
}
