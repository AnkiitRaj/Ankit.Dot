using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class WalletPayment : PaymentMode
{
    string _walletNumber;

    public string WalletNumber
    {
        get { return _walletNumber; }
        set { _walletNumber = value; }
    }
    public WalletPayment() { }
    public WalletPayment(string _walletNumber, string _type)
        : base(_type)
    {
        WalletNumber = _walletNumber;
    }
    public override double MakePayment(Booking booking)
    {
        double d = booking.Amount;
        double d1 = d * 0.05;
        double d2 = d - d1;
        return d2;
    }

}
