using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Program
{
    static void Main(string[] args)
    {
        long bookingId;
        string dateTimeOfService;
        string paymentMode;
        string creditcardNumber;
        string holderName;
        string walletNumber;
        string cardNumber;
        string serviceEngineer;
        string dateOfExpiry;
        double amount;
        Customer customer = new Customer();
        Car car = new Car();

        Console.WriteLine("bookingId");
        bookingId = Convert.ToInt64(Console.ReadLine());

        Console.WriteLine("dateTimeOfService");


        dateTimeOfService = Console.ReadLine();
        Console.WriteLine("paymentMode");
        paymentMode = Console.ReadLine();

        Console.WriteLine("customer id");
        customer.CustomerId = Convert.ToInt64(Console.ReadLine());

        Console.WriteLine("licence number");
        car.LicenceNumber = Console.ReadLine();

        Console.WriteLine("amount");
        amount = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("service engineer");
        serviceEngineer = Console.ReadLine();

        Booking booking = new Booking(bookingId, dateTimeOfService, paymentMode, customer, car, amount, serviceEngineer);



        switch (booking.PaymentMode)
        {
            case "creditcardpayment":
                Console.WriteLine("creditcard number");
                creditcardNumber = Console.ReadLine();
                Console.WriteLine("holder name");
                holderName = Console.ReadLine();
                Console.WriteLine("card number");
                cardNumber = Console.ReadLine();
                Console.WriteLine("date of expiry");
                dateOfExpiry = Console.ReadLine();
                CreditCardPayment c = new CreditCardPayment(creditcardNumber, holderName, cardNumber, dateOfExpiry, paymentMode);
                double d = Math.Round(c.MakePayment(booking));
                Console.WriteLine("Cost is Rs " + d);

                break;
            case "walletpayment":
                Console.WriteLine("wallet number");
                walletNumber = Console.ReadLine();
                WalletPayment w = new WalletPayment(walletNumber, paymentMode);
                double d1 = Math.Round(w.MakePayment(booking));
                Console.WriteLine("Cost is Rs " + d1);
                break;
        }

    }
}
