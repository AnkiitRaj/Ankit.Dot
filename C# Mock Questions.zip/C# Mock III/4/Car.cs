using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Car
{
    string _licenceNumber;

    public string LicenceNumber
    {
        get { return _licenceNumber; }
        set { _licenceNumber = value; }
    }
    public Car() { }
    public Car(string l)
    {
        LicenceNumber = l;
    }

}
