using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Customer
{
    long _customerId;

    public long CustomerId
    {
        get { return _customerId; }
        set { _customerId = value; }
    }


    public Customer() { }
    public Customer(int c)
    {
        CustomerId = c;
    }

}
