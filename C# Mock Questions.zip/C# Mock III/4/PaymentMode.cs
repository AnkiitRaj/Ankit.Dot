using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public abstract class PaymentMode
{
    string _type;

    public string Type
    {
        get { return _type; }
        set { _type = value; }
    }
    public PaymentMode()
    { }
    public PaymentMode(string s)
    {
        Type = _type;
    }
    public abstract double MakePayment(Booking booking);

}

