using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class CreditCardPayment : PaymentMode
{
    string _creditcardNumber;

    public string CreditcardNumber
    {
        get { return _creditcardNumber; }
        set { _creditcardNumber = value; }
    }
    string _holderName;

    public string HolderName
    {
        get { return _holderName; }
        set { _holderName = value; }
    }
    string _cardNumber;

    public string CardNumber
    {
        get { return _cardNumber; }
        set { _cardNumber = value; }
    }
    string _dateOfExpiry;

    public string DateOfExpiry
    {
        get { return _dateOfExpiry; }
        set { _dateOfExpiry = value; }
    }


    public CreditCardPayment() { }
    public CreditCardPayment(string _creditcardNumber, string _holderName, string _cardNumber, string _dateOfExpiry, string _type)
        : base(_type)
    {
        CreditcardNumber = _creditcardNumber;
        HolderName = _holderName;
        CardNumber = _cardNumber;
        DateOfExpiry = _dateOfExpiry;
    }
    public override double MakePayment(Booking booking)
    {
        double d = booking.Amount;
        double d1 = d * 0.02;
        double d2 = d + d1;
        return d2;
    }


}
