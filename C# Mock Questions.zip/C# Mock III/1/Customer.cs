using System;    
public class Customer
{

    private long _customerId;

    public long CustomerId
    {
        get { return _customerId; }
        set { _customerId = value; }
    }
    private string _firstName;

    public string FirstName
    {
        get { return _firstName; }
        set { _firstName = value; }
    }
    private string _lastName;

    public string LastName
    {
        get { return _lastName; }
        set { _lastName = value; }
    }
    private string _gender;

    public string Gender
    {
        get { return _gender; }
        set { _gender = value; }
    }
    private string _email;

    public string Email
    {
        get { return _email; }
        set { _email = value; }
    }
    private string _phoneNumber;

    public string PhoneNumber
    {
        get { return _phoneNumber; }
        set { _phoneNumber = value; }
    }
    private string _address;

    public string Address
    {
        get { return _address; }
        set { _address = value; }
    }

    public Customer()
    { }
    public Customer(long _customerId, string _firstName, string _lastName, string _gender, string _email, string _phoneNumber, string _address)
    {
        this.CustomerId = _customerId;
        this.FirstName = _firstName;
        this.LastName = _lastName;
        this.Gender = _gender;
        this.Email = _email;
        this.PhoneNumber = _phoneNumber;
        this.Address = _address;
    }
    public override string ToString()
    {
        return String.Format("Customer:{0},{1}\nContact details:{2},{3},{4}", this.FirstName, this.LastName, this.PhoneNumber, this.Email, this.Address);
    }
}
