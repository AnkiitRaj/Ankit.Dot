using System;
public class Program
{
    public static void Main(string[] args)
    {
        long _customerId;
        string _firstName, _lastName, _gender, _email, _phoneNumber, _address;
        Customer[] customer = new Customer[2];
        int i;
        for (i = 0; i < 2; i++)
        {
            Console.WriteLine("Customer" + (i + 1) + " :");
            Console.WriteLine("customer id: ");
            _customerId = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("first name: ");
            _firstName = Console.ReadLine();
            Console.WriteLine("last name: ");
            _lastName = Console.ReadLine();
            Console.WriteLine("gender: ");
            _gender = Console.ReadLine();
            Console.WriteLine("email: ");
            _email = Console.ReadLine();
            Console.WriteLine("phone number: ");
           _phoneNumber = Console.ReadLine();
            Console.WriteLine("address: ");
            _address = Console.ReadLine();
            customer[i] = new Customer(_customerId, _firstName, _lastName, _gender, _email, _phoneNumber, _address);
            //fill your code
        }
        for (i = 0; i < 2; i++)
        {
            Console.WriteLine("Customer {0}", (i + 1));
            Console.WriteLine(customer[i].ToString());
        }
        if (customer[0].FirstName.Equals(customer[1].FirstName) && customer[0].LastName.Equals(customer[1].LastName) &&
          customer[0].Email.Equals(customer[1].Email) && customer[0].PhoneNumber.Equals(customer[1].PhoneNumber))
            Console.WriteLine("Customer 1 is same as Customer 2");
        else
            Console.WriteLine("Customer 1 and Customer 2 are different");
        Console.ReadKey();

    }
}