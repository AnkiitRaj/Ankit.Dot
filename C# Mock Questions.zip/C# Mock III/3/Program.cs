using System.Text.RegularExpressions;
using System;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter license number:");
        string licenseNumber = Console.ReadLine();
        Console.WriteLine("Menu:\n" +
            "1) Validate licence Number\n" +
            "2) Check Driver Experience");
        Console.WriteLine("Enter choice: ");
        int choice = Convert.ToInt32(Console.ReadLine());
        switch (choice)
        {
            case 1:
                if (ValidateLicenseNumber(licenseNumber))
                {
                    Console.WriteLine("License number is valid");
                }
                else
                {
                    Console.WriteLine("License number is not valid");
                }
                break;
            case 2:
                if (IsExperiencedDriver(licenseNumber))
                {
                    Console.WriteLine("Experienced Driver");
                }
                else
                {
                    Console.WriteLine("Not Experienced Driver");
                }
                break;
            default:
                Console.WriteLine("Invalid option");
                break;
        }
    }
    
    public static bool ValidateLicenseNumber(string licenceNumber)
    {
        DateTime currentDate = DateTime.ParseExact("28-11-2017", "dd-MM-yyyy", null);
        int currentYear = currentDate.Year;
        int flag = 0;
        char[] ch = licenceNumber.ToCharArray();
        string s1 = "", s2 = "", s3 = "";
        int cnt = 0;
        if (ch.Length == 15)
        {
            s1 = s1 + ch[2] + ch[3];
            s2 = s2 + ch[4] + ch[5] + ch[6] + ch[7];
            s3 = s3 + ch[8] + ch[9] + ch[10] + ch[11] + ch[12] + ch[13] + ch[14];
            if (char.IsUpper(ch[0]) && char.IsUpper(ch[1]))
                cnt++;
            else
                flag = 1;

            if ((int.Parse(s1) >= 10) && (int.Parse(s1) <= 50))
                cnt++;
            else
                flag = 1;

            if ((int.Parse(s2) >= 2005) && (int.Parse(s2) <= 2016))
                cnt++;
            else
                flag = 1;

            if (!s3.Contains("0"))
                cnt++;
            else
                flag = 1;
        }
        else
            flag = 1;
        if (flag == 0 && cnt == 4)
            return true;
        else
            return false;
    }
    
    public static bool IsExperiencedDriver(string licenceNumber)
    {
        DateTime currentDate = DateTime.ParseExact("28-11-2017", "dd-MM-yyyy", null);
        int currentYear = currentDate.Year;
        int flag = 0;
        char[] ch = licenceNumber.ToCharArray();
        string s1 = "";
        int cnt = 0;
        if (ch.Length == 15)
        {
            s1 = s1 + ch[4] + ch[5] + ch[6] + ch[7];
            int d = int.Parse(s1);
            if (currentYear - d >= 5)
                cnt++;
            else
                flag = 1;
        }
        else
            flag = 1;
        if (flag == 0 && cnt == 1)
            return true;
        else
            return false;
    }
}