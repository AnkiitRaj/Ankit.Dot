﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> detail = new List<Customer>();
            bool b = true;
            while(b) 
            {
                Console.WriteLine("Enter customer details: ");
                string s = Console.ReadLine();
                Customer c = new Customer();
                Customer a = c.validateEmail(s);
                if (a != null)
                {
                    detail.Add(a);
                }
                Console.WriteLine("Do you want to continue?");
                string ch = Console.ReadLine();
                if (ch == "Yes" || ch == "yes")
                {
                    b = true;
                }
                else
                {
                    b = false;
                }
            }

            Console.WriteLine("{0}{1,25}{2,25}{3,25}{4,25}{5,25}", "Id", "First Name", "Last Name", "Gender", "Email", "Phone Number");
            detail.Sort();
            foreach (var n in detail)
            {
                Console.WriteLine(n.ToString());
            }
            Console.ReadKey();
        }
    }

