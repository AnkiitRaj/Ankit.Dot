﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Customer : IComparable
    {
        private long customerId;
        private string firstName;
        private string lastName;
        private string gender;
        private string email;
        private string phoneNumber;
        private string address;
        public Customer()
        { }
        public Customer(long customerId, string firstName, string lastName,string gender, string email, string phoneNumber, string address)
        {
            this.customerId = customerId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.email = email;
            this.phoneNumber = phoneNumber;
            this.address = address;
        }
        public long CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public override string ToString()
        {
            return string.Format("{0}{1,25}{2,25}{3,25}{4,25}{5,25}", CustomerId, FirstName, LastName, Gender, Email, PhoneNumber);
        }
        public Customer validateEmail(string s)
        {
            Customer c = new Customer();
            try
            {
                string[] sp = s.Split(',');
                if (sp[4].Contains('@') && (sp[4].EndsWith(".org") ||sp[4].EndsWith(".com")))
                {
                    c.CustomerId = Convert.ToInt64(sp[0]);
                    c.FirstName = sp[1];
                    c.LastName = sp[2];
                    c.Gender = sp[3];
                    c.Email = sp[4];
                    c.PhoneNumber = sp[5];
                    c.Address = sp[6];
                    return c;
                }
                else
                {
                    throw new InvalidEmailException();
                }
            }
            catch (InvalidEmailException)
            {
                Console.WriteLine();
                return null;
            }

        }
        int IComparable.CompareTo(object obj)
        {
            Customer cus = (Customer)obj;
            return this.FirstName.CompareTo(cus.FirstName);
        }
    }



