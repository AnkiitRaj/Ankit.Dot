using System;
using System.Collections;
using System.Collections.Generic;

public class Program
{


    public static void Main(string[] args)
    {

        List<Car> carList = new List<Car>();
        while (true)
        {
            string menu = "Menu:\n1) Add a Car\n" + "2) Find a Car\n" + "3) Find CarList\n" + "4) Exit";
            Console.WriteLine(menu);
            int option = Convert.ToInt32(Console.ReadLine());
            if (option == 1)
            {
                carList.Add(Car.addCar());
            }
                //fill code here.
                if (option == 2)
                {
                    Console.WriteLine("Licence Number");
                    string licNo = Console.ReadLine();
                    if (Car.findCar(licNo, carList) != null)
                        Console.WriteLine(Car.findCar(licNo, carList));
                    else
                        Console.WriteLine("Licence Number not present");
                }
                if (option == 3)
                {
                    List<Car> carList1 = new List<Car>();
                    Console.WriteLine("Model");
                    string model = Console.ReadLine();
                    carList1 = Car.findCarList(model, carList);
                    if (carList1 != null)
                    {
                        foreach (Car c in carList1)
                        {
                            Console.WriteLine(c);
                        }
                    }
                    else
                        Console.WriteLine("Car " + model + " not found");
                }
                if (option == 4)
                {
                    break;
                }

            }
        }
    }