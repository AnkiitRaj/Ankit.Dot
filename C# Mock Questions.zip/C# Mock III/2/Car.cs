using System;
using System.Collections;
using System.Collections.Generic;

public class Car
    {
        private String licenceNumber,model;
    private Double currentMileage;
    private int engineSize;
    public String getLicenceNumber() {
return licenceNumber;
}

public void setLicenceNumber(String licenceNumber) {
this.licenceNumber = licenceNumber;
}

public String getModel() {
return model;
}

public void setModel(String model) {
this.model = model;
}

public Double getCurrentMileage() {
return currentMileage;
}

public void setCurrentMileage(Double currentMileage) {
this.currentMileage = currentMileage;
}

public int getEngineSize() {
return engineSize;
}

public void setEngineSize(int engineSize) {
this.engineSize = engineSize;
}

public Car(String licenceNumber, String model, Double currentMileage,
int engineSize) {

this.licenceNumber = licenceNumber;
this.model = model;
this.currentMileage = currentMileage;
this.engineSize = engineSize;
}

public Car() {

}

    public static Car addCar() {
       
       String licenceNumber, model;
        Double currentMileage;
        int engineSize;
       Car c = null;
       try {
           Console.WriteLine("Licence Number:");
           licenceNumber = Console.ReadLine();
            Console.WriteLine("Model:");
           model = Console.ReadLine();
          Console.WriteLine("Current Mileage:");
           currentMileage = double.Parse(Console.ReadLine());
          Console.WriteLine("Engine Size:");
           engineSize = int.Parse(Console.ReadLine());
           c = new Car(licenceNumber,model,currentMileage,engineSize);
           return c;
           
       }
       catch(Exception e) {
           Console.WriteLine("Could not create Car");
       }
       return c;
       
   }
    
    public static Car findCar(String licNo, List<Car> carList) {
       //fill the code
     
     foreach(Car c in carList)
     {
     if(c.getLicenceNumber().Equals(licNo))
     {
     return c;
     }
     }
     
     return null;
     }
    
    public override string ToString()
{
 	 return "Licence Number:" + licenceNumber + "\nModel:" + model;
}

    

public static List<Car> findCarList(String model, List<Car> carList) {
      List<Car> cL=new List<Car>();
      int f=0;
      foreach(Car c in carList)
      {
      if(c.getModel().Equals(model))
      {
      cL.Add(c);
      f=1;
      }
      }
      if(f==1)
      return cL;
      else
      return null;
      
       //fill the code
     }
}
   