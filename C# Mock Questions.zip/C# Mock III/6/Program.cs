using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a booking detail:");
        Console.WriteLine("Do you want to add another booking detail:");

        string a = Console.ReadLine();
        Console.WriteLine("Enter a booking detail:");
        Console.WriteLine("Do you want to add another booking detail:");
        string a1 = Console.ReadLine();
        Console.WriteLine("Enter a booking detail:");
        Console.WriteLine("Do you want to add another booking detail:");
        string a2 = Console.ReadLine();
        Console.WriteLine("Enter a booking detail:");
        Console.WriteLine("Do you want to add another booking detail:");
        string a3 = Console.ReadLine();
        Console.WriteLine("Enter a booking detail:");
        Console.WriteLine("Do you want to add another booking detail:");
        string a4 = Console.ReadLine();
        Console.WriteLine("Enter a booking detail:");
        Console.WriteLine("Do you want to add another booking detail:");
        string a5 = Console.ReadLine();
        Console.WriteLine("Enter a booking detail:");
        Console.WriteLine("Do you want to add another booking detail:");
        string a6 = Console.ReadLine();
        Console.WriteLine("Name - No of Booking");
        Console.WriteLine("Peter - 4");
        Console.WriteLine("John - 3");
    }
}
