using System;
using System.Collections.Generic;
using System.Collections;

public class Booking
{

    private long _bookingId;

public long BookingId
{
  get { return _bookingId; }
  set { _bookingId = value; }
}
    private DateTime _dateTimeOfService;

public DateTime DateTimeOfService
{
  get { return _dateTimeOfService; }
  set { _dateTimeOfService = value; }
}
    private string _paymentMode;

public string PaymentMode
{
  get { return _paymentMode; }
  set { _paymentMode = value; }
}
    private long _customerId;

public long CustomerId
{
  get { return _customerId; }
  set { _customerId = value; }
}
    private long _carId;

public long CarId
{
  get { return _carId; }
  set { _carId = value; }
}
    private double _amount;

public double Amount
{
  get { return _amount; }
  set { _amount = value; }
}
    private string _serviceEngineer;

public string ServiceEngineer
{
  get { return _serviceEngineer; }
  set { _serviceEngineer = value; }
}
    
    public Booking()
    {

    }

    public Booking(long _bookingId, DateTime _dateTimeOfService, string _paymentMode, long _customerId, long _carId, double _amount, string _serviceEngineer)
    {
        this.BookingId = _bookingId;
        this.DateTimeOfService = _dateTimeOfService;
        this.PaymentMode = _paymentMode;
        this.CustomerId = _customerId;
        this.CarId = _carId;
        this.Amount = _amount;
        this.ServiceEngineer = _serviceEngineer;
    }
    public static SortedDictionary<string,List<Booking>> OrganizeBookings(List<Booking> bookingList)
    {
        //fill code here.
    }

    public static List<string> FindBestServiceEngineer(SortedDictionary<string,List<Booking>>)
    {
        //fill code here.
    }

}
