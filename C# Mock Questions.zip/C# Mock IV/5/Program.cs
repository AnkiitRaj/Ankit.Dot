using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of purchase:");
            int n = int.Parse(Console.ReadLine());
            List<Purchase> pl = new List<Purchase>();
            Console.WriteLine("Enter the purchase details:");
            for (int i = 0; i < n; i++)
            {
                string s = Console.ReadLine();
                string[] a = s.Split(',');
                    Purchase p = new Purchase();
                    p = Purchase.ObtainPurchaseWithAmount(s);
                    if (p != null)
                    {
                        pl.Add(p);
                        Console.WriteLine("Purchase {0} is added to the list",p.Id);
                    }
                    else
                        Console.WriteLine("InvalidWholeSaleException: Purchase {0} is not a whole sale",a[0]);
                
            }

            
            pl.Sort();
            Console.WriteLine("Whole sale purchases:");
            Console.WriteLine("{0} {1,10} {2,15}", "ID", "User", "Amount");
            foreach (Purchase x in pl)
            {
                Console.WriteLine("{0} {1,10} {2,15}", x.Id, x.User, x.TotalAmount); 
            }
                System.Console.ReadKey();
        }
    
}
