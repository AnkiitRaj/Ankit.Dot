using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            Item[] items = new Item[2];
    	    for(int i=0;i<2;i++) {
			    Console.WriteLine("Enter item "+(i+1)+" detail:");
			    string details = Console.ReadLine();
			    string [] itemVal = details.Split(',');
			    items[i] = new Item(Convert.ToInt64(itemVal[0]),itemVal[1],itemVal[2],Convert.ToDouble(itemVal[3]));
		    }
		    //fill code here.
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("\nItem " + (i + 1) + ":\n{0} {1,10} {2,15} {3,15}", "ID", "Name", "Item Code", "Cost");
                Console.WriteLine(items[i].ToString());
            }//fill code here.
            if (items[0].Name.Equals(items[1].Name, StringComparison.InvariantCultureIgnoreCase) && items[0].ItemCode.Equals(items[1].ItemCode, StringComparison.InvariantCultureIgnoreCase))
                Console.WriteLine("Item 1 is same as Item 2");
            else
                Console.WriteLine("Item 1 and Item 2 are different");
            Console.ReadKey();
        }
    
}
