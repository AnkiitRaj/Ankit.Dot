using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Item
{
    private long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private string _itemCode;

    public string ItemCode
    {
        get { return _itemCode; }
        set { _itemCode = value; }
    }
    private double _cost;

    public double Cost
    {
        get { return _cost; }
        set { _cost = value; }
    }
    public Item()
    { }
    public Item(long id, string name, string itemcode, double cost)
    {
        this.Id = id;
        this.Name = name;
        this.ItemCode = itemcode;
        this.Cost = cost;
    }
    public override string ToString()
    {
        return string.Format("{0} {1,10} {2,15} {3,15:0.0}", Id, Name, ItemCode, Cost);
    }


}
