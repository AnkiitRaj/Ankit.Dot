using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of purchase:");
            int n = int.Parse(Console.ReadLine());
            SortedDictionary<String, int> d = new SortedDictionary<string, int>();
            for (int i = 0; i < n; i++)
            {
                string inp = Console.ReadLine();
                Purchase.ObtainPurchaseWithItem(d, inp);
            }
            Console.WriteLine("{0} {1,15}", "Item name", "Quantity");
            foreach (var item in d)
            {
                Console.WriteLine("{0} {1,15}", item.Key, item.Value);
            }
        }
    }