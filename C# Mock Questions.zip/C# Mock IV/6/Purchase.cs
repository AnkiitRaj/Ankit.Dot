﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
    class Purchase
    {
        private long _id;

        public long Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private DateTime _purchaseDate;

        public DateTime PurchaseDate
        {
            get { return _purchaseDate; }
            set { _purchaseDate = value; }
        }
        private double _totalAmount;

        public double TotalAmount
        {
            get { return _totalAmount; }
            set { _totalAmount = value; }
        }
        private string _user;

        public string User
        {
            get { return _user; }
            set { _user = value; }
        }
        public Purchase()
        { }
        public Purchase(long id, DateTime purchasedate, double totalamount,string user)
        {
            this.Id = id;
            this.PurchaseDate = purchasedate;
            this.TotalAmount = totalamount;
            this.User = user;
        }

        public static void ObtainPurchaseWithItem(SortedDictionary<string, int> dictionary, string purchaseDetail)
        {
             string[] a = purchaseDetail.Split(',');
             for (int j = 3; j < a.Length; j = j + 3)
             {
                 if (dictionary.ContainsKey(a[j]))
                 {
                     dictionary[a[j]] = dictionary[a[j]] + Convert.ToInt32(a[j + 2]);
                 }
                 else
                 {
                     dictionary.Add(a[j], Convert.ToInt32(a[j + 2]));
                 }
             }
        }
    }