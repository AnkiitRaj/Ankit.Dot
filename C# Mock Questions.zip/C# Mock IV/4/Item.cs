using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Item
{
    private long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private double _cost;

    public double Cost
    {
        get { return _cost; }
        set { _cost = value; }
    }
    private int _quantity;
    private long p1;
    private string p2;
    private double p3;
    private int p4;

    public int Quantity
    {
        get { return _quantity; }
        set { _quantity = value; }
    }
    public Item()
    {
    }

    public Item(long p1, string p2, double p3, int p4)
    {
        // TODO: Complete member initialization
        this.Id = p1;
        this.Name = p2;
        this.Cost = p3;
        this.Quantity = p4;
    }
        public static double CalculateTotalBill(List<Item> itemList) 
	{
        //fill code here
        double total = 0;
        foreach (var obj in itemList)
        {
            double tot = obj.Cost * obj.Quantity;
            total = total + tot;
        }
        return total;
	}

        //public static double CalculateTotalBill(List<Item> itemList, int deliveryType)
        //{
        //    //fill code here.
        //}
}
