using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            List<Item> itemList = new List<Item>();
            Console.WriteLine("Enter the number of items:");
            int noOfItems = Convert.ToInt32(Console.ReadLine());
            for(int i = 0 ; i < noOfItems ; i++) {
                String itemDetails = Console.ReadLine();
                String []splited = itemDetails.Split(',');
                itemList.Add(new Item(Convert.ToInt64(splited[0]), splited[1], Convert.ToDouble(splited[2]), Convert.ToInt32(splited[3])));
            }
            Console.WriteLine("1.Store\n2.Online\nEnter the choice:");
            int choice = int.Parse(Console.ReadLine());
            if (choice == 1)
            {
                Console.WriteLine("Total amount:{0:0.00}",Item.CalculateTotalBill(itemList));
            }
            else if (choice == 2)
            {
                Console.WriteLine("1.One day delivery\n2.Normal delivery");
                Console.WriteLine("Enter delivery type:");
                int delivery = int.Parse(Console.ReadLine());
                if (delivery == 1)
                {
                    double total = Item.CalculateTotalBill(itemList);
                    double sum = ((15 * total) / 100);
                    double tot = total + sum;
                    Console.WriteLine("Total amount:{0:0.00}",tot);
                }
                else if (delivery == 2)
                {
                    double total = Item.CalculateTotalBill(itemList);
                    double sum = ((8 * total) / 100);
                    double tot = total + sum;
                    Console.WriteLine("Total amount:{0:0.00}", tot);
                }
            }
            Console.ReadKey();
        }
    }
