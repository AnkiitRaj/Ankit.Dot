using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            List<Item> il = new List<Item>();
            while (true)
            {
            Console.WriteLine("1. Add items\n2. Search item by name\n3. Get item between price range\n4. Exit\nEnter your choice:");
            int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter the number of items:");
                        int n = int.Parse(Console.ReadLine());

                        for (int i = 0; i < n; i++)
                        {
                            string s = Console.ReadLine();
                            il.Add(Item.CreateItem(s));
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter the name:");
                        string name = Console.ReadLine();
                        Item sitem = new Item();
                        sitem = Item.SearchItemByName(name, il);
                        if (sitem != null)
                        {
                            Console.WriteLine("Item Detail");
                            Console.WriteLine("Item name: {0}", sitem.Name);
                            Console.WriteLine("Item code: {0}", sitem.ItemCode);
                            Console.WriteLine("Item Cost: {0:0.0}", sitem.Cost);
                        }
                        else 
                        {
                            Console.WriteLine("Item {0} not found",name);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter the max and min cost:");
                        int min = int.Parse(Console.ReadLine());
                        int max = int.Parse(Console.ReadLine());
                        List<Item> al = new List<Item>();
                        al = Item.FindAllItemByPriceRange(il, min, max);
                        Console.WriteLine("{0} {1,15} {2,15}", "Name", "Code", "Cost");
                        foreach (Item i in al)
                        {
                            Console.WriteLine("{0} {1,15} {2,15:0.0}", i.Name, i.ItemCode, i.Cost);
                        }
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                }
            }
            System.Console.ReadKey();
        }
    
}
