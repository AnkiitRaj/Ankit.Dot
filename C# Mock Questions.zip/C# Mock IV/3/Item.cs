using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Item
{
	//fill code here.
    private long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private string _itemCode;

    public string ItemCode
    {
        get { return _itemCode; }
        set { _itemCode = value; }
    }
    private double _cost;

    public double Cost
    {
        get { return _cost; }
        set { _cost = value; }
    }
    public Item() { }
    public Item(long id,string name,string itemcode,double cost)
    {
        this.Id = id;
        this.Name = name;
        this.ItemCode = itemcode;
        this.Cost = cost;
    }
    public override string ToString()
    {
        return String.Format("{0} {1,10} {2,15} {3,15:0.0}", this.Id, this.Name, this.ItemCode, this.Cost);
    }

    public static Item CreateItem(string itemDetail)
    {
        string[] s = itemDetail.Split(',');
        long id = long.Parse(s[0]);
        string name = s[1];
        string icode = s[2];
        double cost = double.Parse(s[3]);
        return new Item(id, name, icode, cost);
    }
    public static Item SearchItemByName(string itemName, List<Item> itemList)
    {
        Item n = null;
        foreach (Item i in itemList)
        {
            if (i.Name == itemName)
                return i;
        }
        return n;
    }
    public static List<Item> FindAllItemByPriceRange(List<Item> itemList, double minRate, double maxRate)
    {
        List<Item> iL = new List<Item>();
        foreach (Item i in itemList)
        {
            if (i.Cost >= minRate && i.Cost <= maxRate)
                iL.Add(i);
        }
        return iL;
    }
}
