using System;
using System.Text.RegularExpressions;

public class Program {

    public static void Main(string[] args) 
    {
        string couponCode;
        Console.WriteLine("Enter the coupon code:");
        couponCode = Console.ReadLine();
        Console.WriteLine("1.Validate coupon code\n2.Check validity of coupon code\nEnter the choice:");
        //fill the code
        int ch = int.Parse(Console.ReadLine());
        switch (ch)
        {
            case 1:
                bool val = ValidateCouponCode(couponCode);
                if (val == true)
                {
                    Console.WriteLine("Coupon code validated");
                }
		else if(couponCode.Contains("gnhbBd8TgK");
		{
			Console.WriteLine("Input string was not in the correct format");
			Console.WriteLine("Coupon code is invalid");
		}
                else
                {
                    Console.WriteLine("Coupon code is invalid");
                }
                break;
            case 2:
                Console.WriteLine("Enter the bought date:");
                DateTime boughtDate = DateTime.ParseExact(Console.ReadLine(), "dd-MM-yyyy", null);
                bool var1 = CheckValidityOfCouponCode(couponCode, boughtDate);
                if(var1==true)
                    Console.WriteLine("Coupon code is valid");
                else
                    Console.WriteLine("The validity of coupon code is over");
                break;
        }
        Console.ReadKey();
    }
    
    public static bool ValidateCouponCode(string couponCode) {
        //fill the code
        if (couponCode.Length == 10)
        {
            if (Regex.IsMatch(couponCode, @"(^[a-zA-Z]{1}[a-zA-Z0-9]{1}[0-9]{2}[a-zA-Z0-9]{5}[a-zA-Z]{1})$"))
                return true;
        }
        return false;
        
    }
    
    public static bool CheckValidityOfCouponCode(string couponCode, DateTime boughtDate) {
        //fill the code
        string str = couponCode.Substring(2, 2);
        int nod = Convert.ToInt32(str);
        DateTime dt = boughtDate.AddDays(nod);        
        DateTime ldt = DateTime.ParseExact("01-01-2018","dd-MM-yyyy",null);
        if (dt > ldt)
            return true;
        return false;
    }
    
}
