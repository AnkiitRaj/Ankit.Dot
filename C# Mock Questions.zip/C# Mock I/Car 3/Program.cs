﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        string menu = "Menu: \n 1) Valid Car registration Number \n 2) Convert Car registration Number \n "
                      + "3) Valid Driving License";
        Console.WriteLine(menu);
        Console.WriteLine("Enter choice");
        int x = Convert.ToInt32(Console.ReadLine());
        string regnum = "";
        switch (x)
        {
            case 1:
                Console.WriteLine("car registration number");
                regnum = Console.ReadLine();
                ValidateRegNum(regnum);
                break;
            case 2:
                Console.WriteLine("car registration number");
                regnum = Console.ReadLine();
                ConvertRegNum(regnum);
                break;
            case 3:
                Console.WriteLine("driving license issue date");
                DateTime date = DateTime.ParseExact(Console.ReadLine(), "dd-MM-yyyy", null);
                //input = Console.ReadLine();
                ValidateDrivingLicense(date);
                break;
        }
        Console.ReadKey();

    }

    public static void ValidateRegNum(string reg)
    {
        string[] str = reg.Split('-');
        if (str.Length < 4)
        {
            Console.WriteLine(reg + " is Invalid");
        }
        else
        {
            Console.WriteLine(reg + " is Valid");
        }
    }
    public static void ConvertRegNum(string reg)
    {
        string sttr = reg;
        string number = "";
        for (int i = 0; i < sttr.Length; i++)
        {
            if (i == 2 || i == 5 || i == 8)
            {
                number = number + "-";
            }
            else
            {
                number = number.ToUpper() + sttr[i];
            }
        }
        Console.WriteLine(number);
    }

    public static void ValidateDrivingLicense(DateTime date)
    {
        DateTime a = new DateTime(2017, 06, 15);
        //string dt = a.ToString("dd-MM-yyyy");
        TimeSpan days = a - date;
        int year = (int)(days.Days / 365);
        if (year < 10)
        {
            Console.WriteLine("{0}", year + " years old license - valid");
        }
        else
        {
            Console.WriteLine(year + " years old license - expired");
        }
    }

}
