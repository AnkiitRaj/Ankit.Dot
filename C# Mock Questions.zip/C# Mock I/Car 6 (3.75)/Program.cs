﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
    public static void Main(string[] args)
    {

        Console.WriteLine("Color to search");

        string color = Console.ReadLine();

        Console.WriteLine("Number of member cars");

        int num = int.Parse(Console.ReadLine());

        string[] details = new string[3];

        Console.WriteLine("Enter the member car details");

        for (int i = 0; i < num; i++)
        {

            string name = Console.ReadLine();

            details[i] = name;

        }

        findColor(details, color);

        Console.ReadKey();

    }



    public static void findColor(string[] details, string color)
    {

        Console.WriteLine(color + " car registration numbers:");

        for (int i = 0; i < details.Length; i++)
        {

            string[] str = details[i].Split(',');

            if (str[4] == color)
            {

                Console.WriteLine(str[3]);

            }

        }

    }

}
