﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class PaymentUtil
{
    public double MakePayment(Dictionary<string, float> bankTax, string bankName, double amount)
    {
        double tamount = 0;
        foreach (var k in bankTax.Keys)
        {
            if (k.Equals(bankName, StringComparison.InvariantCultureIgnoreCase))
            {
                tamount = (amount * (bankTax[k] / 100)) + amount;
            }
        }
        return tamount;
    }

    public double MakePayment(double amount)
    {
        float serviceTax = 5.2f;
        float vat = 2.3f;
        double tamount = 0;
        tamount = amount + (amount * (serviceTax) / 100f);
        tamount = tamount + (tamount * (vat / 100f));
        return tamount;
    }

    public double MakePayment(double amount, float discountPercent)
    {
        double tamount = 0;
        tamount = amount - (amount * (discountPercent / 100));
        return tamount;
    }
}
