﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        Dictionary<string, float> onlineBankingDict = new Dictionary<string, float>();
        onlineBankingDict.Add("ICICI", 4.2f);
        onlineBankingDict.Add("IBRD", 3f);
        onlineBankingDict.Add("IFC", 4.9f);
        onlineBankingDict.Add("HSBC", 3.9f);

        Console.WriteLine("1. Online banking\n2. Credit card\n3. Wallet");
        Console.WriteLine("Enter the choice:");
        Int32 ch = Convert.ToInt32(Console.ReadLine());
        PaymentUtil pu = new PaymentUtil();
        double tamount = 0;
        if (ch == 1)
        {
            Console.WriteLine("Enter the user name:");
            string uname = Console.ReadLine();
            Console.WriteLine("Enter the password:");
            string pass = Console.ReadLine();
            Console.WriteLine("Enter the amount:");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the bank name:");
            string bname = Console.ReadLine();
            Console.WriteLine("Username : {0}", uname);
            Console.WriteLine("Password : {0}", pass);
            Console.WriteLine("Amount : {0}", amt);
            Console.WriteLine("Bank : {0}", bname);
            tamount = pu.MakePayment(onlineBankingDict, bname, amt);
            Console.WriteLine("Total amount(Inclusive of Service Tax): {0:0.00}", tamount);
        }
        else if (ch == 2)
        {
            Console.WriteLine("Enter the account number:");
            string accnum = Console.ReadLine();
            Console.WriteLine("Enter the pin:");
            Int32 pin = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the amount:");
            double amt = Convert.ToDouble(Console.ReadLine());
            tamount = pu.MakePayment(amt);
            Console.WriteLine("AccountNumber : {0}", accnum);
            Console.WriteLine("Pin : {0}", pin);
            Console.WriteLine("Amount : {0}", amt);
            Console.WriteLine("Total amount(Inclusive of Service Tax and VAT): {0:0.00}", tamount);
        }
        else if (ch == 3)
        {
            Console.WriteLine("Enter the user name:");
            string accnum = Console.ReadLine();
            Console.WriteLine("Enter the password:");
            string pass = Console.ReadLine();
            Console.WriteLine("Enter the amount:");
            double amt = Convert.ToDouble(Console.ReadLine());
            tamount = pu.MakePayment(amt, 20.2f);
            Console.WriteLine("AccountNumber : {0}", accnum);
            Console.WriteLine("Password : {0}", pass);
            Console.WriteLine("Amount : {0}", amt);
            Console.WriteLine("Discounted amount: {0:0.00}", tamount);
        }

    }
}
