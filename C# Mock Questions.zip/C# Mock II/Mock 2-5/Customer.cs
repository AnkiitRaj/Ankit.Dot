﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Customer
{
    private long _id;
    private string _name;
    private char _gender;
    private string _email;
    private string _contactNumber;
    private DateTime _createdOn;

    public Customer(long id, string name, char gender, string email, string contactNumber, DateTime createdOn)
    {
        _id = id;
        _name = name;
        _gender = gender;
        _email = email;
        _contactNumber = contactNumber;
        _createdOn = createdOn;
    }

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }

    public char Gender
    {
        get { return _gender; }
        set { _gender = value; }
    }

    public string Email
    {
        get { return _email; }
        set { _email = value; }
    }

    public string ContactNumber
    {
        get { return _contactNumber; }
        set { _contactNumber = value; }
    }

    public DateTime CreatedOn
    {
        get { return _createdOn; }
        set { _createdOn = value; }
    }

    public static List<Customer> PopulateCustomers(List<string> csvList)
    {
        List<Customer> cList = new List<Customer>();
        foreach (string s in csvList)
        {
            string[] ss = s.Split(',');
            string[] format = new string[] { "dd/MM/yyyy HH:mm:ss" };
            cList.Add(new Customer(long.Parse(ss[0]), ss[1], char.Parse(ss[2]), ss[3], ss[4], DateTime.ParseExact(ss[5], format, null, System.Globalization.DateTimeStyles.None)));
        }
        return cList;
    }

    public static List<Customer> FindCustomerNameFromList(List<Customer> customers, string subString)
    {
        List<Customer> clist = new List<Customer>();
        foreach (Customer c in customers)
        {
            if (c.Name.Contains(subString))
            {
                clist.Add(c);
            }
        }
        return clist;
    }
}

