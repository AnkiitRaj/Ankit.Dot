﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of customer:");
        Int32 n = Convert.ToInt32(Console.ReadLine());
        List<string> customerList = new List<string>();
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Enter the customer " + (i + 1) + " detail:");
            customerList.Add(Console.ReadLine());


        }
        List<Customer> custList = new List<Customer>();
        custList = Customer.PopulateCustomers(customerList);
        Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5}", "Id", "Name", "Gender", "Email", "Contact no", "Created on");
        foreach (Customer c in custList)
        {

            Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5}"
                , c.Id, c.Name, c.Gender, c.Email, c.ContactNumber, c.CreatedOn);
        }
        Console.WriteLine("Enter the substring to search from customer list:");
        string name = Console.ReadLine();
        List<Customer> byName = Customer.FindCustomerNameFromList(custList, name);
        Console.WriteLine("{0,-15}{1,-20}{2,-15}{3,-15}{4,-15}{5}", "Id", "Name", "Gender", "Email", "Contact no", "Created on");
        foreach (Customer c in byName)
        {
            Console.WriteLine("{0,-15}{1,-20}{2,-15}{3,-15}{4,-15}{5}"
                , c.Id, c.Name, c.Gender, c.Email, c.ContactNumber, c.CreatedOn);
        }

    }
}
