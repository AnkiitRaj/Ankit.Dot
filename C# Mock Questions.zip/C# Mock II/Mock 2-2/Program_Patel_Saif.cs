﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

    class Program
    {
        static void Main(string[] args)
        {
            int choice = 1;
            do
            {
                Console.WriteLine("Menu");
                Console.WriteLine("1. Parse Name");
                Console.WriteLine("2. Valid Email");
                Console.WriteLine("3. Play Contact Number");
                Console.WriteLine("4. User Lifetime");
                Console.WriteLine("5. Exit");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter name:");
                        string name = Console.ReadLine();
                        ParseName(name);
                        break;
                    case 2:
                        Console.WriteLine("Enter E-mail id:");
                        string mail = Console.ReadLine();
                        IsValidEmail(mail);
                        break;
                    case 3:
                        Console.WriteLine("Enter contact number:");
                        string contact = Console.ReadLine();
                        playContactNumber(contact);
                        break;
                    case 4:
                        Console.WriteLine("Enter Created on date(dd-MM-yyyy HH:mm):");
                        string sss = Console.ReadLine();
                        userLifeTime(sss);
                        break;
                }
            } while (choice != 5);
        }
        public static void ParseName(string name)
        {
            string pattern = "[^0-9A-Za-z ]";
            string n = Regex.Replace(name, pattern, " ");
            Console.WriteLine(n);
        }
        public static void userLifeTime(string time)
        {
            DateTime dateOld = DateTime.ParseExact("28-07-2017 09:00", "dd-MM-yyyy hh:mm", null);
            DateTime dd = DateTime.ParseExact(time, "dd-MM-yyyy HH:mm", null, System.Globalization.DateTimeStyles.None);
            TimeSpan x = dd - dateOld;
            var f = x.TotalMinutes;
            Console.WriteLine("Life time is: {0} minutes", f);
        }
        public static void IsValidEmail(string email)
        {
            if ((!email.Contains("@.")) && email.Contains("@") && (email.EndsWith("com") || email.EndsWith("org") || email.EndsWith("net")))
                Console.WriteLine("Email id is valid");
            else
                Console.WriteLine("Email is invalid");
        }
        public static void playContactNumber(string phone)
        {
            int i, j, sum = 0;
            string[] s = phone.Split('-');
            if (s.Length == 3 && s[0].Length == 3 && s[1].Length == 4 && s[2].Length == 10)
            {
                for (i = 0; i < 3; i++)
                {
                    char[] c = s[i].ToCharArray();
                    for (j = 0; j < c.Length; j++)
                    {
                        if (!char.IsDigit(c[j]))
                            break;
                    }
                    if (j < c.Length)
                        break;
                }
                if (i < 3)
                {
                    Console.WriteLine("Contact number invalid");
                }
                else
                {
                    int[] ss = Array.ConvertAll(Array.ConvertAll(s[2].ToCharArray(), Convert.ToString), Convert.ToInt32);
                    for (i = 0; i < ss.Length; i++)
                    {
                        sum = sum + ss[i];
                    }
                    while (sum >= 10)
                    {
                        string s5 = Convert.ToString(sum);
                        sum = 0;
                        int[] temp = Array.ConvertAll(Array.ConvertAll(s5.ToCharArray(), Convert.ToString), Convert.ToInt32);
                        for (i = 0; i < temp.Length; i++)
                        {
                            sum = sum + temp[i];
                        }
                    }
                    Console.WriteLine("Sum of contact number: " + sum);

                }
            }
            else
                Console.WriteLine("Contact number invalid");
      }
}