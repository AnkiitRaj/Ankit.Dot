﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{

    static void Main(string[] args)
    {
        int choice = 1;
        do
        {
            Console.WriteLine("Menu");
            Console.WriteLine("1. Parse Name");
            Console.WriteLine("2. Valid Email");
            Console.WriteLine("3. Play Contact Number");
            Console.WriteLine("4. User Lifetime");
            Console.WriteLine("5. Exit");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Enter name:");
                    string name = Console.ReadLine();
                    ParseName(name);
                    break;
                case 2:
                    Console.WriteLine("Enter E-mail id:");
                    string email = Console.ReadLine();
                    IsValidEmail(email);
                    break;
                case 3:
                    Console.WriteLine("Enter contact number:");
                    string phone = Console.ReadLine();
                    playContactNumber(phone);
                    break;
                case 4:
                    Console.WriteLine("Enter Created on date(dd-MM-yyyy HH:mm):");
                    string time = Console.ReadLine();
                    userLifeTime(time);
                    break;
            }
        } while (choice != 5);
    }
    public static void ParseName(string name)
    {
        name = Regex.Replace(name, @"[^0-9a-zA-Z]+", " ");
        Console.WriteLine(name);
    }
    public static void userLifeTime(string time)
    {

        DateTime dateOld = DateTime.ParseExact("28-07-2017 09:00", "dd-MM-yyyy HH:mm", null);
        DateTime curDate = DateTime.ParseExact(time, "dd-MM-yyyy HH:mm", null, System.Globalization.DateTimeStyles.None);
        TimeSpan ts = curDate - dateOld;
        var f = ts.TotalMinutes;
        Console.WriteLine("Life time is:" + f + "minutes");
    }
    public static void IsValidEmail(string email)
    {
        if (Regex.IsMatch(email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
        {
            Console.WriteLine("Email id is valid");
        }
        else
        {
            Console.WriteLine("Email is invalid");
        }
    }
    public static void playContactNumber(string phone)
    {
        if (Regex.IsMatch(phone, @"\d{3}([-]*)\d{4}([-]*)\d{10}"))
        {
            long num = Convert.ToInt64(phone.Substring(9));
            while (num >= 10)
            {
                long sum = 0;
                while (num != 0)
                {
                    int rem = (int)(num % 10);
                    num = num / 10;
                    sum = sum + rem;
                }
                num = sum;
            }
            Console.WriteLine("Sum of contact number:" + num);
        }
        else
        {
            Console.WriteLine("Contact number invalid");
        }
    }
}