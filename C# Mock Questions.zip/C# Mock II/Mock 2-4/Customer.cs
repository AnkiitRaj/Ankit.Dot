﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Customer
{
    private long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    private string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private char _gender;

    public char Gender
    {
        get { return _gender; }
        set { _gender = value; }
    }
    private string _email;

    public string Email
    {
        get { return _email; }
        set { _email = value; }
    }
    private string _contactNumber;

    public string ContactNumber
    {
        get { return _contactNumber; }
        set { _contactNumber = value; }
    }
    private DateTime _createdOn;

    public DateTime CreatedOn
    {
        get { return _createdOn; }
        set { _createdOn = value; }
    }
    private Address _address;

    public Address Address
    {
        get { return _address; }
        set { _address = value; }
    }

    public Customer() { }
    public Customer(long id, string name, char gender, string email, string contactNumber, DateTime createdOn, Address address)
    {
        this._id = id;
        this._name = name;
        this._gender = gender;
        this._email = email;
        this._contactNumber = contactNumber;
        this._createdOn = createdOn;
        this._address = address;
    }
    public Customer FindCustomerById(List<Customer> customerList, int id)
    {
        Customer c = new Customer();
        int count = 0;
        foreach (Customer cust in customerList)
        {
            if (id == cust._id)
            {
                count = 1;
                c = cust;
            }
        }
        if (count == 0)
            return null;
        else
            return c;
    }
    public List<Customer> FindCustomerListByState(List<Customer> customerList, string state)
    {
        List<Customer> cust1 = new List<Customer>();
        foreach (Customer c in customerList)
        {
            if (state.Equals(c.Address.State))
            {
                cust1.Add(c);
            }
        }
        return cust1;
    }
}
