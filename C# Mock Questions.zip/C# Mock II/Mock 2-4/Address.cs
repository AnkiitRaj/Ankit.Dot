﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Address
{
    private string _street;

    public string Street
    {
        get { return _street; }
        set { _street = value; }
    }
    private string _city;

    public string City
    {
        get { return _city; }
        set { _city = value; }
    }
    private string _state;

    public string State
    {
        get { return _state; }
        set { _state = value; }
    }
    private string _country;

    public string Country
    {
        get { return _country; }
        set { _country = value; }
    }
    private int _zipCode;

    public int ZipCode
    {
        get { return _zipCode; }
        set { _zipCode = value; }
    }
    public Address() { }
    public Address(string street, string city, string state, string country, int zipCode)
    {
        this._street = street;
        this._city = city;
        this._state = state;
        this._country = country;
        this._zipCode = zipCode;
    }
}
