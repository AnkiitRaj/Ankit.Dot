﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static void Main(string[] args)
    {
        List<Customer> customerList = new List<Customer>
          {
              new Customer(1, "John Smith", 'M', "johnsmith@a.com", "+98-7488-8554744596",
                   DateTime.ParseExact("15/02/2017 16:30:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("15th St", "Buffalo", "New York", "USA", 14220)),
               new Customer(2, "Aekerman", 'M', "aekerman@a.com", "+78-7485-9555874846",
                   DateTime.ParseExact("18/03/2017 15:45:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("Avenue", "Plano", "Texas", "USA", 75025)),
              new Customer(3, "Madeleine", 'F', "madeleine@a.com", "+78-9855-7488742136",
                   DateTime.ParseExact("22/02/2017 16:45:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("Parc St", "Lubbock", "Texas", "USA", 79404)),
               new Customer(4, "Edrick", 'M', "edrick@a.com", "+99-8787-7844859978",
                   DateTime.ParseExact("15/03/2017 15:45:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("145th St", "Wasilla", "Alaska", "USA", 99629)),
              new Customer(5, "Tedmond", 'M', "tedmond@a.com", "+88-7844-8854799658",
                   DateTime.ParseExact("15/03/2017 15:45:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("Port Townsend", "Tacoma", "Washington", "USA", 98412)),
              new Customer(6, "Nelson", 'M', "nelson@a.com", "+88-7848-8857488956",
                   DateTime.ParseExact("17/05/2017 10:35:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("1st St", "Akron", "Ohio", "USA", 44304)),
              new Customer(7, "Dalton", 'M', "dalton@a.com", "+88-8879-8854741124",
                   DateTime.ParseExact("01/05/2017 17:25:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("Lake city", "Newburgh", "New York", "USA", 12550)),
               new Customer(8, "Raymond", 'M', "raymond@a.com", "+89-7748-8859112478",
                   DateTime.ParseExact("17/06/2017 08:45:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("Wall Street", "Texas City", "Texas", "USA", 77591)),
              new Customer(9, "Rosemary", 'F', "rosemary@a.com", "+89-7844-8857489958",
                   DateTime.ParseExact("22/04/2017 16:15:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("Georgetown", "Olympia", "Washington", "USA", 98506)),
              new Customer(10, "Ruford", 'M', "ruford@a.com", "+88-7485-8597448596",
                   DateTime.ParseExact("12/02/2017 09:05:00","dd/MM/yyyy HH:mm:ss",null,System.Globalization.DateTimeStyles.None),
                   new Address("Baker street", "Miles City", "Montana", "USA", 59301))
          };


        Customer customer = new Customer();

        Console.WriteLine("Menu\n1. Find customer by id\n2. Find customer by states\nEnter the choice:");

        switch (Convert.ToInt32(Console.ReadLine()))
        {
            case 1:
                Console.WriteLine("Enter the Id to find customer:");

                int id = int.Parse(Console.ReadLine());

                customer = customer.FindCustomerById(customerList, id);
                if (customer != null)
                {
                    Console.WriteLine("Customer Name: {0}\nEmail: {1}\nCity: {2}\nState: {3}\nCountry: {4}\nZip code: {5}",
                    customer.Name, customer.Email, customer.Address.City, customer.Address.State,
                    customer.Address.Country, customer.Address.ZipCode);
                }
                else
                    Console.WriteLine("No Customer with that id");

                break;
            case 2:
                Console.WriteLine("Enter the state:");

                string state = Console.ReadLine();
                List<Customer> customerByState = new List<Customer>();
                customerByState = customer.FindCustomerListByState(customerList, state);

                if (customerByState.Count != 0)
                {
                    Console.WriteLine("{0,-15}{1,-20}{2,-15}{3,-15}{4}", "Name", "Email", "City", "Country", "Zipcode");

                    foreach (Customer cc in customerByState)
                    {
                        Console.WriteLine("{0,-15}{1,-20}{2,-15}{3,-15}{4}", cc.Name, cc.Email, cc.Address.City, cc.Address.Country, cc.Address.ZipCode);
                    }
                }
                else
                    Console.WriteLine("No customer belongs that state");

                break;
        }
    }
}

