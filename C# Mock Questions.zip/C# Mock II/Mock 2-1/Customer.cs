﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Customer
    {
        private long _id;

        public long Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private char _gender;

        public char Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }
        private string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        private string _contactNumber;

        public string ContactNumber
        {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }
        private DateTime _createdOn;

        public DateTime CreatedOn
        {
            get { return _createdOn; }
            set { _createdOn = value; }
        }
        public Customer() { }
        public Customer(long Id, string Name, char Gender, string Email, string ContactNumber, DateTime CreatedOn)
        {
            this.Id = Id;
            this.Name = Name;
            this.Gender = Gender;
            this.Email = Email;
            this.ContactNumber = ContactNumber;
            this.CreatedOn = CreatedOn;
        }
        public override string ToString()
        {
            return String.Format("Customer id: {0}\nCustomer: {1}\nCustomer contact details: {2},{3}",this.Id,this.Name,this.ContactNumber,this.Email);
        }
    }
