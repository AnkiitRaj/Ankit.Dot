﻿using System;
using System.Collections.Generic;

class Program
{
	public static void Main(string[] args)
	{
		Console.WriteLine("Enter the number of customer:");
		int n = Convert.ToInt32(Console.ReadLine());

		List<string> csvList = new List<string>();

		for(int i=0; i < n; i++)
		{
			Console.WriteLine("Enter the customer "+(i+1)+" details:");

            //fill your code
		}

		Console.WriteLine("State - No of customers");

		//fill your code
		
		Console.WriteLine("{0,-15}{1,-20}{2,-5}{3,-20}{4,-20}{5,-20}{6,-15}{7,-15}{8,-15}{9,-15}{10,-15}", "Id", "Name", "Gender", "Email", "Contact Number", "Created On", "Streer", "City", "State", "Country", "Zipcode");

		//fill your code
	}
}