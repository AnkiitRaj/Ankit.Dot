create database ATS;
use ATS;
create table UserMaster
(
fname varchar(200) not null,
lname varchar(200) not null,
phoneNumber varchar(200) not null,
userId varchar(200) primary key,
upassword varbinary(max) not null
);

select * from UserMaster;

create table CustomerMaster
(
cid varchar(200) primary key,
cname varchar(200) not null,
cage varchar(200) not null,
cgender varchar(200) not null,
userId varchar (200) not null,
foreign key (userId) references UserMaster(userId)
);

Select * from CustomerMaster;

create table HotelMaster
(
hid varchar(200) primary key,
hname varchar(200) not null,
hlocation varchar(200) not null,
hrating varchar(200) not null
);

Select * from HotelMaster;

create table RoomMaster
(
rid varchar(200) primary key,
hid varchar(200) not null,
rcapacity varchar(200) not null,
ravailable bit not null,
rwifi bit not null,
rtype  varchar(200) not null,
rprice money not null,
foreign key (hid) references HotelMaster(hid)
);

Select * from RoomMaster;

create table PaymentMaster
(
pid varchar(200) primary key,
card_number varchar(200) not null,
name_on_card varchar(200) not null,
userId varchar(200) not null,
foreign key(userId) references UserMaster(userId)
);

Select * from PaymentMaster;

create table BookingMaster
(
bid varchar(200) primary key,
bdate date not null, 
bcheckin datetime not null,
bcheckout datetime not null,
btotalprice money not null,
bstatus bit not null,
hid varchar(200) not null,
rid varchar(200) not null,
userId varchar(200) not null,
cid varchar(200) not null,
pid varchar(200) not null,
foreign key (cid) references CustomerMaster(cid),
foreign key (userId) references UserMaster(userId),
foreign key (hid) references HotelMaster(hid),
foreign key (rid) references RoomMaster(rid),
foreign key (pid) references PaymentMaster(pid)
);

Select * from BookingMaster;

