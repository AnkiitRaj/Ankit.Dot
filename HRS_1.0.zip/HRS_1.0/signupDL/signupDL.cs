﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupBO;
using System.Data;
using System.Data.SqlClient;

namespace signupDL
{
    public class signupDL
    {
        public int Insertsignup(signupBo signup, out object id)
        {
            string commandText = "Insertsignup"; //"insert into dept(deptname,deptloc)"+"values(@dname,@dloc)";
            SqlParameter[] sqlparam = new SqlParameter[6];
            sqlparam[0] = new SqlParameter("@fname", signup.Fname);
            sqlparam[1] = new SqlParameter("@lname", signup.Lname);
            sqlparam[2] = new SqlParameter("@phoneNumber", signup.PhoneNumber);
            sqlparam[3] = new SqlParameter("@userId", signup.UserId);
            sqlparam[4] = new SqlParameter("@upassword", signup.Upassword);
            sqlparam[5] = new SqlParameter("@id", SqlDbType.Int);
            sqlparam[5].Direction = ParameterDirection.Output;

            return SqlHelperDL.ExecuteNonQuery(commandText, CommandType.StoredProcedure, sqlparam, out id);
        }
    }
}
