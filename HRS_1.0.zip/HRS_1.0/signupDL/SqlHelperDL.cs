﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace signupDL
{
    public static class SqlHelperDL
    {
        public static int ExecuteNonQuery(string commandText, CommandType commandType, SqlParameter[] commandParameters, out object oval)
        {
            SqlConnection connection = null;
            try
            {
                //connection = new SqlConnection(@"data source=PCXXXXXX\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=HRS");
                connection = new SqlConnection(ConfigurationManager.AppSettings["sqlConnectionString"].ToString());
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = commandType;
                command.CommandText = commandText;
                foreach (SqlParameter p in commandParameters)
                {
                    command.Parameters.Add(p);
                }
                connection.Open();
                int r = command.ExecuteNonQuery();
                oval = null;
                foreach (SqlParameter sp in commandParameters)
                {
                    if (sp.Direction == ParameterDirection.Output)
                        oval = sp.Value;
                }
                //oval = command.Parameters["@id"].Value;
                return r;
            }
            catch
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
