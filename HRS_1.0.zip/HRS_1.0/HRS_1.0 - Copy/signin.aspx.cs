﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class signin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(@"data source=PC399003\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=HRS1");
            SqlCommand com = new SqlCommand();
            string userID = Request.Params["userId"].ToString();
            com.CommandText = "select upassword from UserMaster where userId=@userID";
            SqlParameter[] search = new SqlParameter[1];
            search[0] = new SqlParameter("@userid", userID);
            string pass = Request.Params["psw"].ToString();
            com.Parameters.AddRange(search);
            com.Connection = con;
            con.Open();
            string password = System.Text.ASCIIEncoding.ASCII.GetString((byte[])com.ExecuteScalar());
            if (password.Equals(pass))
            {
                Session["id"] = userID;
                Response.Write("<script>window.location.href ='http://localhost:61665/HRS_1.0/Redirectfront_page.aspx'</script>");
            }
            else
            {
                
                //ViewState["userId"] = userID;
                //Response.Redirect("http://localhost:61665/HRS_1.0/signin.aspx?userId="+userID);
                Label1.Text = "Invalid Username or Password";
                Label1.ForeColor = System.Drawing.Color.Red;
                Session.RemoveAll();
            }
            con.Close();
        }
        catch
        {
            Label1.Text = "Invalid Username or Password";
            Label1.ForeColor = System.Drawing.Color.Red;  
            //Response.Write("<script>alert('Incorrect User ID PASSWORD')</script><script>window.location.href ='signin.aspx'</script>");
        }
    }
}