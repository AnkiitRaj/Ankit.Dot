﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class front_page : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(@"data source=PC399003\MSSQLSERVER2014;" + "Integrated Security=SSPI;Database=HRS1");
        //SqlCommand com = new SqlCommand();
        //com.CommandText = "select count(userId) from UserMaster where userId=@userID";
        
        //com.Connection = con;
        //SqlParameter[] param = new SqlParameter[5];
        //param[0] = new SqlParameter("@fname", SqlDbType.VarChar);
        //param[1] = new SqlParameter("@lname", SqlDbType.VarChar);
        //param[2] = new SqlParameter("@phoneNumber", SqlDbType.VarChar);
        //param[3] = new SqlParameter("@userId", SqlDbType.VarChar);
        //param[4] = new SqlParameter("@upassword", SqlDbType.VarBinary);
        //param[0].Value = Request.Params["fname"].ToString();
        //param[1].Value = Request.Params["lname"].ToString();
        //param[2].Value = Request.Params["phoneNumber"].ToString();
        //param[3].Value = Request.Params["userID"].ToString();
        //string sp = Request.Params["psw"].ToString();
        //string s1 = Request.Params["psw-repeat"].ToString();

        Response.Write("<script>window.location.href ='http://localhost:61665/HRS_1.0/reserve2.aspx'</script>");
    }
}