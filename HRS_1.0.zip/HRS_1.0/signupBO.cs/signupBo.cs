﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace signupBO
{
    public class signupBo
    {
        private string fname;

        public string Fname
        {
            get { return fname; }
            set { fname = value; }
        }
        private string lname;

        public string Lname
        {
            get { return lname; }
            set { lname = value; }
        }
        private string phoneNumber;

        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }
        private string userId;

        public string UserId
        {
            get { return userId; }
            set { userId = value; }
        }
        private string upassword;

        public string Upassword
        {
            get { return upassword; }
            set { upassword = value; }
        }

        public signupBo() { }
        public signupBo(string fname, string lname, string phoneNumber, string userId, string upassword)
        {
            this.Fname = fname;
            this.Lname = lname;
            this.PhoneNumber = phoneNumber;
            this.UserId = userId;
            this.Upassword = upassword;
        }
    }
}
