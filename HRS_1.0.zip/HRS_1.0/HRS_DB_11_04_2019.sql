create database HRS2;
use HRS2;
create table UserMaster
(
fname varchar(200) not null,
lname varchar(200) not null,
phoneNumber varchar(200) not null,
userId varchar(200) primary key,
upassword varbinary(max) not null
);

create table CustomerMaster
(
cid varchar(200) primary key,
cname varchar(200) not null,
cage varchar(200) not null,
cgender varchar(200) not null,
cnumber varchar (200) not null,
userId varchar (200) not null,
foreign key (userId) references UserMaster(userId)
);

create table HotelMaster
(
hid varchar(200) primary key,
hname varchar(200) not null,
hlocation varchar(200) not null,
hrating varchar(200) not null
);



create table RoomMaster
(
rid varchar(200) primary key,
hid varchar(200) not null,
rcapacity varchar(200) not null,
ravailable bit not null,
rwifi bit not null,
rtype  varchar(200) not null,
rprice money not null,
foreign key (hid) references HotelMaster(hid)
);


create table PaymentMaster
(
pid varchar(200) primary key,
card_number varchar(200) not null,
name_on_card varchar(200) not null,
userId varchar(200) not null,
foreign key(userId) references UserMaster(userId)
);

create table BookingMaster
(
bid varchar(200) primary key,
bdate date not null, 
bcheckin datetime not null,
bcheckout datetime not null,
btotalprice money not null,
bstatus bit not null,
hid varchar(200) not null,
rid varchar(200) not null,
userId varchar(200) not null,
cid varchar(200) not null,
pid varchar(200) not null,
foreign key (cid) references CustomerMaster(cid),
foreign key (userId) references UserMaster(userId),
foreign key (hid) references HotelMaster(hid),
foreign key (rid) references RoomMaster(rid),
foreign key (pid) references PaymentMaster(pid)
);





alter table PaymentMaster drop constraint FK__PaymentMast__cid__1FCDBCEB

alter table PaymentMaster drop column cid;

select * from PaymentMaster;

create table AdminMaster
(
aloginId varchar(200) not null,
aloginPw varbinary(max) not null,
hid varchar(200) not null,
foreign key (hid) references HotelMaster(hid)
);


select h.hid,r.rid from HotelMaster h join RoomMaster r on h.hid=r.rid  join BookingMaster b on b.rid=r.rid;



select h.hname, count(r.rid) as NoOfRoomsAvailable from RoomMaster r 
join HotelMaster h on r.hid = h.hid
join BookingMaster b on h.hid=b.hid
where (r.ravailable =1) and (b.bcheckin not between '2019-10-05 11:00:00.000' and '2019-05-06 11:00:00.000') and h.hlocation='Kolkata'
group by h.hname
order by h.hname;

select * from RoomMaster  order by hid;

select * from BookingMaster;

select * from UserMaster;

select * from CustomerMaster;

Insert into CustomerMaster values(1,'Ankit Raj',24,'Male',8882742837,'Ankit@gmail.com');
Insert into CustomerMaster values(2,'Divyanjali Sharma',22,'Female',9875632142,'divyanjali@gmail.com');
Insert into CustomerMaster values(3,'Nilanjan  Nanda',35,'Male',7894561233,'nilanjan@gmail.com');
Insert into CustomerMaster values(4,'Kshatriya Prabhu',21,'Male',9442693795,'Prabu@gmail.com');
Insert into CustomerMaster values(5,'Pradeep Kumar',34,'Male',6541239873,'pradeep@gmail.com');
Insert into CustomerMaster values(6,'Sanjeev Mishra',27,'Male',7866003513,'sanjiv@gmail.com');
Insert into CustomerMaster values(7,'Soumen Chowdhury',32,'Male',8961413350,'soumen@gmail.com');
Insert into CustomerMaster values(8,'Subham Chowdhury',45,'Male',9831254687,'subham@gmail.com');

select * from HotelMaster;

Insert into HotelMaster values(1,'Central Heritage Resort','Kolkata',3);
Insert into HotelMaster values(2,'The Orchid London','Kolkata',4);
Insert into HotelMaster values(3,'Hotel Oberoi Grand','Kolkata',3);
Insert into HotelMaster values(4,'Hotel Hayatt Regency','Kolkata',3);
Insert into HotelMaster values(5,'Hotel Novotel','Kolkata',2);
Insert into HotelMaster values(6,'Hotel Pride Plaza','Kolkata',3);
Insert into HotelMaster values(7,'Central Heritage Resort and Spa','Kolkata',3);


select * from RoomMaster  where ravailable = 1 order by hid ;



Insert into RoomMaster values(1,1,3,1,1,'Ac',8999);
Insert into RoomMaster values(2,1,2,1,1,'Non-Ac',7499);
Insert into RoomMaster values(3,1,3,0,1,'Deluxe',9799);
Insert into RoomMaster values(4,1,2,0,1,'Ac',89999);
Insert into RoomMaster values(5,1,2,1,1,'Deluxe',9799);
Insert into RoomMaster values(6,1,2,1,1,'Ac',8999);
Insert into RoomMaster values(7,1,2,0,1,'Deluxe',9799);

Insert into RoomMaster values(8,2,3,1,1,'Ac',7459);
Insert into RoomMaster values(9,2,2,0,1,'Non-Ac',5999);
Insert into RoomMaster values(10,2,3,1,1,'Deluxe',8999);
Insert into RoomMaster values(11,2,2,1,1,'Ac',7459);


Insert into RoomMaster values(12,3,2,0,1,'Non-Ac',5999);
Insert into RoomMaster values(13,3,3,1,1,'Deluxe',8999);
Insert into RoomMaster values(14,3,2,1,1,'Ac',7459);

Insert into RoomMaster values(15,4,3,1,1,'Non-Ac',5599);
Insert into RoomMaster values(16,4,2,0,1,'Deluxe',7799);
Insert into RoomMaster values(17,4,3,1,1,'Ac',6759);

Insert into RoomMaster values(18,5,3,1,1,'Non-Ac',4699);
Insert into RoomMaster values(19,5,2,0,1,'Deluxe',8899);
Insert into RoomMaster values(20,5,3,1,1,'Ac',7459);

Insert into RoomMaster values(21,6,2,0,1,'Deluxe',9899);
Insert into RoomMaster values(22,6,3,1,1,'Ac',7419);


Insert into RoomMaster values(23,7,2,0,1,'Ac',7419);
Insert into RoomMaster values(24,7,2,1,1,'Non-Ac',6699);

select * from BookingMaster;
Insert into BookingMaster values(1,'2019-04-11','2019-04-13 11:00:00 AM','2019-04-15 10:00:00 AM',7499,1,1,3,'Ankit@gmail.com',1);
Insert into BookingMaster values(2,'2019-04-15','2019-04-16 11:00:00 AM','2019-04-18 10:00:00 AM',7499,1,1,4,'Ankit@gmail.com',1);
Insert into BookingMaster values(3,'2019-04-18','2019-04-19 11:00:00 AM','2019-04-21 10:00:00 AM',7499,1,1,7,'Ankit@gmail.com',1);
Insert into BookingMaster values(4,'2019-04-21','2019-04-22 11:00:00 AM','2019-04-23 10:00:00 AM',8999,1,2,9,'divyanjali@gmail.com',2);
Insert into BookingMaster values(5,'2019-04-23','2019-04-24 11:00:00 AM','2019-04-26 10:00:00 AM',9799,1,3,12,'nilanjan@gmail.com',3);
Insert into BookingMaster values(6,'2019-04-26','2019-04-27 11:00:00 AM','2019-04-29 10:00:00 AM',7499,1,4,16,'Prabu@gmail.com',4);
Insert into BookingMaster values(7,'2019-04-29','2019-04-30 11:00:00 AM','2019-05-02 10:00:00 AM',7499,1,5,19,'pradeep@gmail.com',5);
Insert into BookingMaster values(8,'2019-05-02','2019-05-03 11:00:00 AM','2019-05-05 10:00:00 AM',7499,1,6,21,'sanjiv@gmail.com',6);
Insert into BookingMaster values(9,'2019-05-05','2019-05-06 11:00:00 AM','2019-05-08 10:00:00 AM',7499,1,7,23,'soumen@gmail.com',7);

delete from BookingMaster;

delete from BookingMaster

select  *  from PaymentMaster;

Insert into PaymentMaster values(1,'2019-04-11','4564 6798 2346 9567','Ankit Raj',1,1,'Ankit@gmail.com');
Insert into PaymentMaster values(2,'2019-04-15','4564 6798 2346 9567','Ankit Raj',2,1,'Ankit@gmail.com');
Insert into PaymentMaster values(3,'2019-04-18','4564 6798 2346 9567','Ankit Raj',3,1,'Ankit@gmail.com');
Insert into PaymentMaster values(4,'2019-04-21','8697 5364 5768 2435','Divyanjali Sharma',4,2,'divyanjali@gmail.com');
Insert into PaymentMaster values(5,'2019-04-23','5746 6857 2456 3857','Nilanjan  Nanda',5,3,'nilanjan@gmail.com');
Insert into PaymentMaster values(6,'2019-04-26','9354 5769 2458 6735','Kshatriya Prabhu',6,4,'Prabu@gmail.com');
Insert into PaymentMaster values(7,'2019-04-29','1435 5739 5639 6846','Pradeep Kumar',7,5,'pradeep@gmail.com');
Insert into PaymentMaster values(8,'2019-05-02','3857 6753 9265 3857','Sanjeev Mishra',8,6,'sanjiv@gmail.com');
Insert into PaymentMaster values(9,'2019-05-05','7583 5648 6758 8674','Soumen Chowdhury',9,7,'soumen@gmail.com');


select r.hid,r.rid from RoomMaster r left join BookingMaster b on r.rid=b.rid where r.ravailable=1 group by r.hid,r.rid  order by r.hid;

select r.hid,count(r.rid) as NumberOfRoomsAvailable from RoomMaster r where r.ravailable=1 group by r.hid order by r.hid;

select * from RoomMaster where ravailable=1 order by hid;
select * from RoomMaster order by hid;
select * from BookingMaster;

select h.hid,h.hname, count(r.rid) as NoOfRoomsAvailable from RoomMaster r 
join HotelMaster h on r.hid = h.hid
join BookingMaster b on h.hid=b.hid
where (r.ravailable =1) and (b.bcheckin not between '2019-04-13 11:00:00 AM' and '2019-04-18 10:00:00 AM')
group by h.hid,h.hname
order by h.hid,h.hname;

