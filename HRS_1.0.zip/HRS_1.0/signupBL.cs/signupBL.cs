﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupBO;
using signupDL;

namespace signupBL
{
    public class signupBL
    {
        public int Addsignup(signupBo SignupBO)
        {
            try
            {
                signupBL signup = new signupBL();
                return signup.Insertsignup(SignupBO);
            }
            catch
            {
                throw;
            }
        }
    }

}
