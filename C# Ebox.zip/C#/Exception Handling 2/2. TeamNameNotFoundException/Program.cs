using System;
using System.Collections.Generic;
class Program
    {
        static void Main(string[] args)
        {
         Console.WriteLine("Enter the expected winner team of IPL Season 4");
         string teamNamew = Console.ReadLine();
         string teamNamer = null;
        try {
            if ((teamNamew.Contains("Chennai Super Kings") 
                        || (teamNamew.Contains("Deccan Chargers") 
                        || (teamNamew.Contains("Delhi Daredevils") 
                        || (teamNamew.Contains("Kings XI Punjab") 
                        || (teamNamew.Contains("Kolkata Knight Riders") 
                        || (teamNamew.Contains("Mumbai Indians") 
                        || (teamNamew.Contains("Rajasthan Royals") || teamNamew.Contains("Royal Challengers Bangalore"))))))))) {
                Console.WriteLine("Enter the expected runner Team of IPL Season 4");
                teamNamer = Console.ReadLine();
                if ((teamNamer.Contains("Chennai Super Kings") 
                            || (teamNamer.Contains("Deccan Chargers") 
                            || (teamNamer.Contains("Delhi Daredevils") 
                            || (teamNamer.Contains("Kings XI Punjab") 
                            || (teamNamer.Contains("Kolkata Knight Riders") 
                            || (teamNamer.Contains("Mumbai Indians") 
                            || (teamNamer.Contains("Rajasthan Royals") || teamNamer.Contains("Royal Challengers Bangalore"))))))))) {
                    Console.WriteLine(("Expected IPL Season 4 winner: " + teamNamew));
                    Console.WriteLine(("Expected IPL Season 4 runner: " + teamNamer));
                }
                else {
                    throw new CustomException();
                }
                
            }
            else {
                throw new CustomException();
            }
            
        }
        catch (CustomException e)
        {
            Console.WriteLine("TeamNameNotFoundException: Entered team is not a part of IPL Season 4");
        }
        Console.ReadKey();
        }
    }



   

