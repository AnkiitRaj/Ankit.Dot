﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class CustomException : System.Exception
{
    public CustomException(string s)
        : base(s)
    {
        Console.WriteLine("TeamNameNotFoundException: Entered team is not a part of IPL Season 4");
    }
    public CustomException()
    { }
}
