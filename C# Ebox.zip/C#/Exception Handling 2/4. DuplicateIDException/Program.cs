using System;
public class Program
{ 
 static void Main(string[] args)
 {
        Console.WriteLine("Enter the number of players suggested");
        int noOfPlayer = int.Parse(Console.ReadLine());
        int[] id = new int[noOfPlayer];
        string[] name = new string[noOfPlayer];
        int count = 0;
        try {
            for (int i = 0; (i < noOfPlayer); i++) {
                Console.WriteLine(("Enter player " 
                                + ((i + 1) 
                                + " details")));
                id[i] = int.Parse(Console.ReadLine());
                name[i] = Console.ReadLine();
                for (int j = 0; (j <= i); j++) {
                    if ((id[j] == id[i])) {
                        count++;
                    }
                    
                    if ((count == 2)) {
                        throw new DuplicateIdException();
                    }
                    
                }
                
                count = 0;
            }
            
            for (int i = 0;i < noOfPlayer; i++) {
                Console.WriteLine(id[i] + (" " + name[i]));
            }
            
        }
        catch (DuplicateIdException e)
        {
            Console.WriteLine("DuplicateIdException : Player Id must be unique");       //  TODO: handle exception
        }
 }
}



