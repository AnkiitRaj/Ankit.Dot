using System;

public class DuplicateIdException : Exception
{

  
    public DuplicateIdException(string message) :base(message)
    {
        Console.WriteLine("DuplicateIdException : Player Id must be unique");    
    }
    public DuplicateIdException()
    { }
    
}
