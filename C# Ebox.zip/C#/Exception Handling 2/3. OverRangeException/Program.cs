using System;
using System.Collections.Generic;
class Program
    {
        public static void Main(string[] args)
        {
            float over = 0;
            float runs = 0;
            try
            {
                Console.WriteLine("Enter the total runs scored");
                runs = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter the total overs faced");
                over = float.Parse(Console.ReadLine());
            }
            catch (Exception e)
            {
                //  TODO: handle exception
            }
            try
            {
                if (((over < 0) || (over > 20)))
                {
                    throw new CustomException();
                }


                float res = (runs / over);
                Console.Write("Current Run Rate :{0:0.00}", res);
            }
            catch (Exception ex)
            {
                Console.WriteLine("OverRangeException: Over is not in the specified range");            
            }
        Console.ReadKey();
        }
    }



   

