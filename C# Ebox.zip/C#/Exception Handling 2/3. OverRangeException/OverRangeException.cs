﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class CustomException : Exception
{
    public CustomException(string s) : base(s)
    {
        Console.WriteLine("OverRangeException: Over is not in the specified range");
    }
    public CustomException()
    { }
}
