using System;
public class Program
{ 
 static void Main(string[] args)
 {
        Console.WriteLine("Enter the player name");
         string name = Console.ReadLine();
         Console.WriteLine("Enter the player age");
        int age = int.Parse(Console.ReadLine());
        try
        {
            if (age < 19)
            {
             throw new InvalidAgeRangeException();
            }
            
        Console.WriteLine("Player name : " + name);
        Console.WriteLine("Player age : " + age);
        }
        catch (InvalidAgeRangeException e)
        {
            Console.WriteLine("CustomException: InvalidAgeRangeException");       //  TODO: handle exception
        }
    }
}



