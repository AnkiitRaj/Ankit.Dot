﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class FourWheeler : Vehicle
    {
        string _audioSystem;

public string AudioSystem
{
  get { return _audioSystem; }
  set { _audioSystem = value; }
}
    
    int _numberOfDoors;

public int NumberOfDoors
{
  get { return _numberOfDoors; }
  set { _numberOfDoors = value; }
}
    
    public FourWheeler(string make, string vehicleNumber, string fuelType, int fuelCapacity, int cc, string audioSystem, int numberOfDoors)
        :base(make, vehicleNumber, fuelType, fuelCapacity, cc)
    {
        this._audioSystem = audioSystem;
        this._numberOfDoors = numberOfDoors;
    }
    
     
    public new void DisplayMake() {
       Console.WriteLine(("***"+(Make + "***")));
    }
    
    public new void DisplayBasicInfo() {
        Console.WriteLine("---Basic Information---");
        Console.WriteLine(("Vehicle Number:" + VehicleNumber));
        Console.WriteLine(("Fuel Capacity:" + FuelCapacity));
        Console.WriteLine(("Fuel Type:" + FuelType));
        Console.WriteLine(("CC:" + cc));
    }
    
    public new void DisplayDetailInfo() {
        Console.WriteLine("---Detail Information---");
        Console.WriteLine(("Audio System:" + this._audioSystem));
        Console.WriteLine(("Number of Doors:" + this._numberOfDoors));
    }
    }

