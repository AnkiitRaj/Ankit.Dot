﻿using System;
public class Vehicle
{
    private string _make;

    public string Make
    {
        get { return _make; }
        set { _make = value; }
    }

    
    string _vehicleNumber;

    public string VehicleNumber
    {
        get { return _vehicleNumber; }
        set { _vehicleNumber = value; }
    }
    string _fuelType;

    public string FuelType
    {
        get { return _fuelType; }
        set { _fuelType = value; }
    }
    int _fuelCapacity;

    public int FuelCapacity
    {
        get { return _fuelCapacity; }
        set { _fuelCapacity = value; }
    }
    int _cc;

    public int cc
    {
        get { return _cc; }
        set { _cc = value; }
    }
    public Vehicle()
    {
        //  TODO Auto-generated constructor stub
    }

    public Vehicle(string make, string vehicleNumber, string fuelType, int fuelCapacity, int cc)
    {
        this._make = make;
        this._vehicleNumber = vehicleNumber;
        this._fuelType = fuelType;
        this._fuelCapacity = fuelCapacity;
        this._cc = cc;
    }

    public void DisplayMake() {
        System.Console.WriteLine(("***"+(this._make + "***")));
    }

    public void DisplayBasicInfo() {
        System.Console.WriteLine("---Basic Information---");
        System.Console.WriteLine(("Vehicle Number:" + this._vehicleNumber));
        System.Console.WriteLine(("Fuel Capacity:" + this._fuelCapacity));
        System.Console.WriteLine(("Fuel Type:" + this._fuelType));
        System.Console.WriteLine(("CC:" + this._cc));
    }

    public void DisplayDetailInfo()
    {

    }
}