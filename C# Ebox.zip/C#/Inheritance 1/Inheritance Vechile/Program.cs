using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{

		Console.WriteLine("1.Four Wheeler");
        Console.WriteLine("2.Two Wheeler");
        Console.WriteLine("Enter Vehicle Type:");
        string type = Console.ReadLine();
        if (type.Equals("1")) {
            Console.WriteLine("Vehicle Make:");
            string make = Console.ReadLine();
            Console.WriteLine("Vehicle Number:");
            String number = Console.ReadLine();
            Console.WriteLine("Fuel Type:");
            Console.WriteLine("1.Petrol");
            Console.WriteLine("2.Diesel");
            int ftype = int.Parse(Console.ReadLine());
            string fuelType = "";
            if ((ftype == 1)) {
                fuelType = "Petrol";
            }
            
            if ((ftype == 2)) {
                fuelType = "Diesel";
            }
            
            Console.WriteLine("Fuel Capacity:");
            int capacity = int.Parse(Console.ReadLine());
            Console.WriteLine("Engine CC:");
            int cc = int.Parse(Console.ReadLine());
            Console.WriteLine("Audio System:");
            string audio = Console.ReadLine();
            Console.WriteLine("Number of Doors:");
            int door = int.Parse(Console.ReadLine());
            FourWheeler v = new FourWheeler(make, number, fuelType, capacity, cc, audio, door);
            v.DisplayMake();
            v.DisplayBasicInfo();
            v.DisplayDetailInfo();
        }
        
        if (type.Equals("2")) {
            Console.WriteLine("Vehicle Make:");
            string make = Console.ReadLine();
            Console.WriteLine("Vehicle Number:");
            string number = Console.ReadLine();
            Console.WriteLine("Fuel Type:");
            Console.WriteLine("1.Petrol");
            Console.WriteLine("2.Diesel");
            int ftype = int.Parse(Console.ReadLine());
            string fuelType = "";
            if ((ftype == 1)) {
                fuelType = "Petrol";
            }
            
            if ((ftype == 2)) {
                fuelType = "Diesel";
            }
            
            Console.WriteLine("Fuel Capacity:");
            int capacity = int.Parse(Console.ReadLine());
            Console.WriteLine("Engine CC:");
            int cc = int.Parse(Console.ReadLine());
            Console.WriteLine("Kick Start Available(yes/no):");
            string kickStart = Console.ReadLine();
            bool a = false;
            if (kickStart.Equals("yes")) {
                a = true;
            }
            else {
                a = false;
            }
            
            TwoWheeler v = new TwoWheeler(make, number, fuelType, capacity, cc, a);
            v.DisplayMake();
            v.DisplayBasicInfo();
            v.DisplayDetailInfo();
        }
        Console.ReadKey();
}
	
}
			
