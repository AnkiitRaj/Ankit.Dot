﻿public class TwoWheeler : Vehicle {

    bool _kickStartAvailable;

    public bool KickStartAvailable
    {
        get { return _kickStartAvailable; }
        set { _kickStartAvailable = value; }
    }
    
    
    public TwoWheeler()
    {
        //  TODO Auto-generated constructor stub
    }
    
    public TwoWheeler(string make, string vehicleNumber, string fuelType, int fuelCapacity, int cc, bool kickStartAvailable) : 
            base(make, vehicleNumber, fuelType, fuelCapacity, cc) {
        //base.(make, vehicleNumber, fuelType, fuelCapacity, cc);
        this._kickStartAvailable = kickStartAvailable;
        //  TODO Auto-generated constructor stub
    }
    
    public new void DisplayDetailInfo() {
        System.Console.WriteLine("---Detail Information---");
        if ((this._kickStartAvailable == true)) {
            System.Console.WriteLine("Kick Start Available:YES");
        }
        else {
            System.Console.WriteLine("Kick Start Available:NO");
        }
        
    }
}