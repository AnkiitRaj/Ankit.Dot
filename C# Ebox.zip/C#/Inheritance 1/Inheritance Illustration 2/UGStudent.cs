using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class UGStudent:Student
{
	private string _degree;

public string Degree
{
  get { return _degree; }
  set { _degree = value; }
}
	private string _stream;

public string Stream
{
  get { return _stream; }
  set { _stream = value; }
}
    public UGStudent()
    {
    }
    public UGStudent(string a, string b, int c, double d, string e, string Degree, string Stream)
        : base(a, b, c, d, e)
    {
    this._degree=Degree;
    this._stream=Stream;
    }

  public new void Display()
  {
    base.Display();
     Console.WriteLine("Degree : "+_degree);
     Console.WriteLine("Stream : "+_stream);
  }
  public new bool IsPassed()
  {
    if(base.Grade>70)
      {
        return true;
      }
      else
      {
        return false;
      }
    
  }
}

	
