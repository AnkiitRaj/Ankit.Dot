using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class PGStudent:Student
{
    private string _specialization;

    public string Specialization
    {
        get { return _specialization; }
        set { _specialization = value; }
    }
    private int _noOfPapersPublished;

    public int NoOfPapersPublished
    {
        get { return _noOfPapersPublished; }
        set { _noOfPapersPublished = value; }
    }

    public PGStudent()
    {
    }
    public PGStudent(string a, string b, int c, double d, string e, string Specialization, int NoOfPapersPublished)
        : base(a, b, c, d, e)
    {
        this._specialization = Specialization;
        this._noOfPapersPublished = NoOfPapersPublished;
    }
    public new void Display()
   {
    base.Display();
     Console.WriteLine("Specialization : " + _specialization);
     Console.WriteLine("No. of papers published : "+_noOfPapersPublished);

   }
    public new bool IsPassed()
    {

        if (base.Grade > 70 && _noOfPapersPublished >= 2)
            return true;
        else
            return false;
    }
}
