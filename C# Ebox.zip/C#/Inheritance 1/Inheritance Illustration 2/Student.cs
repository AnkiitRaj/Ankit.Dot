using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Student
{
    private string _name;

    protected string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private string _id;

    protected string Id
    {
        get { return _id; }
        set { _id = value; }
    }
    private int _age;

    protected int Age
    {
        get { return _age; }
        set { _age = value; }
    }
    private double _grade;

    protected double Grade
    {
        get { return _grade; }
        set { _grade = value; }
    }
    private string _address;

    protected string Address
    {
        get { return _address; }
        set { _address = value; }
    }
    public Student()
    {
    }
    public Student(string name, string id, int age, double grade, string address)
    {
        this._name = name;
        this._id = id;
        this._age = age;
        this._grade = grade;
        this._address = address;
    }
    public void Display()
  {
    Console.WriteLine("Name : "+_name);
    Console.WriteLine("Id : " + _id);
    Console.WriteLine("Age : "+_age);
    Console.WriteLine("Grade : {0:0.0}",_grade);
    Console.WriteLine("Address : "+_address);
  }
    public bool IsPassed()
    {
        if (this._grade > 50)
            return true;
        else
           return false;
    }

}