﻿public class Rectangle : Shape
{
    private int _length;

    public int Length
    {
        get { return _length; }
        set { _length = value; }
    }
    private int _breadth;

    public int Breadth
    {
        get { return _breadth; }
        set { _breadth = value; }
    }

  public Rectangle(int Length,int Breadth)
  {
    _shapeName="Rectangle";
    this._length=Length;
    this._breadth=Breadth;
  }
   public new double CalculateArea()
   {
     return ((this._length) * (this._breadth));
   }
}