﻿public class Square : Shape

{
  private int _side;
  public Square(int side)

  {
    _shapeName = "Square";
    this._side=side;
  }
   public new double CalculateArea()
   {
     return this._side*this._side;
   }
}