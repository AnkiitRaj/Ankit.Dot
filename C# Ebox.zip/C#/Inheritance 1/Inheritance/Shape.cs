﻿public class Shape
{
    public Shape()
    { }
    protected string _shapeName;
    
    public Shape(string shapeName)
    {
       this._shapeName = shapeName;
    }
    public string getShapeName()
    {
        return _shapeName;
    }
    public double CalculateArea()
    { 
        return 0;
    }
}