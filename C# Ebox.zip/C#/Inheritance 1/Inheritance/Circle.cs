﻿using System;
public class Circle : Shape
{
  private int radius ;
  public Circle(int radius)
  {
    _shapeName="Circle";
    this.radius =radius;
  }
  public new double CalculateArea()
  {
      return Math.PI*radius*radius;
  }
}