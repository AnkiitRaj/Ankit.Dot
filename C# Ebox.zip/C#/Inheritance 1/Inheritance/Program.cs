using System;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("1. Rectangle");
        Console.WriteLine("2. Square");
        Console.WriteLine("3. Circle");
        Console.WriteLine("Area Calculator --- Choose your shape");
        string choice = Console.ReadLine();
        switch (choice)
        {
            case "1":
                Console.WriteLine("Enter length and breadth:");
                int length = int.Parse(Console.ReadLine());
                int breadth = int.Parse(Console.ReadLine());
                Rectangle s1 = new Rectangle(length, breadth);
                double area1 = s1.CalculateArea();
                Console.WriteLine("Area of {0} is:{1:0.00}",s1.getShapeName(),area1);
                break;
            case "2":
                Console.WriteLine("Enter side:");
                int side = int.Parse(Console.ReadLine());
                Square s2 = new Square(side);
                double area2 = s2.CalculateArea();
                Console.WriteLine("Area of " + s2.getShapeName() + " is:{0:0.00}",area2);
                break;
            case "3":
                Console.WriteLine("Enter Radius:");
                int radius = int.Parse(Console.ReadLine());
                Circle s3 = new Circle(radius);
                double area3 = s3.CalculateArea();
                Console.WriteLine("Area of " + s3.getShapeName() + " is:{0:0.00}",area3);
                break;
        }
        Console.ReadKey();
    }
 
}

