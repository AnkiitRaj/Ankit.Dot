﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class HotelRoom
{

    private string _hotelName;

    protected string HotelName
    {
        get { return _hotelName; }
        set { _hotelName = value; }
    }

    private int _numberOfSqFeet;

    protected int NumberOfSqFeet
    {
        get { return _numberOfSqFeet; }
        set { _numberOfSqFeet = value; }
    }

    private bool _hasTV;

    protected bool HasTV
    {
        get { return _hasTV; }
        set { _hasTV = value; }
    }

    private bool _hasWifi;

    protected bool HasWifi
    {
        get { return _hasWifi; }
        set { _hasWifi = value; }
    }

    public HotelRoom() 
    {
    }

    public HotelRoom(string hotelName, int numberOfSqFeet, bool hasTV, bool hasWifi)
    {
        this._hotelName = hotelName;
        this._numberOfSqFeet = numberOfSqFeet;
        this._hasTV = hasTV;
        this._hasWifi = hasWifi;
    }

  

    public int calculateTariff()
    {
        return 0;
    }

    public int getRatePerSqFeet()
    {
        return 0;
    }
}