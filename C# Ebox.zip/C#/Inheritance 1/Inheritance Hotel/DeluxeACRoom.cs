﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class DeluxeACRoom : DeluxeRoom
{

    public DeluxeACRoom(string hotelName, int numberOfSqFeet, bool hasTV, bool hasWifi) :
        base(hotelName, numberOfSqFeet, hasTV, hasWifi)
    {
        
        this._ratePerSqFeet = base.RatePerSqFeet;
    }
    public new int calculateTariff()
    {
        this._ratePerSqFeet = 12;
        if ((base.HasWifi == true))
        {
            return (base.NumberOfSqFeet
                        * (base.RatePerSqFeet + 2));
        }
        else
        {
            return (base.NumberOfSqFeet * base.RatePerSqFeet);
        }

    }
}