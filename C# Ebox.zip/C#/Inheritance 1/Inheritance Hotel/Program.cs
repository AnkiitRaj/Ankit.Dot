using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{

		Console.WriteLine("Hotel Tariff Calculator");
        Console.WriteLine("1. Deluxe Room");
        Console.WriteLine("2. Deluxe AC Room");
        Console.WriteLine("3. Suite AC Room");
        Console.WriteLine("Select Room Type:");
        string type = Console.ReadLine();
        if (type.Equals("1")) {
            Console.WriteLine("Hotel Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Room Square Feet Area:");
            int numberOfSqFeet = int.Parse(Console.ReadLine());
            Console.WriteLine("Room has TV (yes/no):");
            string TV = Console.ReadLine();
            bool hasTV = false;
            if (TV.Equals("yes")) {
                hasTV = true;
            }
            else {
                hasTV = false;
            }
            
            Console.WriteLine("Room has Wifi (yes/no):");
            string Wifi = Console.ReadLine();
            bool hasWifi = false;
            if (Wifi.Equals("yes")) {
                hasWifi = true;
            }
            else {
                hasWifi = false;
            }
            
          //  int ratePerSqFeet = 10;
            DeluxeRoom hr = new DeluxeRoom(name, numberOfSqFeet, hasTV, hasWifi);
            Console.WriteLine(("Room Tariff per day is:" + hr.calculateTariff()));
        }
        
        if (type.Equals("2")) {
            Console.WriteLine("Hotel Name:");
            String name = Console.ReadLine();
            Console.WriteLine("Room Square Feet Area:");
            int numberOfSqFeet = int.Parse(Console.ReadLine());
            Console.WriteLine("Room has TV (yes/no):");
            string TV = Console.ReadLine();
            bool hasTV = false;
            if (TV.Equals("yes")) {
                hasTV = true;
            }
            else {
                hasTV = false;
            }
            
            Console.WriteLine("Room has Wifi (yes/no):");
            string Wifi = Console.ReadLine();
            bool hasWifi = false;
            if (Wifi.Equals("yes")) {
                hasWifi = true;
            }
            else {
                hasWifi = false;
            }
            
           // int ratePerSqFeet = 12;
            DeluxeACRoom hr = new DeluxeACRoom(name, numberOfSqFeet, hasTV, hasWifi);
            Console.WriteLine(("Room Tariff per day is:" + hr.calculateTariff()));
        }
        
        if (type.Equals("3")) {
            Console.WriteLine("Hotel Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Room Square Feet Area:");
            int numberOfSqFeet = int.Parse(Console.ReadLine());
            Console.WriteLine("Room has TV (yes/no):");
            string TV = Console.ReadLine();
            bool hasTV = false;
            if (TV.Equals("yes")) {
                hasTV = true;
            }
            else {
                hasTV = false;
            }
            
            Console.WriteLine("Room has Wifi (yes/no):");
            String Wifi = Console.ReadLine();
            bool hasWifi = false;
            if (Wifi.Equals("yes")) {
                hasWifi = true;
            }
            else {
                hasWifi = false;
            }
            
            SuiteACRoom hr = new SuiteACRoom(name, numberOfSqFeet, hasTV, hasWifi);
            Console.WriteLine(("Room Tariff per day is:" + hr.calculateTariff()));
        }
        Console.ReadKey();
}
	
}
			
