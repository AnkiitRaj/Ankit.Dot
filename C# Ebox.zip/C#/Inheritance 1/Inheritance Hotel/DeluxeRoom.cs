﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class DeluxeRoom : HotelRoom {

    public int _ratePerSqFeet;

    protected int RatePerSqFeet
    {
        get { return _ratePerSqFeet; }
        set { _ratePerSqFeet = value; }
    }
    
    public DeluxeRoom(string hotelName, int  numberOfSqFeet, bool hasTV, bool hasWifi) : 
            base(hotelName, numberOfSqFeet, hasTV, hasWifi)
    {
        this._ratePerSqFeet = RatePerSqFeet;
    }
    
    public new int calculateTariff() {
        this._ratePerSqFeet = 10;
        if ((base.HasWifi == true)) {
            return (NumberOfSqFeet 
                        * (this._ratePerSqFeet + 2));
        }
        else {
            return (NumberOfSqFeet * this._ratePerSqFeet);
        }
        
    }
}
 
