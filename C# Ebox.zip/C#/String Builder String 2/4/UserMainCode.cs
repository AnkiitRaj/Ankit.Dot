﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static void display(string s,string c) {
        string s1 = s;
        char[] ch = c.ToCharArray();
        for (int i = 0; i < s1.Length; i++) 
        {
            if (s[i]==c[0])
                continue;
            else
                Console.Write(s1[i]);
        }
        
//            Console.WriteLine(s1);
        //string[] st = s.Split('!');
        //foreach (string sp in st)
        //{
        //    Console.Write(sp);
        //}
        //string[] ss = s.Split('#');
        //for (int i = ss.Length - 1; i >= 0; i--)
        //{
        //    if (i == 0)
        //    {
        //        Console.Write(ss[i]);
        //    }
        //    else
        //    {
        //        Console.Write(ss[i] + " ");
        //    }
        //}
   
    }
}