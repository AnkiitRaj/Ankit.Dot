using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        string s = Console.ReadLine();
        string c = Console.ReadLine();
        UserMainCode.display(s,c);
        Console.ReadKey();

    }
}


