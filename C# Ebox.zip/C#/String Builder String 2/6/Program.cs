using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        string s = Console.ReadLine();
        if (UserMainCode.ValidatePlayer(s)) {
            Console.WriteLine("Valid");
        }
        else {
            Console.WriteLine("Invalid");
        }
        Console.ReadKey();

    }
}


