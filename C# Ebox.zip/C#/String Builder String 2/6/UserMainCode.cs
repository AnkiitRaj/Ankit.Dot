﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static bool ValidatePlayer(string s)
    {
        bool f = true;
        string[] sp = s.Split(' ');
        if (sp.Length == 2)
        {
            if ((sp[0].Equals("RCB")
                        || (sp[0].Equals("MI")
                        || (sp[0].Equals("CSK")
                        || (sp[0].Equals("SRH")
                        || (sp[0].Equals("KXIP")
                        || (sp[0].Equals("DD")
                        || (sp[0].Equals("KKR")
                        || (sp[0].Equals("RPSG") || sp[0].Equals("GL"))))))))))
            {
                f = true;
            }
            else
            {
                f = false;
            }

            char[] ch = sp[1].ToCharArray();
            for (int i = 0; (i < ch.Length); i++)
            {
                if (Char.IsDigit(ch[i]))
                {
                    // TODO: Warning!!! continue If
                }
                else
                {
                    f = false;
                    break;
                }

            }

        }
        else
        {
            f = false;
        }

        return f;
    }
}