﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static bool ValidatePlayer(string s)
    {
        char[] ch = s.ToCharArray();
        int odd = 0;
        int even = 0;
        for (int i = 0; (i < ch.Length); i++)
        {
            if (((i % 2)
                        == 0))
            {
                if (((ch[i] == 'a')
                            || ((ch[i] == 'e')
                            || ((ch[i] == 'i')
                            || ((ch[i] == 'o')
                            || ((ch[i] == 'u')
                            || ((ch[i] == 'A')
                            || ((ch[i] == 'E')
                            || ((ch[i] == 'I')
                            || ((ch[i] == 'O')
                            || (ch[i] == 'U')))))))))))
                {
                    even++;
                }

            }
            else if (((ch[i] == 'a')
                        || ((ch[i] == 'e')
                        || ((ch[i] == 'i')
                        || ((ch[i] == 'o')
                        || ((ch[i] == 'u')
                        || ((ch[i] == 'A')
                        || ((ch[i] == 'E')
                        || ((ch[i] == 'I')
                        || ((ch[i] == 'O')
                        || (ch[i] == 'U')))))))))))
            {
                odd++;
            }

        }

        if ((even > odd))
        {
            return false;
        }

        return true;
    }
}