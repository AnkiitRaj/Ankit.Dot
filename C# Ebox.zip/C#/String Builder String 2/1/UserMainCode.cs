﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static void display(string s) {
        string[] st = s.Split(' ');
        foreach (string sp in st)
        {
            Console.WriteLine(sp);
        }
        string[] ss = s.Split(' ');
        for (int i = ss.Length - 1; i >= 0; i--)
        {
            if (i == 0)
            {
                Console.Write(ss[i]);
            }
            else
            {
                Console.Write(ss[i] + " ");
            }
        }
   
    }
}