﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static bool ValidatePlayer(string s,string s1)
    {
        char[] ch = s.ToCharArray();
        char[] ch1 = new char[ch.Length];
        for (int i = 0; (i < ch.Length); i++) {
            ch1[i] = ((char)((ch[i] + 1)));
        }
        
        char[] ss = s1.ToCharArray();
        for (int i = 0; (i < ss.Length); i++) {
            if ((ss[i] == ch1[i])) {
                // TODO: Warning!!! continue If
            }
            else {
                return false;
            }
            
        }
        
        return true;
    }
}
