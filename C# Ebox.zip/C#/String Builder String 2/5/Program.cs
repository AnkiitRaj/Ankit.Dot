using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        string s = Console.ReadLine();
        string[] c = s.Split(' ');
        if (UserMainCode.ValidatePlayer(c[0], c[1]))
        {
            Console.WriteLine("Valid");
        }
        else {
            Console.WriteLine("Invalid");
        }
        Console.ReadKey();
    }
}


