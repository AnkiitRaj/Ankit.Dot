﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

     public static bool ValidatePlayer(string string1, string string2)
     {
        bool f = true;
        string[] s1 = string1.Split(' ');
        char[] ch = string1.ToCharArray();
        int res = 0;
        int count = 0;
        res = (ch.Length / 2);
        for (int i = 0; (i < ch.Length); i++) {
            if (((i % 2) 
                        != 0)) {
                if ((ch[i] == '*')) {
                    count++;
                }
                
            }
            
        }
        
        if ((count == res)) {
            f = true;
        }
        else {
            f = false;
        }
        
        count = 0;
        char[] ch1 = string2.ToCharArray();
        for (int i = 0; (i < ch1.Length); i++) {
            if (((i % 2) 
                        != 0)) {
                if ((ch1[i] == '#')) {
                    count++;
                }
                
            }
            
        }
        
        res = 0;
        res = (ch1.Length / 2);
        if ((count == res)) {
            f = true;
        }
        else {
            f = false;
        }
        
        return f;
    }
}