﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static void display(string s) {
        string s1 = s;
        for (int i = 0; i < s1.Length; i++) 
        {
            if (s1[i] == '!' || s[i] == '#') 
            {
                continue;
            }
            else
                Console.Write(s[i]);
        }
        Console.ReadKey();
        //string[] st = s.Split('!');
        //foreach (string sp in st)
        //{
        //    Console.Write(sp);
        //}
        //string[] ss = s.Split('#');
        //for (int i = ss.Length - 1; i >= 0; i--)
        //{
        //    if (i == 0)
        //    {
        //        Console.Write(ss[i]);
        //    }
        //    else
        //    {
        //        Console.Write(ss[i] + " ");
        //    }
        //}
   
    }
}