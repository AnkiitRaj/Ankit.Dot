﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static void display(string s, string s1) {
        string[] a1 = s.Split(' ');
        string[] a2 = s1.Split(' ');
        if (a1[1].Equals(a2[1])) {
            Console.WriteLine("Yes");
        }
        else {
            Console.WriteLine("No");
        }
    }
}