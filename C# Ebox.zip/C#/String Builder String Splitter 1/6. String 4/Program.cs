using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the team names");
        string s = Console.ReadLine();
        UserMainCode.display(s);
        Console.ReadKey();
    }
}


