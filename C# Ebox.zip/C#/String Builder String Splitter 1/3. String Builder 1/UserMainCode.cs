﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static void display(string s, string s1) {
        s1 = s1.ToUpper();
        s = s.ToLower();
        char c = s[0];
        char cc = '0';
        if (c > 96) {
            cc = ((char)((c - 32)));
        }
        
        s = s.Replace(c, cc);
        char[] ch = s.ToCharArray();
        for (int i = 0; (i < ch.Length); i++) {
            if (i == 0)
            {

            }
            else {
                char xx = ch[i];
                if ((xx < 96)) {
                    ch[i] = ((char)((ch[i] + 32)));
                }
                
            }
            
        }
        
        for (int i = 0; (i < ch.Length); i++) {
            Console.Write(ch[i]);
        }
        
        Console.WriteLine(" " + s1);
    }
}