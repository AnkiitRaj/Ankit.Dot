using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the venue name");
        String s = Console.ReadLine();
        UserMainCode.display(s);
        Console.ReadKey();
    }
}


