﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static void display(string s)
    {
        //  TODO Auto-generated method stub
        Console.WriteLine("Modified Venue");
        string ns = s.Replace("Stadium", "Ground");
        Console.WriteLine(ns);
    }
}