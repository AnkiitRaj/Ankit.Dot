using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the player name");
        String s = Console.ReadLine();
        Console.WriteLine("Enter the team name");
        String s1 = Console.ReadLine();
        UserMainCode.display(s, s1);
        Console.ReadKey();
    }
}


