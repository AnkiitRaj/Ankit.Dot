﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class UserMainCode
{

    public static void display(string s) {
//        StringTokenizer st = new StringTokenizer(s, ",");
        string[] st = s.Split(' ');
        foreach (string sp in st)
        {
            Console.WriteLine(sp);
        }
        
        
    }
}