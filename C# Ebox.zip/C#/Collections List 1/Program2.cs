﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        List<int> n1 = new List<int>();
        for (int i = 0; i < n; i++)
        {
            n1.Add(int.Parse(Console.ReadLine()));
        }
        n1.Sort();
        
        foreach (int s in n1)
        {
            Console.WriteLine(s);
        }
        
    }
}