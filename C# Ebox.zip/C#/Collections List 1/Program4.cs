﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Program
    {
      public static void Main(string[] args) 
      {
          Console.WriteLine("Enter the team name");
          string name = Console.ReadLine();
          Console.WriteLine("Enter the number of matches played in home ground");
          int hn = int.Parse(Console.ReadLine());
          List<int> myList = new List<int>();
          Console.WriteLine("Enter the runs scored");
          for (int i = 0; i < hn; i++)
              myList.Add(int.Parse(Console.ReadLine()));
          Console.WriteLine("Enter the number of matches played in other ground");
          int on = int.Parse(Console.ReadLine());
          Console.WriteLine("Enter the runs scored");
          for (int i = hn; i < on + hn; i++)
              myList.Add(int.Parse(Console.ReadLine()));
          Console.WriteLine("Runs scored by {0}", name);
          foreach (int i in myList)
              Console.WriteLine(i);
          Console.WriteLine("Run scored by {0} more than 300", name);
          foreach (int i in myList)
              if (i > 300)
                  Console.WriteLine(i);
              Console.ReadKey();
      }

    }

