﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Program
    {
      public static void Main(string[] args) 
      {
          int n = int.Parse(Console.ReadLine());
          List<string> myList = new List<string>();
          for (int i = 0; i < n; i++)
              myList.Add(Console.ReadLine());

          //List<string> ls = myList.Distinct().ToList();
          int c = 0;
          string p = Console.ReadLine();
          //foreach (string s in ls)
          for (int i = 0; i < n; i++)
          {
              if (myList[i].Equals(p))
              {
                  c++;
              }
          }
          Console.WriteLine(c);
          
          // 4 Console.WriteLine("Enter the team name");
          //string name = Console.ReadLine();
          //Console.WriteLine("Enter the number of matches played in home ground");
          //int hn = int.Parse(Console.ReadLine());
          //List<int> myList = new List<int>();
          //Console.WriteLine("Enter the runs scored");
          //for(int i=0;i<hn;i++)
          //    myList.Add(int.Parse(Console.ReadLine()));
          //Console.WriteLine("Enter the number of matches played in other ground");
          //int on = int.Parse(Console.ReadLine());
          //Console.WriteLine("Enter the runs scored");
          //for (int i = hn; i < on+hn; i++)
          //    myList.Add(int.Parse(Console.ReadLine()));
          //Console.WriteLine("Runs scored by {0}",name);
          //foreach(int i in myList)
          //    Console.WriteLine(i);
          //Console.WriteLine("Run scored by {0} more than 300",name);
          //foreach(int i in myList)
          //    if(i>300)
          //        Console.WriteLine(i);
          
          // 5 Console.WriteLine("Enter the top 5 scorers of IPL Season 8");
          //List<string> myList = new List<string>();
          //for (int i = 0; i < 5; i++)
          //    myList.Add(Console.ReadLine());
          //Console.WriteLine("Enter the top 5 scorers of IPL Season 9");
          //List<string> myList1 = new List<string>();
          //for (int i = 0; i < 5; i++)
          //    myList1.Add(Console.ReadLine());
          //List<string> myls = new List<string>();
          //foreach (string s in myList) 
          //{
          //    if(myList1.Contains(s))
          //        myls.Add(s);
          //}
          //Console.WriteLine("Consistent run scorers");
          //foreach(string s in myls)
          //    Console.WriteLine(s);
          
          // 6 Console.WriteLine("Enter the teams in ranking table");
          //List<string> mylist = new List<string>();
          //for (int i = 0; i < 5; i++)
          //    mylist.Add(Console.ReadLine());
          //Console.WriteLine("Enter the rank to be searched");
          //int n = int.Parse(Console.ReadLine());
          ////for (int i = 0; i < 5; i++)
          //    Console.WriteLine(mylist.ElementAt(n-1));
          //List<string> myList = new List<string>();
          //for (int i = 0; i < 5; i++)
          //    myList.Add(Console.ReadLine());
          //Console.WriteLine("Enter swap positons");
          //int n = int.Parse(Console.ReadLine());
          //string s = myList.ElementAt(n - 1);
          //myList.RemoveAt(n-1);
          
          // 8 Console.WriteLine("Enter the player details");
          //Console.WriteLine("Enter player name");
          //List<string> myList = new List<string>();
          //string name = Console.ReadLine();
          //Console.WriteLine("Enter age");
          //string age = Console.ReadLine();
          //Console.WriteLine("Enter Country");
          //string country = Console.ReadLine();
          //Console.WriteLine("Player Details");
          //Console.WriteLine(name+"\n"+age+"\n"+country);
          //Console.WriteLine("Enter Skill");
          //string skill = Console.ReadLine();
          //Console.WriteLine("Enter the position to add the skill");
          //int p = int.Parse(Console.ReadLine());
          //Console.WriteLine("Player Details");
          //myList.Add(name);
          //myList.Add(age);
          //myList.Add(country);
          //List<string> myls = new List<string>();
          //if (p < myList.Count)
          //{
          //    for (int i = 0; i < myList.Count; i++)
          //    {
          //        if (p == i)
          //        {
          //            myls.Add(skill);
          //            myls.Add(myList[i]);
          //        }
          //        else
          //            myls.Add(myList[i]);
          //    }
          //}
          //else 
          //{
          //    myls = myList.ToList();
          //    myls.Add(skill);
          //}
              

          //    foreach (string s in myls)
          //        Console.WriteLine(s);
          //Console.WriteLine("Enter the position of the detail to be removed");
          //int ps = int.Parse(Console.ReadLine());
          //Console.WriteLine("Player Details");
          //myls.RemoveAt(ps);
          //foreach (string s in myls)
          //    Console.WriteLine(s);
          // 7 List<string> myList = new List<string>();
          //for (int i = 0; i < 5;i++)
          //    myList.Add(Console.ReadLine());
          //Console.WriteLine("Enter swap positons");
          //int n = int.Parse(Console.ReadLine());
          //int n1 = int.Parse(Console.ReadLine());
          //string s = myList[n];
          //string s1 = myList[n1];
          //myList[n] = s1;
          //myList[n1] = s;
          //foreach(string ch in myList)
          //    Console.WriteLine(ch);
              Console.ReadKey();
      }

    }

