﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Program
    {
      public static void Main(string[] args) 
      {             
          // 8 Console.WriteLine("Enter the player details");
          //Console.WriteLine("Enter player name");
          //List<string> myList = new List<string>();
          //string name = Console.ReadLine();
          //Console.WriteLine("Enter age");
          //string age = Console.ReadLine();
          //Console.WriteLine("Enter Country");
          //string country = Console.ReadLine();
          //Console.WriteLine("Player Details");
          //Console.WriteLine(name+"\n"+age+"\n"+country);
          //Console.WriteLine("Enter Skill");
          //string skill = Console.ReadLine();
          //Console.WriteLine("Enter the position to add the skill");
          //int p = int.Parse(Console.ReadLine());
          //Console.WriteLine("Player Details");
          //myList.Add(name);
          //myList.Add(age);
          //myList.Add(country);
          //List<string> myls = new List<string>();
          //if (p < myList.Count)
          //{
          //    for (int i = 0; i < myList.Count; i++)
          //    {
          //        if (p == i)
          //        {
          //            myls.Add(skill);
          //            myls.Add(myList[i]);
          //        }
          //        else
          //            myls.Add(myList[i]);
          //    }
          //}
          //else 
          //{
          //    myls = myList.ToList();
          //    myls.Add(skill);
          //}
              

          //    foreach (string s in myls)
          //        Console.WriteLine(s);
          //Console.WriteLine("Enter the position of the detail to be removed");
          //int ps = int.Parse(Console.ReadLine());
          //Console.WriteLine("Player Details");
          //myls.RemoveAt(ps);
          //foreach (string s in myls)
          //    Console.WriteLine(s);

          List<string> myList = new List<string>();
          for (int i = 0; i < 5;i++)
              myList.Add(Console.ReadLine());
          Console.WriteLine("Enter swap positons");
          int n = int.Parse(Console.ReadLine());
          int n1 = int.Parse(Console.ReadLine());
          string s = myList[n];
          string s1 = myList[n1];
          myList[n] = s1;
          myList[n1] = s;
          foreach(string ch in myList)
              Console.WriteLine(ch);
              Console.ReadKey();
      }

    }

