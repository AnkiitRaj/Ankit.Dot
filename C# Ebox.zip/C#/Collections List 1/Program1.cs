﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Program
    {
      public static void Main(string[] args) 
      {
          int n = int.Parse(Console.ReadLine());
          List<int> myList = new List<int>();
          for (int i = 0; i < n; i++) 
             myList.Add(int.Parse(Console.ReadLine()));
          long sum=0;
          foreach (int i in myList) 
              sum+= i;
          float avg = (float)sum / n;
          Console.WriteLine(sum);
          Console.WriteLine("{0:0.0}",avg);
          Console.ReadKey();
      }

    }

