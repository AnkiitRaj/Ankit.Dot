﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

class CalculateScores
{
    private string _matchType;

    public string MatchType
    {
        get { return _matchType; }
        set { _matchType = value; }
    }
    private string _scoreString;

    public string ScoreString
    {
        get { return _scoreString; }
        set { _scoreString = value; }
    }
    private int[] _scores;

    public int[] Scores
    {
        get { return _scores; }
        set { _scores = value; }
    }
    private double _meanScore;

    public double MeanScore
    {
        get { return _meanScore; }
        set { _meanScore = value; }
    }
    private int _minScore;

    public int MinScore
    {
        get { return _minScore; }
        set { _minScore = value; }
    }
    private int _maxScore;

    public int MaxScore
    {
        get { return _maxScore; }
        set { _maxScore = value; }
    }
    public CalculateScores(string MatType, string splitbleArr)
    {
        this._matchType = MatType;
        string[] s = splitbleArr.Split(',');
        Scores = Array.ConvertAll(s, X => int.Parse(X));
        Array.Sort(Scores);
        this.MeanScore = (double)Scores.Sum() / Scores.Length;
        this.MaxScore = Scores[Scores.Length - 1];
        this.MinScore = Scores[0];
    }
    public void RunThread()
    {
        Console.WriteLine(@"Match : {0}
Mean : {1:#0.00}
Min Mark : {2}
Max Mark : {3}", this.MatchType, this.MeanScore, this.MinScore, this.MaxScore);
    }
}