﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the match :");
        string name = Console.ReadLine();
        Console.WriteLine("Enter the scores :");
        string arr = Console.ReadLine();
        CalculateScores s1 = new CalculateScores(name, arr);
        Console.WriteLine("Enter the match :");
        string name2 = Console.ReadLine();
        Console.WriteLine("Enter the scores :");
        string arr2 = Console.ReadLine();
        CalculateScores s2 = new CalculateScores(name2, arr2);
        Console.WriteLine("Enter the match :");
        string name3 = Console.ReadLine();
        Console.WriteLine("Enter the scores :");
        string arr3 = Console.ReadLine();
        CalculateScores s3 = new CalculateScores(name3, arr3);
        Console.WriteLine("Score Summary");
        Thread t1 = new Thread(s1.RunThread);
        Thread t2 = new Thread(s2.RunThread);
        Thread t3 = new Thread(s3.RunThread);
        t1.Start(); t1.Join();
        t2.Start(); t2.Join();
        t3.Start(); t3.Join();
        Console.ReadLine();
    }
}