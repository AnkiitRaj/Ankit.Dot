﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of lines in the summary");
        int n = int.Parse(Console.ReadLine());
        string[] Lines = new string[n];
        for (int i = 0; i < n; i++)
            Lines[i] = Console.ReadLine();
        Thread[] t = new Thread[n];
        for (int i = 0; i < n; i++)
        {
            TitleCaseThread T = new TitleCaseThread(Lines[i]);
            t[i] = new Thread(T.RunThread);
            t[i].Start(); t[i].Join();
        }

        Console.ReadLine();
    }
}
