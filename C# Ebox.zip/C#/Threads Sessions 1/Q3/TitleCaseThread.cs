﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class TitleCaseThread
{
    public static int k = 1;
    private string summary;

    public string Summary
    {
        get { return summary; }
        set { summary = value; }
    }
    public TitleCaseThread(string str)
    {
        this.summary = str;
    }
    public void RunThread()
    {
        if (this.Summary.Contains("III"))
            this.Summary = this.Summary.Replace("III", "iii");
        Console.WriteLine("Sentence {0} : {1}", k++,
            string.Join(" ", Array.ConvertAll(this.summary.Split(' '), X => char.ToUpper(X[0]).ToString() + X.Substring(1))));
    }
}


