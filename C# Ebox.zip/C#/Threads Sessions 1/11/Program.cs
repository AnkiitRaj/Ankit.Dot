﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Match :");
            string match1 = Console.ReadLine();
            Console.WriteLine("Enter the Scores :");
            string score1 = Console.ReadLine();
            SortScores s1 = new SortScores(match1, score1);
            Console.WriteLine("Enter the Match :");
            string match2 = Console.ReadLine();
            Console.WriteLine("Enter the Scores :");
            string score2 = Console.ReadLine();
            SortScores s2 = new SortScores(match2, score2);
            Console.WriteLine("Enter the Match :");
            string match3 = Console.ReadLine();
            Console.WriteLine("Enter the Scores :");
            string score3 = Console.ReadLine();
            SortScores s3 = new SortScores(match3, score3);
            
            
            
            Console.WriteLine("Ordered Score List");
            Thread th1 = new Thread(s1.GetScores);
            Thread th2 = new Thread(s2.GetScores);
            Thread th3 = new Thread(s3.GetScores);


            th1.Start();
            th1.Join();
            th2.Start();
            th2.Join();
            th3.Start();
            th3.Join();

            Console.ReadLine();
        }

    }

