﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class SortScores
    {

        string _matchType; string _scoreString; int[] _scores = null;
       
        public SortScores(string _matchType,string _scoreString)
        {
            this._matchType = _matchType;
            this._scoreString = _scoreString;
            string[] s = _scoreString.Split(',');
            _scores =new int[s.Length];
            for (int i = 0; i < s.Length; i++)
            {
                _scores[i] = int.Parse(s[i]);
            }

        }

        public void GetScores() 
        {
            Array.Sort(_scores);
            Console.WriteLine("Match : {0}",_matchType);
            for (int i = 0; i < _scores.Length; i++)
            {
                Console.WriteLine(_scores[i]);
            }

        
        }




    }

