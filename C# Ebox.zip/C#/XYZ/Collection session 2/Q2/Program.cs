﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            List<int> list = new List<int>();
            for (int i = 0; i < n; i++)
            {
                list.Add(Convert.ToInt32(Console.ReadLine()));
            }
            int sum = 0;
            for (int i = 1; i <=n; i++)
            {
                if(i%2==0)
                sum = sum + list[i-1];
            }

            Console.WriteLine(sum);



        }
    }

