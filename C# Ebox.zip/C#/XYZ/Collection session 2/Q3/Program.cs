﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            List<int> list = new List<int>();
            for (int i = 0; i < n; i++)
            {
                list.Add(Convert.ToInt32(Console.ReadLine()));
            }
            int ctr1=0,ctr2=0;
            for (int i = 0; i < n; i++)
            {
                if (list[i] >= 100)
                    ctr1++;
                if (list[i] >= 50 && list[i] < 100)
                    ctr2++;
            }

            Console.WriteLine(ctr2);
            Console.WriteLine(ctr1);


        }
    }

