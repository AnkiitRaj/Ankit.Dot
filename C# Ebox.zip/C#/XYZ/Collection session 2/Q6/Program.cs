﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        int sum = 0;
        int n = int.Parse(Console.ReadLine());
        List<string> list = new List<string>();
        for (int i = 0; i < n; i++)
        {
            list.Add(Console.ReadLine());

            if (list[i].Contains("7"))
            {

                for (int j = 0; j < list[i].IndexOf("7"); j++)
                {
                    string a = Convert.ToString(list[i][j]);

                    sum = sum + Convert.ToInt32(a);

                }

            }

            else
            {
                for (int j = 0; j < list[i].Length; j++)
                {
                    string a = Convert.ToString(list[i][j]);

                    sum = sum + Convert.ToInt32(a);

                }

            }
        }

        Console.WriteLine(sum);
        Console.ReadLine();
    }
}
