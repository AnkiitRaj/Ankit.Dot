﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            List<string> list = new List<string>();
            for (int i = 0; i <n; i++)
            {
                list.Add(Console.ReadLine());
            }

            bool flag = true;

            while (flag == true)
            {

                Console.WriteLine(@"Menu
1.Insert Players
2.Delete Players");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                { 
                    case 1:
                        list.Add(Console.ReadLine());
                        Console.WriteLine("Player details after insertion");
                        foreach (string item in list)
                        {
                            Console.WriteLine(item);
                        }

                     break;
                    case 2:
                     list.Remove(Console.ReadLine());
                     Console.WriteLine("Player details after deletion");
                     foreach (string item in list)
                     {
                         Console.WriteLine(item);
                     }
                     break;
                 
                }
                Console.WriteLine("Do you want to continue");
                string str = Console.ReadLine();
                if (str.Equals("No"))
                    flag = false;


            }


        }
    }

