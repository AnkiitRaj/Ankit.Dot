﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            List<string> list = new List<string>();
            for (int i = 0; i < n; i++)
            {
                list.Add(Console.ReadLine());
            }
            int ctr = 0;
            for (int i = 0; i < n; i++)
            {
                if (list[i].Split('-')[1].Equals("0") && list[i].Split('-')[2].Equals("0"))
                {
                    Console.WriteLine(list[i].Split('-')[0]);

                }
                else 
                {
                    ctr++;
                }
                
            }
            if(ctr==n)
                Console.WriteLine("No player has scored a duck ");
        }
    }

