﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
          public static bool Prime(int num)
            {
                bool flag = true;
                int ctr=0;
                
                for (int i = 1; i <= num; i++)
                {
                    if (num % i == 0)
                    {
                        ctr++;
                    }
                }
                if (ctr == 2)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
                
              return flag;
            }
        


        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of matches");
            int n = Convert.ToInt32(Console.ReadLine());
            int ctr = 0;
            List<int> list = new List<int>();
            Console.WriteLine("Enter the runs scored by the team");
            for (int i = 0; i < n; i++)
            {
                list.Add(Convert.ToInt32(Console.ReadLine()));
                if (Prime(list[i])) 
                {
                    ctr++;
                }
            }

            Console.WriteLine("Number of prime scores : " + ctr);


        }
    }

