﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        int iu = 0;
        List<TopScorer> list = new List<TopScorer>();
        Console.WriteLine("Enter the number of players");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Enter player name");
            string PlName = Console.ReadLine();
            //Console.WriteLine("Enter team name");
            //string TName = Console.ReadLine();
            Console.WriteLine("Enter number of runs");
            long rns = long.Parse(Console.ReadLine());
            list.Add(new TopScorer(PlName, rns));
        }
        var v = (list.OrderByDescending(o => o.Runs)).Take(1);
        foreach (var x in v)
            Console.WriteLine("Top scorer of the match : {0} {1}", x.PlayerName, x.Runs);
        Console.ReadLine();
    }
}

class TopScorer
{
    private string _playerName;

    public string PlayerName
    {
        get { return _playerName; }
        set { _playerName = value; }
    }
    //private string _teamName;

    //public string TeamName
    //{
    //    get { return _teamName; }
    //    set { _teamName = value; }
    //}
    private long _runs;

    public long Runs
    {
        get { return _runs; }
        set { _runs = value; }
    }
    public TopScorer() { }
    public TopScorer(string PlName, long runs)
    {
        this.PlayerName = PlName; this.Runs = runs;
    }

}