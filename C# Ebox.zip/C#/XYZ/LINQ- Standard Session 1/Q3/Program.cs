﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            List<Player> list = new List<Player>();
            Console.WriteLine("Enter the number of players");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter player name");
                string PlName = Console.ReadLine();

                Console.WriteLine("Enter number of runs");
                long rns = long.Parse(Console.ReadLine());
                list.Add(new Player(PlName, rns));
            }

            var avg = list.Select(x => x.Runs).Average();
            var count = list.Count(x => x.Runs > avg);

            Console.WriteLine("Average Score : {0:0.00} ", avg);

            Console.WriteLine("Pass Count : {0}", count);

        }
    }

    class Player 
    {
      private string _playerName;

    public string PlayerName
    {
        get { return _playerName; }
        set { _playerName = value; }
    }
   
    private long _runs;

    public long Runs
    {
        get { return _runs; }
        set { _runs = value; }
    }
    public Player() { }
    public Player(string PlName, long runs)
    {
        this.PlayerName = PlName; this.Runs = runs;
    }


    
    
    }