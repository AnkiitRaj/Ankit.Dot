﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Player
    {
        private string _playerName;

    public string PlayerName
    {
        get { return _playerName; }
        set { _playerName = value; }
    }
   
    private long _score;

    public long Score
    {
        get { return _score; }
        set { _score = value; }
    }
    public Player() { }
    public Player(string PlName,  long score)
    {
        this.PlayerName = PlName;
      
        this.Score = score;
    }
    }



    class Program
    {
        static void Main(string[] args)
        {

            List<Player> list = new List<Player>();
            Console.WriteLine("Enter the number of players");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter player name");
                string PlName = Console.ReadLine();

                Console.WriteLine("Enter number of runs");
                long rns = long.Parse(Console.ReadLine());
                list.Add(new Player(PlName, rns));
            }
            var v1 = list.Max(y => y.Score);
            var v2 = list.Min(X => X.Score);
            Console.WriteLine(@"Maximum score : {0}
Minimum score : {1}",v1,v2);

            Console.ReadLine();
        }
    }
    