﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>();
            Console.WriteLine("Enter the teams in ranking table");
            for (int i = 0; i < 5; i++)
            {
                list.Add(Console.ReadLine());
            }

            Console.WriteLine("Enter the rank to be searched");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(list[n-1]);


        }

    }

