﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            List<string> list1 = new List<string>();
            List<string> list2 = new List<string>();
            List<string> list3 = new List<string>();
            Console.WriteLine("Enter the top 5 scorers of IPL Season 8");
            for (int i = 0; i < 5; i++)
            {
                list1.Add(Console.ReadLine() );
            }
            Console.WriteLine("Enter the top 5 scorers of IPL Season 9");
            for (int i = 0; i < 5; i++)
            {
                list2.Add(Console.ReadLine());
            }

            Console.WriteLine("Consistent run scorers");
            list3 = list1.Intersect(list2).ToList();

            foreach (string item in list3)
            {

                Console.WriteLine(item);

            }


        }
    }

