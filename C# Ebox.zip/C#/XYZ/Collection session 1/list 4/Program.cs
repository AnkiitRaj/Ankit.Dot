﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the team name");
            string str = Console.ReadLine();
            Console.WriteLine("Enter the number of matches played in home ground");
            int n1 = Convert.ToInt32(Console.ReadLine());
            List<int> list = new List<int>();
            Console.WriteLine("Enter the runs scored");
            for (int i = 0; i < n1; i++)
            {
                list.Add(Convert.ToInt32(Console.ReadLine()));
            }
            Console.WriteLine("Enter the number of matches played in other ground");
            int n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the runs scored");
            for (int i = 0; i < n2; i++)
            {
                list.Add(Convert.ToInt32(Console.ReadLine()));
            }

            Console.WriteLine("Runs scored by {0}",str);
            foreach (int item in list)
            {
                
                    Console.WriteLine(item);
                
            }
            Console.WriteLine("Run scored by {0} more than 300",str);
            foreach (int item in list)
            {
                if (item > 300)
                {
                    Console.WriteLine(item);
                }
            }


        }
    }

