﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        int iu=0;
        List<TopScorer> list = new List<TopScorer>();
        Console.WriteLine("Enter number of top scorers");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Enter player name");
            string PlName = Console.ReadLine();
            Console.WriteLine("Enter team name");
            string TName = Console.ReadLine();
            Console.WriteLine("Enter number of runs");
            long rns = long.Parse(Console.ReadLine());
            list.Add(new TopScorer(PlName, TName, rns));
        }
        var v = list.GroupBy(X => X.TeamName);
        foreach (var item in v)
        {

            foreach (var item1 in item)
            {
                if(iu==0)
                {
                Console.WriteLine("{ Team = " + item1.TeamName + " }");
                    iu=1;
                }
                Console.WriteLine(item1.PlayerName + " " + item1.Score);
            }
            iu = 0;
        }
        Console.ReadLine();
    }
}


class TopScorer
{
    private string _playerName;

    public string PlayerName
    {
        get { return _playerName; }
        set { _playerName = value; }
    }
    private string _teamName;

    public string TeamName
    {
        get { return _teamName; }
        set { _teamName = value; }
    }
    private long _score;

    public long Score
    {
        get { return _score; }
        set { _score = value; }
    }
    public TopScorer() { }
    public TopScorer(string PlName, string TmName, long score)
    {
        this.PlayerName = PlName; this.TeamName = TmName; this.Score = score;
    }

}