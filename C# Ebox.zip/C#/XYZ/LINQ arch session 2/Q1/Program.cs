﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Ranking
    {
        private string _playerName;

        public string PlayerName
        {
            get { return _playerName; }
            set { _playerName = value; }
        }
        private long _runs;

        public long Runs
        {
            get { return _runs; }
            set { _runs = value; }
        }
        public Ranking() { }
        public Ranking(string PlaName,long Rns)
        {
            this.PlayerName = PlaName; this.Runs = Rns;
        }
        public override string ToString()
        {
            return this.PlayerName+" "+this.Runs;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Ranking> List = new List<Ranking>();
            Console.WriteLine("Enter the number of players");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter player name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter number of runs");
                long rns = long.Parse(Console.ReadLine());
                List.Add(new Ranking(name,rns));
            }

    
            Console.WriteLine(string.Join("\n",List.OrderByDescending(x=>x.Runs)));
            Console.ReadLine();
        }
    }
