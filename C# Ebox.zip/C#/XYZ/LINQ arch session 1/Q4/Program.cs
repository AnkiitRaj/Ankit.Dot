﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Player:IComparer<Player>
    {
        private string _playerName;

        public string PlayerName
        {
            get { return _playerName; }
            set { _playerName = value; }
        }
        private long _capNumber;

        public long CapNumber
        {
            get { return _capNumber; }
            set { _capNumber = value; }
        }
        private string _skill;

        public string Skill
        {
            get { return _skill; }
            set { _skill = value; }
        }
        public Player() { }
        public Player(string plName,long CpNo,string skill)
        {
            this.CapNumber = CpNo; this.PlayerName = plName; this.Skill = skill;
        }
        public override string ToString()
        {
            return String.Format(@"{0} {1} {2}", this.CapNumber, this.PlayerName, this.Skill);
        }
        public int Compare(Player p1, Player p2)
        {
            return int.Parse(p1.Equals(p2).ToString());
        }
        public override bool Equals(object obj)
        {
            Player p = (Player)obj;
            return this.GetHashCode()==p.GetHashCode();
        }
        public override int GetHashCode()
        {
            return this.CapNumber.GetHashCode();
        }
    }



   class Program
    {
        static void Main(string[] args)
        {
            List<Player> List = new List<Player>();
            Console.WriteLine("Enter the number of records");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter cap number");
                long cpno = long.Parse(Console.ReadLine());
                Console.WriteLine("Enter player name");
                string plName = Console.ReadLine();
                Console.WriteLine("Enter skill");
                string skill = Console.ReadLine();
                List.Add(new Player(plName,cpno,skill));
            }
            
            Console.WriteLine(string.Join("\n",List.Distinct()));
            
            Console.ReadLine();
        }
    }
