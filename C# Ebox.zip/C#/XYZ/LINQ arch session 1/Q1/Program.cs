﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Player
{
    public string PlayerName { get; set; }
    public Player()
    { }

    public Player(string pname)
    {
        PlayerName = pname;
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<Player> list = new List<Player>();
        Console.WriteLine("Enter number of players");
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the player names");
        for (int i = 0; i < n; i++)
        {
            string name = Console.ReadLine();
            Player p = new Player(name);
            list.Add(p);
        }
        var x = from s in list
                select s;
        Console.WriteLine("Player list:");
        foreach (Player pl in x)
        {
            Console.WriteLine(pl.PlayerName);

        }
        Console.ReadLine();
    }
}