﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


 class Player
{
    public string PlayerName { get; set; }
    public long Runs { get; set; }
    public string Country { get; set; }
    public Player()
    { }

    public Player(string pname,string country, long run)
    {
        PlayerName = pname;
        Runs = run;
        Country = country;
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<Player> list = new List<Player>();
        Console.WriteLine("Enter the number of players");
        int n = Int32.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Enter player name");
            string pname = Console.ReadLine();
            Console.WriteLine("Enter country");
            string country = Console.ReadLine();
            Console.WriteLine("Enter number of runs");
            long run = long.Parse(Console.ReadLine());
            list.Add(new Player(pname, country, run));
        }
        Console.WriteLine("Enter name and country you want to search");
        string name = Console.ReadLine();
        string country1 = Console.ReadLine();
        var x = from item in list
                where item.PlayerName.Equals(name) && item.Country.Equals(country1)
                select item;
        foreach (var c in x)
        {
            Console.WriteLine(@"Player : {0}
Country : {1}
Number of Runs : {2}",c.PlayerName,c.Country,c.Runs);
        }
        Console.ReadLine();
    }
}