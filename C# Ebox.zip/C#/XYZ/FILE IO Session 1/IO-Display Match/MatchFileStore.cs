﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class MatchFileStore
{
    public List<Match> ObtainMatchFromFile(StreamReader sr)
    {
        List<Match> LM = new List<Match>();
        string str = "";
        while ((str = sr.ReadLine()) != null)
        {
            Match m = new Match(str.Substring(0, 5).Trim(), str.Substring(5, 5).Trim(), str.Substring(10, 20).Trim(), str.Substring(30, 10).Trim());
            LM.Add(m);
        }
        return LM;
    }
}
