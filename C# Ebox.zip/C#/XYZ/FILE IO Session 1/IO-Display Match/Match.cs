﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Match
{
    public string teamOne { get; set; }
    public string teamTwo { get; set; }
    public string venue { get; set; }
    public string matchDate { get; set; }
    public Match() { }
    public Match(string teamOne, string teamTwo, string venue, string matchDate)
    {
        this.teamOne = teamOne; this.teamTwo = teamTwo; this.venue = venue; this.matchDate = matchDate;
    }
    public void DisplayMatch(Match M, int I)
    {
        Console.WriteLine(@"Match {4}
TeamOne : {0}
TeamTwo : {1}
Venue : {2}
MatchDate : {3}", M.teamOne, M.teamTwo, M.venue, M.matchDate, I);
    }
}