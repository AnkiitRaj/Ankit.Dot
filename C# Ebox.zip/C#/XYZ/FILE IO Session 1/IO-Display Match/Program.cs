﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        Match m = new Match();
        ; StreamReader sr = new StreamReader("matches.txt");
        List<Match> LM = new MatchFileStore().ObtainMatchFromFile(sr);
        Console.WriteLine("The Match Details are :");
        for (int i = 0; i < LM.Count; i++)
        {
            m.DisplayMatch(LM[i], (i + 1));
        }

    }
}
