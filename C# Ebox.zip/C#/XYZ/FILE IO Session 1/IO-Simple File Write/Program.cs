﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

class Program
{
    static void Main(string[] args)
    {

        StreamWriter sw = new StreamWriter("player.csv");
        Console.WriteLine("Enter the name of the player");
        sw.Write(Console.ReadLine());
        sw.Write(",");
        Console.WriteLine("Enter the team name");
        sw.Write(Console.ReadLine());
        sw.Write(",");
        Console.WriteLine("Enter the number of matches played");
        sw.WriteLine(Console.ReadLine());
        sw.Close();
        sw.Dispose();
        
    }
}
