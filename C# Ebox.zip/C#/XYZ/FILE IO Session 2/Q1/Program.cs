using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter number of words");
        int n = int.Parse(Console.ReadLine());
        string[] s = new string[n];
        int[] opt = new int[n];
        Console.WriteLine("Enter the strings to be searched");
        for (int i = 0; i < n; i++)
            s[i] = Console.ReadLine();
        StreamReader s1 = new StreamReader("team.txt");
        string s2 = s1.ReadLine();
        int p = 0;
        Console.WriteLine("Given string is {0}", s2);
        for (int i = 0; i < n; i++)
        {
            while (s2.IndexOf(s[i], p) != -1)
            {
                opt[i]++;
                p = s2.IndexOf(s[i], p) + s[i].Length;
            }
            p = 0;
            Console.WriteLine("Word:{0} Count:{1}", s[i], opt[i]);
        }

    }
}
