﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Please provide the number of players to be registered");
        int n = int.Parse(Console.ReadLine());
        List<Player> list = new List<Player>();
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Please enter player name");
            string name = Console.ReadLine();

            Console.WriteLine("Please select the skill of the player");
            Console.WriteLine("1.All Rounder");
            Console.WriteLine("2.Batsman");
            Console.WriteLine("3.Bowler");
            int ch = int.Parse(Console.ReadLine());
            string skill = null;
            if (ch == 1)
                skill = "All Rounder";
            else if (ch == 2)
                skill = "Batsman";
            else if (ch == 3)
                skill = "Bowler";

            list.Add(new Player(name, skill));

        }
        list.Sort();
        PlayerSkillNameComparer ps = new PlayerSkillNameComparer();
        list.Sort(ps);

        Console.WriteLine("Player Details");
        foreach (Player item in list)
        {
            Console.WriteLine("Player : {0} Skill  : {1}", item.Name, item.Skill);
        }
        Console.ReadLine();
    }
}