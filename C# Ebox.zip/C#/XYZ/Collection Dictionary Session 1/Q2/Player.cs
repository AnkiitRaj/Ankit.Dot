﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Player : IComparable<Player>
{
    private string name;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    private string skill;

    public string Skill
    {
        get { return skill; }
        set { skill = value; }
    }

    public Player() { }

    public Player(string name, string skill)
    {
        this.name = name;
        this.skill = skill;
    }


    public int CompareTo(Player p1)
    {
      return this.Name.CompareTo(p1.Name);
    }
}