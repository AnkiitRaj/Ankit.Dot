﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Player
    {
        private string _bowlerName ;

        public string BowlerName 
        {
            get { return _bowlerName ; }

            set { _bowlerName  = value; }
        }

        private int _wicketCount;

        public int WicketCount
        {
            get { return _wicketCount; }
            set { _wicketCount = value; }
        }

        public Player(string _bowlerName, int _wicketCount) 
        {
            this._bowlerName = _bowlerName;
            this._wicketCount = _wicketCount;
        }

    }

