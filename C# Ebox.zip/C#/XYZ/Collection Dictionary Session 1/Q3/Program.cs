﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        string res = "no";

        Dictionary<string, int> dict = new Dictionary<string, int>();
        do
        {
            Console.WriteLine("Enter the player name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter wickets - seperated by \"|\" symbol");
            string[] wicket = Console.ReadLine().Split('|');
            //Player p = new Player(name, wicket.Length);
            dict.Add(name, wicket.Length);

            Console.WriteLine("Do you want to add another player (yes/no)");
            res = Console.ReadLine();
        } while (res == "yes");
        int count = 0;
        string c = "no";
        do
        {
            Console.WriteLine("Enter the player name to search");
            string s = Console.ReadLine();

            foreach (KeyValuePair<string, int> item in dict)
            {
                if (item.Key.Contains(s))
                {
                    count++;
                    Console.WriteLine("Player Name : {0}", item.Key);
                    Console.WriteLine("Wicket Count : {0}", item.Value);
                }

            }
            if (count == 0)
            {
                Console.WriteLine("No player found with the name {0}", s);
            }
            Console.WriteLine("Do you want to search another player (yes/no)");
            c = Console.ReadLine();

        } while (c == "yes");
        Console.ReadLine();
    }
}