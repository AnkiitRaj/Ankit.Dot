﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        List<Team> list = new List<Team>();
        Console.WriteLine("Enter number of teams:");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Enter team {0} detail", i + 1);
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter number of matches");
            long match = long.Parse(Console.ReadLine());
            list.Add(new Team(name, match));
        }
        TeamComparer tm = new TeamComparer();
        list.Sort(tm);
        Console.WriteLine("Team list after sort by number of matches");
        foreach (Team item in list)
        {
            Console.WriteLine("{0}-{1}", item.Name, item.NumberOfMatches);
        }
        Console.ReadLine();
    }
}