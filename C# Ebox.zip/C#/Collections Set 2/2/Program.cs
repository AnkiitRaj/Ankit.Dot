﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        public static void Main(string[] args) 
        {
            //Console.WriteLine("Please provide the number of  players ");
            //int n = int.Parse(Console.ReadLine());
            //List<Ranking> rl = new List<Ranking>();
            //for (int i = 0; i < n; i++)
            //{
            //    Console.WriteLine("Enter the name of the player {0}",i+1);
            //    string name = Console.ReadLine();
            //    Console.WriteLine("Enter the score of the player {0}",i+1);
            //    long score = long.Parse(Console.ReadLine());
            //    rl.Add(new Ranking(name, score));
            //}
            //rl.Sort();
            //Console.WriteLine("Player Details by Score(High to Low)");
            //int c=0;
            //foreach (Ranking r in rl)
            //{
            //    Console.WriteLine(++c + " " + r.Name + " " + r.Score);
            //}


            Console.WriteLine("Enter the number of matches");
            int n = int.Parse(Console.ReadLine());
            List<Match> ls = new List<Match>();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter  match date in (MM-dd-yyyy)");
                DateTime d = DateTime.ParseExact(Console.ReadLine(), "MM-dd-yyyy", null);
                Console.WriteLine("Enter Team 1");
                string teamOne = Console.ReadLine();
                Console.WriteLine("Enter Team 2");
                string teamTwo = Console.ReadLine();
                ls.Add(new Match(d, teamOne, teamTwo));
            }
            ls.Sort();
            Console.WriteLine("Match Details");
            int t1 = 1, t2 = 2;
            foreach (Match m in ls)
            {
                Console.WriteLine("Team " + t1 + " " + m.TeamOne);
                Console.WriteLine("Team " + t2 + " " + m.TeamTwo);
                Console.WriteLine("Match held on " + m.MatchDate.ToString("MM-dd-yyyy"));
            }
            Console.ReadKey();
        }
    }
