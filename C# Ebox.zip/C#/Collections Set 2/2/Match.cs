﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Match:IComparable<Match>
    {
        private DateTime matchDate;

        public DateTime MatchDate
        {
            get { return matchDate; }
            set { matchDate = value; }
        }
        private string teamOne;

        public string TeamOne
        {
            get { return teamOne; }
            set { teamOne = value; }
        }
        private string teamTwo;

        public string TeamTwo
        {
            get { return teamTwo; }
            set { teamTwo = value; }
        }
        public Match() { }
        public Match(DateTime MatchDate, string TeamOne, string TeamTwo) 
        {
            this.MatchDate = MatchDate;
            this.TeamOne = TeamOne;
            this.teamTwo = TeamTwo;
        }
        public int CompareTo(Match other)
        {
            if(this.MatchDate.CompareTo(other.MatchDate)==1)
                return -1;
            else if(this.MatchDate.CompareTo(other.MatchDate)==-1)
                return 1;
            return 0;
        }
    }
