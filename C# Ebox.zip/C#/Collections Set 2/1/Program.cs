﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        public static void Main(string[] args) 
        {
            Console.WriteLine("Please provide the number of  players ");
            int n = int.Parse(Console.ReadLine());
            List<Ranking> rl = new List<Ranking>();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter the name of the player {0}",i+1);
                string name = Console.ReadLine();
                Console.WriteLine("Enter the score of the player {0}",i+1);
                long score = long.Parse(Console.ReadLine());
                rl.Add(new Ranking(name, score));
            }
            rl.Sort();
            Console.WriteLine("Player Details by Score(High to Low)");
            int c=0;
            foreach (Ranking r in rl)
            {
                Console.WriteLine(++c + " " + r.Name + " " + r.Score);
            }
            
            
        }
    }
