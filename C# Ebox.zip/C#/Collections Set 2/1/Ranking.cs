﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Ranking:IComparable<Ranking>
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private long score;

        public long Score
        {
            get { return score; }
            set { score = value; }
        }
        public Ranking() { }
        public Ranking(string Name, long Score) 
        {
            this.Name = Name;
            this.Score = Score;
        }
        public int CompareTo(Ranking other)
        {
            if (this.score.CompareTo(other.score) == 1)
                return -1;
            else if (this.score.CompareTo(other.score) == -1)
                return 1;
            return 0;
        }
    }
