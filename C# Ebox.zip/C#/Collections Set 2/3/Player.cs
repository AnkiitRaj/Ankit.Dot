﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Player : IComparable<Player>
{

    string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    public Player()
    {
        //  TODO Auto-generated constructor stub
    }

    public Player(string name)
    {
        this._name = name;
    }
    
    public int CompareTo(Player p)
    {
        return this._name.CompareTo(p.Name);
    }
}
