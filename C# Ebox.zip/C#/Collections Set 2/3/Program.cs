﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        List<string> list1 = new List<string>();
        for (int i = 0; (i < n); i++) {
            list1.Add(Console.ReadLine());
        }
        
        List<Team> tl = new List<Team>();
        foreach (string s in list1)
        {
            string[] t = s.Split('|');
            bool flag = false;
            for (int i = 0; (i < tl.Count); i++) {
                if (tl[i].Name.Equals(t[0])) {
                    List<Player> pl = tl[i].L1;
                    flag = true;
                    pl.Add(new Player(t[1]));
                    break;
                }
                
            }
            
            if ((flag == false)) {
                List<Player> pl = new List<Player>();
                pl.Add(new Player(t[1]));
                Team t1 = new Team();
               // t1.Name(t[0]);
                t1.Name=(t[0]);
                t1.L1 = (pl);
                tl.Add(t1);
            }
            
        }
        
        tl.Sort();
        Console.WriteLine("Teams and Players in ascending order");
        for (int i = 0; (i < tl.Count); i++) 
        {
            Console.WriteLine(tl[i].Name);
            List<Player> pl = tl[i].L1;
            pl.Sort();
            for (int j = 0; j < pl.Count; j++)
            {
                Console.WriteLine(("--" + pl[j].Name));
            }
        
    }
        Console.ReadKey();
    }
    }