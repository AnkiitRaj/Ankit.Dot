﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Team : IComparable<Team>
{

    string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private List<Player> _l1 = new List<Player>();

    public List<Player> L1
    {
        get { return _l1; }
        set { _l1 = value; }
    }

    public Team()
    {
       
    }

    public Team(string name, List<Player> l1)
    {
        this._name = name;
        this._l1 = l1;
    }

    
    public int CompareTo(Team o)
    {
        return this._name.CompareTo(o.Name);
    }
}