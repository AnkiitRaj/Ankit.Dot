﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Player:IComparable<Player>
    {
        private string playerName;

        public string PlayerName
        {
            get { return playerName; }
            set { playerName = value; }
        }
        private string skill;

        public string Skill
        {
            get { return skill; }
            set { skill = value; }
        }
        private long capNumber;

        public long CapNumber
        {
            get { return capNumber; }
            set { capNumber = value; }
        }
        public Player() { }
        public Player(string PlayerName, string Skill, long CapNumber)
        {
            this.PlayerName = PlayerName;
            this.Skill = Skill;
            this.CapNumber = CapNumber;
        }

        public int CompareTo(Player other)
        {
            if (this.CapNumber.CompareTo(other.CapNumber) == 1)
                return -1;
            else if (this.CapNumber.CompareTo(other.CapNumber) == -1)
                return 1;
            return 0;
        }
    }
