﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        public static void Main(string[] args) 
        {
            //Console.WriteLine("Please provide the number of  players ");
            //int n = int.Parse(Console.ReadLine());
            //List<Ranking> rl = new List<Ranking>();
            //for (int i = 0; i < n; i++)
            //{
            //    Console.WriteLine("Enter the name of the player {0}",i+1);
            //    string name = Console.ReadLine();
            //    Console.WriteLine("Enter the score of the player {0}",i+1);
            //    long score = long.Parse(Console.ReadLine());
            //    rl.Add(new Ranking(name, score));
            //}
            //rl.Sort();
            //Console.WriteLine("Player Details by Score(High to Low)");
            //int c=0;
            //foreach (Ranking r in rl)
            //{
            //    Console.WriteLine(++c + " " + r.Name + " " + r.Score);
            //}

            //HashSet<Team> tm = new HashSet<Team>();
            //int n = int.Parse(Console.ReadLine());
            //string s;
            //for (int i = 0; i < n; i++) 
            //{
            //    s = Console.ReadLine();
            //    string[] s1 = s.Split('|');
            //    //t.Add(new Team(s1[0]));

            //    Team t = new Team(s1[0]);
            //    t.AddPlayer(s1[1]);
            //    tm.Add(t);
            //}
            
            //Console.WriteLine("Team and Players in ascending order");
            //List<Player> p = new List<Player>();
            //p.Sort();
            Console.WriteLine("Enter number of players:");
            int n = int.Parse(Console.ReadLine());
            List<Player> p = new List<Player>();
            for (int i = 0; i < n;i++ )
            {
                Console.WriteLine("Enter player {0} detail",i+1);
                Console.WriteLine("Enter Name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Skill");
                string skill = Console.ReadLine();
                Console.WriteLine("Enter Cap Number");
                long l = long.Parse(Console.ReadLine());
                p.Add(new Player(name, skill, l));
            }
            Console.WriteLine("Player list after sorting by cap number in descending order");
            p.Sort();
            foreach (Player pm in p)
               Console.WriteLine(pm.PlayerName+"-"+pm.CapNumber);
            
                Console.ReadKey();
        }
    }
