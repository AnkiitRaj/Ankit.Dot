﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Score
{
    int _start;
    int _end;
    string _scoreType;
    List<int> _scoreList;

    public Score(int _start, int _end, string _scoreType)
    {
        Start = _start;
        End = _end;
        ScoreType = _scoreType;
    }
    public int Start
    {
        set { _start = value; }
        get { return _start; }
    }
    public int End
    {
        set { _end = value; }
        get { return _end; }
    }
    public string ScoreType
    {
        set { _scoreType = value; }
        get { return _scoreType; }
    }
    public void RunThread()
    {
        SortedSet<int> s = new SortedSet<int>();
        if (ScoreType.Equals("ODD"))
        {
            Console.WriteLine("Odd numbers in given range");
            for (int i = Start; i <= End; i++)
            {
                if (i % 2 != 0)
                {
                    s.Add(i);
                }
            }
        }
        else if (ScoreType.Equals("EVEN"))
        {
            Console.WriteLine("Even numbers in given range");
            for (int i = Start; i <= End; i++)
            {
                if (i % 2 == 0)
                {
                    s.Add(i);
                }
            }
        }
        Display(s);
    }
    public void Display(SortedSet<int> s)
    {
        foreach (int i in s)
        {
            Console.Write(i + " ");
        }
        Console.WriteLine();
    }
}
