﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter range of numbers");
            int s = Int32.Parse(Console.ReadLine());
            int e = Int32.Parse(Console.ReadLine());

            Thread t1 = new Thread(new Score(s, e, "ODD").RunThread);
            Thread t2 = new Thread(new Score(s, e, "EVEN").RunThread);
            t1.Start();
            t1.Join();
            t2.Start();

            Console.ReadLine();
        }

    }

