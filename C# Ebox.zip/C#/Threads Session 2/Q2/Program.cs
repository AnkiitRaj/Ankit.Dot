﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


public class UserProgramCode
{
    static StringBuilder resultName = new StringBuilder();
    public static void GetNodeByName(string input1)
    {
        XmlDocument xmlDoc = new XmlDocument();
        try
        {
            xmlDoc.LoadXml(input1);
        }
        catch (XmlException xe)
        {
            Console.WriteLine("Input Xml is not parseable. " + xe.Message);
        }
        string xpath = "Names/Name";
        var nodes = xmlDoc.SelectNodes(xpath);
        foreach (XmlNode childrenNode in nodes)
        {
            resultName.Append(childrenNode.SelectSingleNode("FirstName").InnerText + " " + childrenNode.SelectSingleNode("LastName").InnerText + " ");
        }
        Console.WriteLine(resultName.ToString());
    }
}
// XmlDocument represent the contents of an xml file in memory,when loading it from a file.
// XmlReader represents a reader that provides fast,noncached ,

class Program
{
    static void Main(string[] args)
    {
        string s = Console.ReadLine();
        UserProgramCode.GetNodeByName(s);
        Console.ReadLine();
    }
}

