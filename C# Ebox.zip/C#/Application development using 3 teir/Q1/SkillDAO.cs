﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

class SkillDAO
{
    public Skill FindBySkillName(String skillName)
    {
        //Console.WriteLine("Entered SkillDao");
        Skill s = new Skill();

        string conString = Connect.Connection();
        SqlConnection sqlCon = new SqlConnection();
        sqlCon.ConnectionString = conString;

        SqlCommand com = new SqlCommand();
        com.CommandType = CommandType.Text;
        com.CommandText = "Select * from skill where name = '" + skillName + "';";
        com.Connection = sqlCon;

        SqlDataAdapter adapter = null;
        DataSet DS = null;


        adapter = new SqlDataAdapter(com);
        DS = new DataSet();
        adapter.Fill(DS, "Skill");

        foreach (DataTable dt in DS.Tables)
        {
            foreach (DataRow dr in dt.Rows)
            {
                //foreach (DataColumn col in dt.Columns)
                //{
                //    //if (DS.Tables[0].Rows[0][0].Equals(skillName))
                //{
                Skill sk = new Skill(long.Parse(dr[0].ToString()), dr[1].ToString()); // new Skill(long.Parse(DS.Tables[0].Rows[0][0].ToString()), DS.Tables[0].Rows[0][1].ToString());
                //Console.WriteLine("Skill Name in Skill Dao=" + sk.SkillName);
                s = sk;
                //}
                //}
            }
        }

        return s;

    }


    public Skill FindBySkillId(long skillId)
    {
        //Console.WriteLine("Entered SkillDao");
        Skill s = new Skill();

        string conString = Connect.Connection();
        SqlConnection sqlCon = new SqlConnection();
        sqlCon.ConnectionString = conString;

        SqlCommand com = new SqlCommand();
        com.CommandType = CommandType.Text;
        com.CommandText = "Select * from skill where id = '" + skillId + "';";
        com.Connection = sqlCon;

        SqlDataAdapter adapter = null;
        DataSet DS = null;


        adapter = new SqlDataAdapter(com);
        DS = new DataSet();
        adapter.Fill(DS, "Skill");

        foreach (DataTable dt in DS.Tables)
        {
            foreach (DataRow dr in dt.Rows)
            {
                //foreach (DataColumn col in dt.Columns)
                //{
                //    if (DS.Tables[0].Rows[0][0].Equals(skillId))
                //    {
                Skill sk = new Skill(long.Parse(dr[0].ToString()), dr[1].ToString());    //new Skill(long.Parse(DS.Tables[0].Rows[0][0].ToString()), DS.Tables[0].Rows[0][1].ToString());
                //Console.WriteLine("Skill Name in Skill Dao="+sk.SkillName);
                s = sk;
                //    }
                //}
            }
        }

        return s;
    }
}
