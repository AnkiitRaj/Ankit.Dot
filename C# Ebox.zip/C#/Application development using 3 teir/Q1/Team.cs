﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Team
{
    public long TeamId { get; set; }
    public string TeamName { get; set; }

    public Team() { }
    public Team(long _teamId, string _teamName)
    {
        TeamId = _teamId;
        TeamName = _teamName;
    }
}
