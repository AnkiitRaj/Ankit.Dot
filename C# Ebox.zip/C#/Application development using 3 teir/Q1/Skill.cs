﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Skill
{
    public long SkillId { get; set; }
    public string SkillName { get; set; }

    public Skill() { }
    public Skill(long _skillId, string _skillName)
    {
        SkillId = _skillId;
        SkillName = _skillName;
    }
}
