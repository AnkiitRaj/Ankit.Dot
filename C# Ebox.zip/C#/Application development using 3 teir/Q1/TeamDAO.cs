﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


class TeamDAO
{
    public Team FindByTeamId(long teamId)
    {
        Team t = new Team();

        string conString = Connect.Connection();
        SqlConnection sqlCon = new SqlConnection();
        sqlCon.ConnectionString = conString;

        SqlCommand com = new SqlCommand();
        com.CommandType = CommandType.Text;
        com.CommandText = "Select * from Team where id = '" + teamId + "';";
        com.Connection = sqlCon;

        SqlDataAdapter adapter = null;
        DataSet DS = null;


        adapter = new SqlDataAdapter(com);
        DS = new DataSet();
        adapter.Fill(DS, "Team");

        foreach (DataTable dt in DS.Tables)
        {
            foreach (DataRow dr in dt.Rows)
            {
                //foreach (DataColumn col in dt.Columns)
                //{
                //    if (DS.Tables[0].Rows[0][0].Equals(teamId))
                //    {
                Team temp = new Team(long.Parse(dr[0].ToString()), dr[1].ToString());      //new Team(long.Parse(DS.Tables[0].Rows[0][0].ToString()), DS.Tables[0].Rows[0][1].ToString());
                t = temp;
                //    }
                //}
            }
        }

        return t;
    }

    public Team FindByTeamName(string TeamName)
    {
        Team t = new Team();

        string conString = Connect.Connection();
        SqlConnection sqlCon = new SqlConnection();
        sqlCon.ConnectionString = conString;

        SqlCommand com = new SqlCommand();
        com.CommandType = CommandType.Text;
        com.CommandText = "Select * from team where name = '" + TeamName + "';";
        com.Connection = sqlCon;

        SqlDataAdapter adapter = null;
        DataSet DS = null;


        adapter = new SqlDataAdapter(com);
        DS = new DataSet();
        adapter.Fill(DS, "Team");

        foreach (DataTable dt in DS.Tables)
        {
            foreach (DataRow dr in dt.Rows)
            {
                //foreach (DataColumn col in dt.Columns)
                //{
                //    if (DS.Tables[0].Rows[0][0].Equals(TeamName))
                //    {
                Team temp = new Team(long.Parse(dr[0].ToString()), dr[1].ToString());      //new Team(long.Parse(DS.Tables[0].Rows[0][0].ToString()), DS.Tables[0].Rows[0][1].ToString());
                t = temp;
                //    }
                //}
            }
        }

        return t;
    }
}