﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


class PlayerDAO
{
    string connection = Connect.Connection();

    public void CreatePlayer(Player p)
    {
        SqlConnection con = new SqlConnection(connection);
        con.Open();
        string query = "Insert into player(name,country,skill_id,team_id) values('" + p.PlayerName + "' , '" + p.Country + "' , " + p.Skillns.SkillId + ", " + p.TeamIns.TeamId + ")";
        SqlCommand c = new SqlCommand(query, con);
        c.ExecuteNonQuery();
    }


    public List<Player> GetPlayerDetails(string skillName)
    {
        //Console.WriteLine("Entered PlayerDao");
        SqlConnection con = new SqlConnection(connection);
        con.Open();
        List<Player> plist = new List<Player>();
        SkillBO sbo = new SkillBO();
        TeamBO tbo = new TeamBO();
        Skill s = sbo.FindBySkillName(skillName);
        long sid = s.SkillId;

        string query = "select * from player where skill_id=" + sid;
        SqlCommand com = new SqlCommand(query, con);

        SqlDataReader r = com.ExecuteReader();

        while (r.Read())
        {
            string name = r["name"].ToString();
            string country = r["country"].ToString();
            long s_id = long.Parse(r["skill_id"].ToString());
            long t_id = long.Parse(r["team_id"].ToString());
            Player p = new Player(name, country, sbo.FindBySkillId(s_id), tbo.FindByTeamId(t_id));
            plist.Add(p);
        }
        r.Close();
        con.Close();
        return plist;
    }



    public List<Player> GetAllPlayerDetails()
    {
        string conString = Connect.Connection();
        SqlConnection sqlCon = new SqlConnection();
        sqlCon.ConnectionString = conString;
        sqlCon.Open();

        List<Player> list = new List<Player>();
        SkillBO skillbo = new SkillBO();
        TeamBO teambo = new TeamBO();


        string query = "select * from Player";
        SqlCommand command = new SqlCommand(query, sqlCon);

        SqlDataReader r1 = command.ExecuteReader();

        while (r1.Read())
        {
            string a = r1["name"].ToString();
            string b = r1["country"].ToString();
            long c = long.Parse(r1["skill_id"].ToString());
            long d = long.Parse(r1["team_id"].ToString());

            Skill newS = skillbo.FindBySkillId(c);
            //Console.WriteLine("Skill Name="+newS.SkillName);

            Player p = new Player(a, b, skillbo.FindBySkillId(c), teambo.FindByTeamId(d));
            list.Add(p);
        }
        r1.Close();
        sqlCon.Close();
        return list;
    }
}