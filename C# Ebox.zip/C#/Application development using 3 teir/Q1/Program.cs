﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        List<Player> plist = new List<Player>();
        PlayerDAO play = new PlayerDAO();

        Console.WriteLine(@"Menu
1.List all Players
2.Add new player
3.Search Player");

        int choice = int.Parse(Console.ReadLine());

        switch (choice)
        {
            case 1:

                Console.WriteLine("Player details");
                Console.WriteLine("{0,-15} {1,-15} {2,-15} {3,-15}", "Player Name", "Country", "Skill", "Team Name");
                plist = play.GetAllPlayerDetails();
                foreach (Player p in plist)
                {
                    Console.WriteLine("{0,-15} {1,-15} {2,-15} {3,-15}", p.PlayerName, p.Country, p.Skillns.SkillName, p.TeamIns.TeamName);
                }
                break;

            case 2:
                plist = play.GetAllPlayerDetails();
                Console.WriteLine("Enter the player name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter the country name");
                string country = Console.ReadLine();
                Console.WriteLine("Enter the skill");
                string skill = Console.ReadLine();
                Console.WriteLine("Enter the team name");
                string tname = Console.ReadLine();

                SkillBO sbo = new SkillBO();
                Skill s = sbo.FindBySkillName(skill);

                TeamBO tbo = new TeamBO();
                Team t = tbo.FindByTeamName(tname);

                Player p1 = new Player(name, country, s, t);
                PlayerDAO dao = new PlayerDAO();
                dao.CreatePlayer(p1);
                plist.Add(p1);
                Console.WriteLine("Player has been inserted.");
                Console.WriteLine("Player details");
                Console.WriteLine("{0,-15} {1,-15} {2,-15} {3,-15}", "Player Name", "Country", "Skill", "Team Name");
                foreach (Player p in plist)
                {
                    Console.WriteLine("{0,-15} {1,-15} {2,-15} {3,-15}", p.PlayerName, p.Country, p.Skillns.SkillName, p.TeamIns.TeamName);
                }
                break;

            case 3:
                Console.WriteLine("Enter the Skill name");
                string sname = Console.ReadLine();
                plist = play.GetPlayerDetails(sname);
                Console.WriteLine("Player details");
                Console.WriteLine("{0,-15} {1,-15} {2,-15} {3,-15}", "Player Name", "Country", "Skill", "Team Name");
                foreach (Player p in plist)
                {
                    Console.WriteLine("{0,-15} {1,-15} {2,-15} {3,-15}", p.PlayerName, p.Country, p.Skillns.SkillName, p.TeamIns.TeamName);
                }
                break;

            default:
                Console.WriteLine("Invalid Option");
                break;
        }

        Console.ReadLine();

    }
}