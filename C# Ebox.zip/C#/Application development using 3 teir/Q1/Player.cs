﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Player
{
    public string PlayerName { get; set; }
    public string Country { get; set; }
    public Skill Skillns { get; set; }
    public Team TeamIns { get; set; }

    public Player() { }
    public Player(string _playerName, string _country, Skill _skillns, Team _teamIns)
    {
        PlayerName = _playerName;
        Country = _country;
        Skillns = _skillns;
        TeamIns = _teamIns;
    }
}
