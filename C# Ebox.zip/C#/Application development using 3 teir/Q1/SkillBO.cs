﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class SkillBO
{

    public Skill FindBySkillId(long skillId)
    {
        SkillDAO skillDao = new SkillDAO();
        Skill sk = skillDao.FindBySkillId(skillId);
        return sk;
    }

    public Skill FindBySkillName(string skillName)
    {
        SkillDAO skillDao = new SkillDAO();
        Skill sk = skillDao.FindBySkillName(skillName);
        return sk;
    }
}
