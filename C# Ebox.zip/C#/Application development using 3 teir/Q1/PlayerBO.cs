﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class PlayerBO
{
    public List<Player> GetAllPlayerDetails()
    {
        PlayerDAO playerdao = new PlayerDAO();
        List<Player> newlist = playerdao.GetAllPlayerDetails();
        return newlist;
    }


}
