﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class TeamBO
{
    public Team FindByTeamId(long TeamId)
    {
        TeamDAO teamdao = new TeamDAO();
        Team team = teamdao.FindByTeamId(TeamId);
        return team;
    }


    public Team FindByTeamName(string TeamName)
    {
        TeamDAO teamdao = new TeamDAO();
        Team team = teamdao.FindByTeamName(TeamName);
        return team;
    }
}
