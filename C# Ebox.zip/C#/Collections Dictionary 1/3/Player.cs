﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Player
{
    private string bowlerName;

    public string BowlerName
    {
        get { return bowlerName; }
        set { bowlerName = value; }
    }
    private int wicketCount;

    public int WicketCount
    {
        get { return wicketCount; }
        set { wicketCount = value; }
    }
    public Player() { }
    public Player(string bowlername, int wicketcount)
    {
        this.BowlerName = bowlername;
        this.WicketCount = wicketcount;
    }
}
