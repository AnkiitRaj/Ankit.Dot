﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static void Main(string[] args)
    {
        Dictionary<string, Player> dic = new Dictionary<string, Player>();
        string a = "yes";
        do
        {
            Console.WriteLine("Enter the player name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter wickets - seperated by \"|\" symbol");
            string s = Console.ReadLine();
            string[] s1 = s.Split('|');
            int w = s1.Length;
            dic.Add(name, new Player(name, w));
            Console.WriteLine("Do you want to add another player (yes/no)");
            a = Console.ReadLine();
        } while (a == "yes");
        string b = "yes";
        do
        {
            Console.WriteLine("Enter the player name to search");
            string srh = Console.ReadLine();
            if (dic.Keys.Contains(srh))
            {
                Console.WriteLine("Player Name : {0}", srh);
                Console.WriteLine("Wicket Count : {0}", dic[srh].WicketCount);
            }
            else
                Console.WriteLine("No player found with the name {0}", srh);
                Console.WriteLine("Do you want to search another player (yes/no)");
                b = Console.ReadLine();
        } while (b == "yes");
        Console.WriteLine();

    }

}