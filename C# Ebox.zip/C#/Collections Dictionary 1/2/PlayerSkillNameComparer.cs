﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class PlayerSkillNameComparer : IComparer<Player>
    {
        public int Compare(Player player1, Player player2)
        {
            if (player1.Skill.CompareTo(player2.Skill) == 1)
                return 1;
            else if (player1.Skill.CompareTo(player2.Skill) == -1)
                return -1;
            else if (player1.Skill.CompareTo(player2.Skill) == 0)
                return player1.Name.CompareTo(player2.Name);
            return 0;
            
        }

    }

