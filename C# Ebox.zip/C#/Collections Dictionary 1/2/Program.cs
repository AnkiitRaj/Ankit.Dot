﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Please provide the number of players to be registered");
        int n = int.Parse(Console.ReadLine());
        Dictionary<int, Player> dic = new Dictionary<int, Player>();
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Please enter player name");
            string name = Console.ReadLine();
            Console.WriteLine("Please select the skill of the player");
            Console.WriteLine("1.All Rounder\n2.Batsman\n3.Bowler");
            int ch = int.Parse(Console.ReadLine());
            string skill = "";
            if (ch == 1)
                skill = "All Rounder";
            else if (ch == 2)
                skill = "Batsman";
            else if (ch == 3)
                skill = "Bowler";
            dic.Add((i + 1), new Player(name, skill));
        }
        Player[] p = dic.Values.ToArray();
        Array.Sort(p, new PlayerSkillNameComparer());
        Console.WriteLine("Player Details");
        foreach (Player P in p)
        {
            Console.WriteLine("Player : {0} Skill : {1}", P.Name, P.Skill);
        }
        Console.ReadKey();
    }
}