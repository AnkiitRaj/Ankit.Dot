﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Player
{
    private string name;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    private string skill;

    public string Skill
    {
        get { return skill; }
        set { skill = value; }
    }
    public Player() { }
    public Player(string Name, string Skill)
    {
        this.Name = Name;
        this.Skill = Skill;
    }

}
