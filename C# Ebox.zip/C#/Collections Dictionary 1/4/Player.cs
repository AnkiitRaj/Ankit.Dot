﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Player
    {
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _team;

        public string Team
        {
            get { return _team; }
            set { _team = value; }
        }


        private string _skill;

        public string Skill
        {
            get { return _skill; }
            set { _skill = value; }
        }
        public Player(string _name, string _team, string _skill)
        {
            this._name = _name;
            this._skill = _skill;
            this._team = _team;
        }



    }

