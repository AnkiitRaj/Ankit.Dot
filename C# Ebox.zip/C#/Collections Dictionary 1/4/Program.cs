﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


  class Program
  {
    static void Main(string[] args)
    {
      List<Player> list = new List<Player>();
      SortedDictionary<string, Player> dict = new SortedDictionary<string, Player>();

      Console.WriteLine("Enter the number of players");
      int n = int.Parse(Console.ReadLine());
      for (int i = 0; i < n; i++)
      {
        Console.WriteLine("Enter the details of the player {0}",i+1);
        string cap = Console.ReadLine();
        string name = Console.ReadLine();
        string team = Console.ReadLine();
        string skill = Console.ReadLine();
        Player p = new Player(name, team, skill);
        list.Add(p);
        dict.Add(cap, p);
      }
      foreach (var item in dict)
      {
        Console.WriteLine("{0}--{1}--{2}--{3}",item.Key,item.Value.Name,item.Value.Team,item.Value.Skill);
      }
      Console.ReadLine();
    }
  }
