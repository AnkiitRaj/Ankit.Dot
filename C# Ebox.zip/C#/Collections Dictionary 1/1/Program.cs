﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter number of teams:");
        int n = int.Parse(Console.ReadLine());
        Dictionary<long, Team> dict = new Dictionary<long, Team>();
        for (long i = 0; i < n; i++)
        {
            Console.WriteLine("Enter team {0} detail", i + 1);
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter number of matches");
            long match = long.Parse(Console.ReadLine());
            dict.Add((i + 1), new Team(name, match));
        }
        Console.WriteLine("Team list after sort by number of matches");
        Team[] t = dict.Values.ToArray();
        Array.Sort(t, new TeamComparer());
        foreach (Team t1 in t)
        {
            Console.WriteLine("{0}-{1}", t1.Name, t1.NumberOfMatches);
        }

        Console.ReadKey();
    }
}
