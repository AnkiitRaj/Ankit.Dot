﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class TeamComparer : IComparer<Team>
    {

        public int Compare(Team x, Team y)
        {
            return x.NumberOfMatches.CompareTo(y.NumberOfMatches);
        }
    }
