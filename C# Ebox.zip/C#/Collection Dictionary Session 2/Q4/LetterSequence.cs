﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class LetterSequence
{
    private string sentence;
    public string Sentence { get; set; }

    public LetterSequence() { }
    public LetterSequence(string s)
    {
        this.Sentence = s;
    }
    public SortedDictionary<char, int> computeFrequency()
    {
        SortedDictionary<char, int> sd = new SortedDictionary<char, int>();
        int c = 0;
        char[] ar = Sentence.ToCharArray();
        for (int i = 0; i < ar.Length; i++)
        {
            c = 0;
            for (int j = 0; j < ar.Length; j++)
            {
                if (ar[i] == ar[j])
                    c++;
            }
            if (sd.Keys.Contains(ar[i]))
                continue;
            else if (sd.Keys.Contains(ar[i]) == false && ar[i] != ' ')
                sd.Add(ar[i], c);

        }
        return sd;
    }
    public void DisplayLetterFrequency(SortedDictionary<char, int> frequencyMap)
    {
        foreach (char item in frequencyMap.Keys)
        {
            Console.Write(item + " : ");
            for (int i = 0; i < frequencyMap[item]; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }
}