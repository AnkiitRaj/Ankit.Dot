﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the input string");
        string s = Console.ReadLine();
        LetterSequence ls = new LetterSequence(s);
        SortedDictionary<char, int> sd = ls.computeFrequency();
        ls.DisplayLetterFrequency(sd);
    }
}


