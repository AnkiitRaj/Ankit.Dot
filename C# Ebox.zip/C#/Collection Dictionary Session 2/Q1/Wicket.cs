﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Wicket
    {
        private string _playerName ;

        public string PlayerName 
        {
            get { return _playerName ; }
            set { _playerName  = value; }
        }

        private Wicket _wicket;

        public Wicket Wickets
        {
            get { return _wicket; }
            set { _wicket = value; }
        }

        public Wicket(string _playerName, Wicket _wicket) 
        {
            this._playerName = _playerName;
            this._wicket = _wicket;
        }

    }

