﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Player
{
    private string name;

    public string Name { get; set; }

    private string team;

    public string Team { get; set; }

    private string skill;

    public string Skill { get; set; }

    public Player(string name, string team, string skill)
    {
        this.Name = name;
        this.Team = team;
        this.Skill = skill;
    }

}