﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Player p = null;
        SortedDictionary<string, Player> sd = new SortedDictionary<string, Player>();
        Console.WriteLine("Enter the number of players");
        int n = int.Parse(Console.ReadLine());
        for (int i = 1; i <= n; i++)
        {
            Console.WriteLine("Enter the details of the player {0}", i);
            string cap = Console.ReadLine();
            string name = Console.ReadLine();
            string team = Console.ReadLine();
            string bowler = Console.ReadLine();
            p = new Player(name, team, bowler);
            sd.Add(cap, p);
        }
        Console.WriteLine("Player Details");
        foreach (KeyValuePair<string, Player> val in sd)
        {
            Console.WriteLine("{0}--{1}--{2}--{3}", val.Key, val.Value.Name, val.Value.Team, val.Value.Skill);
        }
        Console.WriteLine("Enter the cap number of the player to be searched");
        string cpp = Console.ReadLine();
        if (sd.ContainsKey(cpp) == true)
        {
            Console.WriteLine("Player Details");
            Console.WriteLine("{0}--{1}--{2}--{3}", cpp, sd[cpp].Name, sd[cpp].Team, sd[cpp].Skill);
        }
        else if (sd.ContainsKey(cpp) == false)
            Console.WriteLine("Player not found");


    }
}