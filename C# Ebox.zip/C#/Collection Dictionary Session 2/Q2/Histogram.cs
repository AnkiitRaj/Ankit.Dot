﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Histogram
{
    //Dictionary<int, int> bins = new Dictionary<int, int>();
    private Dictionary<int, int> bins;

    public Dictionary<int, int> Bins
    {
        get { return bins; }
        set { bins = value; }
    }
    public Histogram()
    {
        bins = new Dictionary<int, int>();
        bins.Add(10, 0);
        bins.Add(20, 0);
        bins.Add(30, 0);
        bins.Add(40, 0);
    }
    public void AddScore(int score)
    {

        if (score <= 10 && score > 0)
            bins[10] += 1;
        else if (score <= 20 && score > 10)
            bins[20] += 1;
        else if (score <= 30 && score > 20)
            bins[30] += 1;
        else bins[40] += 1;
    }
    public void DisplayHistogram()
    {
        Console.WriteLine("Histogram");
        foreach (var v in bins)
        {
            Console.Write(v.Key + " : ");
            int x = bins[v.Key];
            while (x-- > 0)
                Console.Write("*");
            Console.WriteLine();
        }
    }
}