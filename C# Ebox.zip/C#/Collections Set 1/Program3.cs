﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        SortedSet<string> s1=new SortedSet<string>();
		Console.WriteLine("Enter the number of bowlers");
		int n=int.Parse(Console.ReadLine());
		for(int i=0;i<n;i++){
			s1.Add(Console.ReadLine());
		}
		ArrayList l1=new ArrayList(s1);
		Console.WriteLine("Players list in ascending order");
		for(int i=0;i<l1.Count;i++){
            Console.WriteLine(l1[i]);
		}
        Console.ReadKey();
    }
}