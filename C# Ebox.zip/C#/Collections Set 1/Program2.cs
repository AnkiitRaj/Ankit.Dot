﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
      int n=int.Parse(Console.ReadLine());
		SortedSet<string> s1=new SortedSet<string>();
		for(int i=0;i<n;i++){
			s1.Add(Console.ReadLine());
		}
		List<string> l1=new List<string>(s1);
        l1.Sort();
		for(int i=0;i<l1.Count;i++){
            Console.WriteLine(l1[i]);
		}
        Console.ReadKey();
    }
}