﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        //6
        Console.WriteLine("Enter the number of best bowlers in season 4");
        int n = int.Parse(Console.ReadLine());
        List<string> myls = new List<string>();
        Console.WriteLine("Enter the name of players");
        for (int i = 0; i < n; i++)
            myls.Add(Console.ReadLine());
        Console.WriteLine("Enter the number of best bowlers in season 5");
        n = int.Parse(Console.ReadLine());
        List<string> myls1 = new List<string>();
        Console.WriteLine("Enter the name of players");
        for (int i = 0; i < n; i++)
            myls1.Add(Console.ReadLine());
        Console.WriteLine("Player Set 1");
        foreach (string s in myls)
            Console.WriteLine(s);
        Console.WriteLine("Player Set 2");
        foreach (string s1 in myls1)
            Console.WriteLine(s1);

        List<string> l = new List<string>();
        for (int i = 0; i < myls.Count; i++)
        {
            if (!myls1.Contains(myls[i]))
                l.Add(myls[i]);
        }

        Console.WriteLine("Difference");
        foreach (string a in l)
            Console.WriteLine(a);

        Console.ReadKey();
    }
}