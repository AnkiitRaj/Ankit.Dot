﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Index : IComparable<Index>
{
    public char _ch { get; set; }
    public int _count { get; set; }
    public Index() { }
    public Index(char ch, int count)
    {
        _ch = ch;
        _count = count;
    }
    public int CompareTo(Index other)
    {
        return this._ch.CompareTo(other._ch);
    }

    public SortedSet<Index> BuildIndex(HashSet<Player> playerSet)
    {
        SortedSet<Index> sortedIndex = new SortedSet<Index>();
        char[] dupli = new char[playerSet.Count];
        int j = 0;

        foreach (var item in playerSet)
            dupli[j++] = item._name.ElementAt(0);

        for (int i = 0; i < playerSet.Count; i++)
        {
            if (FindIndex(sortedIndex, dupli[i]) != null)
                sortedIndex.Add(new Index(dupli[i], dupli.Where(x => dupli[i] == x).Count()));
        }
        return sortedIndex;
    }

    private Index FindIndex(SortedSet<Index> sortedIndex, char ch)
    {
        Index index = new Index();
        foreach (var item in sortedIndex)
        {
            if (item._ch == ch)
            {
                index = null;
                break;
            }
        }
        return index;
    }

    public void displayIndex(SortedSet<Index> sortedIndex)
    {
        foreach (var item in sortedIndex)
            Console.WriteLine("{0,-14} {1,-15}", item._ch, item._count);
    }
}
