using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class PlayerHashSetIndex
{
    static void Main(string[] args)
    {
        HashSet<Player> playerSet = new HashSet<Player>();
        do
        {
            Console.WriteLine("Enter Player Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Skill:");
            string skill = Console.ReadLine();
            Player newPlayer = new Player(name, skill);
            bool added = playerSet.Add(newPlayer);
            if (!added)
                Console.WriteLine("Player {0} already exist", name);

            Console.WriteLine("Do you want to continue(yes/no):");
        } while (Console.ReadLine().ToLower().Equals("yes"));

        Index indexObj = new Index();
        SortedSet<Index> indexSet = indexObj.BuildIndex(playerSet);
        Console.WriteLine("{0,-14}{1,-15}", "Player", "Index");
        indexObj.displayIndex(indexSet);

        Console.ReadLine();
    }
}
