﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Player
{
    public string _name { get; set; }
    public string _skill { get; set; }
    public Player() { }
    public Player(string name, string skill)
    {
        _name = name;
        _skill = skill;
    }
    public override bool Equals(object obj)
    {
        Player other = (Player)obj;
        return other != null && this._name == other._name ;
    }
    public override int GetHashCode() { return this._name.GetHashCode() ; }
}
