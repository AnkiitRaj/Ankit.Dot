﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Revenue : IComparable<Revenue>
{
    protected string revenueCategory;

    public string RevenueCategory
    {
        get { return revenueCategory; }
        set { revenueCategory = value; }
    }
    protected int amount;

    public int Amount
    {
        get { return amount; }
        set { amount = value; }
    }
    public Revenue()
    {
	    // TODO Auto-generated constructor stub
    }
    public Revenue(string revenueCategory, int amount)
    {
	    this.revenueCategory = revenueCategory;
	    this.amount = amount;
    }
    public override string ToString()
    {
	    return string.Format("{0,-14} {1,-15}", revenueCategory,amount);
    }
    public int CompareTo(Revenue r)
    {
	    return this.amount.CompareTo(r.amount);
    }
}
