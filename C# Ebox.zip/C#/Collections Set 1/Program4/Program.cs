﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        string ans = null;
        SortedSet<Revenue> rs=new SortedSet<Revenue>();
		
		do{
			Revenue r=new Revenue();
			Console.WriteLine("Enter revenue category");
			r.RevenueCategory = (Console.ReadLine());
			Console.WriteLine("Enter revenue amount");
			r.Amount = int.Parse(Console.ReadLine());
			rs.Add(r);
			Console.WriteLine("Do you want to continue(yes/no):");
			ans = Console.ReadLine();
            if(ans.Equals("no"))
				break;
		}while(ans == "yes");
		Console.WriteLine("Top spending categories");
        List<Revenue> ls = new List<Revenue>();
        ls = rs.ToList();
        ls.Sort();
        ls.Reverse();
        int total=0;
        Console.WriteLine("{0,-14} {1,-15}", "Category", "Amount");
        
        foreach (Revenue o in ls) 
        {
            Console.WriteLine(o.ToString());
            total += (int)o.Amount;
        }
        
		Console.WriteLine("Total amount earned: "+total);
        Console.ReadKey();
    }
}