﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
      HashSet<string> s1=new HashSet<string>();
		int n= int.Parse(Console.ReadLine());
		for(int i=0;i<n;i++){
			s1.Add(Console.ReadLine());
		}
        Console.WriteLine(s1.Count());
        
    }
}