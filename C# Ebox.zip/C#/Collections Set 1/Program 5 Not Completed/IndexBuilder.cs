﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class IndexBuilder
{   
    public SortedSet<Index> buildIndex(HashSet<Player> hsp) {
       SortedSet<Index> ts = new SortedSet<Index>();
        foreach (Player p in hsp) {
            char ch = p.Name[0];
            int cnt = 0;
            foreach (Player p1 in hsp) {
                
                if (ch == p1.Name[0]) {
                    cnt++;
                }
                
            }  
            Index indx = new Index(ch, cnt);
            ts.Add(indx);
        }
        
        return ts;
    }
    //private Index findIndex(SortedSet<Index>, char ch)
    //{
    //    return char 
    //}
    
    public void displayIndex(SortedSet<Index> ts) {
        Console.WriteLine(string.Format("{0,-14} {1,-15}", "Player", "Index"));
        foreach (Index i in ts) {
            Console.WriteLine(i.ToString());
        }
        
    }
}