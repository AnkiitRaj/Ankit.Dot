﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        string ans = null;
        HashSet<Player> ps = new HashSet<Player>();
        do
        {
            Player p = new Player();
            Console.WriteLine("Enter Player Name:");
            p.Name = (Console.ReadLine());
            Console.WriteLine("Enter Skill:");
            p.Skill = (Console.ReadLine());
            
            //ps.Add(p);
            if (ps.Add(p) == false)
            {

                Console.WriteLine("Player " + (p.Name + " already exist"));
            }
            Console.WriteLine("Do you want to continue(yes/no):");
            ans = Console.ReadLine();
            if (ans.Equals("no"))
                break;
            
        }
        while (true);
        IndexBuilder ib = new IndexBuilder();
        SortedSet<Index> ts = ib.buildIndex(ps);
        //ib.findIndex(ts);
        ib.displayIndex(ts);
        Console.ReadKey();
    }
}