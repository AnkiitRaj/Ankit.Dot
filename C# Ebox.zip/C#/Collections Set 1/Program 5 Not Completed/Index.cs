﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Index : IComparable<Index>
{
    char _ch;

    public char Ch
    {
        get { return _ch; }
        set { _ch = value; }
    }
    int _count;

    public int Count
    {
        get { return _count; }
        set { _count = value; }
    }

    public Index()
    {
        //  TODO Auto-generated constructor stub
    }

    public Index(char ch, int count)
    {
        this._ch = ch;
        this._count = count;
    }

    public int CompareTo(Index o)
    {
        return this._ch.CompareTo(o.Ch);
    }

    public override string ToString()
    {
        return string.Format("{0,-15} {1,-15}", this._ch, this._count);
    }
}
