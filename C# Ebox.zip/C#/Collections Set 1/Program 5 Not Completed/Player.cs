﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Player
{
    string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    string _skill;

    public string Skill
    {
        get { return _skill; }
        set { _skill = value; }
    }

    public Player()
    {
    }

    public Player(string name, string skill)
    {
        this._name = name;
        this._skill = skill;
    }
    public int hashCode()
    {
        int prime = 31;
        int result = 1;
      // result = ((prime * result) + (this._name == null));
         result = prime * result + ((this._skill == null) ? 0 : this._skill.GetHashCode());
        return result;
    }

    public bool equals(Object obj)
    {
        Player p = ((Player)(obj));
        return this._name.Equals(p.Name);
    }
}
