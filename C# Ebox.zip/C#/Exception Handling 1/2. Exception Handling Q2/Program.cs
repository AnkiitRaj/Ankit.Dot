using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of overs");
        int over = int.Parse(Console.ReadLine());
        try
        {
            if ((over < 0))
            {
                throw new OverflowException();
            }

            int[] runs = new int[over];
            Console.WriteLine("Enter the number of runs for each over");
            for (int i = 0; (i < over); i++)
            {
                runs[i] = int.Parse(Console.ReadLine());
            }

            int overnumber = 0;
            Console.WriteLine("Enter the over number");
            overnumber = int.Parse(Console.ReadLine());
            if ((overnumber > over))
            {
                throw new IndexOutOfRangeException();
            }

            overnumber--;
            for (int i = 0; (i < over); i++)
            {
                if ((overnumber == i))
                {
                    Console.WriteLine(runs[i]);
                    // Console.WriteLine("Runs scored in this over : "+runs[i]);
                    // System.exit(0);
                }

            }

        }
        catch (Exception e)
        {
            if ((e is OverflowException))
            {
                Console.WriteLine("OverflowException");
            }

            if ((e is IndexOutOfRangeException))
            {
                Console.WriteLine("IndexOutOfRangeException");
            }
        }

    }
}


