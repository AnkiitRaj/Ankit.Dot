using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of players");
        int np = int.Parse(Console.ReadLine());
        Console.WriteLine("Do you know the details of the captain? Type Yes / No");
        string captainInfo = Console.ReadLine();
        Player[] p = new Player[np];
        //string skill;
        //string name;
        //string country;
        bool flag = true;
        //int v = 0;
        Player cap = new Player();
        if (captainInfo == ("yes") || captainInfo == ("Yes") || captainInfo == ("YES"))
        {
            cap = new Player();
            Console.WriteLine("Enter name of the captain");
            cap.Name = (Console.ReadLine());
            Console.WriteLine("Enter country of the captain");
            cap.Country =(Console.ReadLine());
            Console.WriteLine("Enter skillset of the captain");
            cap.Skill = (Console.ReadLine());
            flag = false;
            //v = 10;
        }
        
        for (int i = 0; (i < np); i++) {
            p[i] = new Player();
            Console.WriteLine(("Enter name of player " 
                            + (i + 1)));
            p[i].Name = (Console.ReadLine());
            Console.WriteLine(("Enter country of player " 
                            + (i + 1)));
            p[i].Country = (Console.ReadLine());
            Console.WriteLine(("Enter skillset of player " 
                            + (i + 1)));
            p[i].Skill = (Console.ReadLine());
        }
        
        // }
        PlayerBO pbo = new PlayerBO();
        pbo.DisplayPlayerDetails(cap, p, flag);
        Console.ReadKey();
    }
}


