﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PlayerBO
{
    public void DisplayPlayerDetails(Player cap, Player[] p, bool flag)
    {
        if (!flag)
        {
            Console.WriteLine(cap);
            Console.WriteLine("Player Details");
            for (int i = 0; i < p.Length; i++) {
                Console.WriteLine(p[i].ToString());
            }
            
        }
        else {
            Console.WriteLine("Exception Occured : NullReferenceException");
            Console.WriteLine("Captain details not available");
            Console.WriteLine("Player Details");
            for (int i = 0; i < p.Length; i++)
            {
                Console.WriteLine(p[i].ToString());
            }
            
        }
        
    }
}