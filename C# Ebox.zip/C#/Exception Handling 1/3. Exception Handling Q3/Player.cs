﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Player
{
    private string name;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    private string country;

    public string Country
    {
        get { return country; }
        set { country = value; }
    }
    private string skill;

    public string Skill
    {
        get { return skill; }
        set { skill = value; }
    }
    

    public Player()
    {
        //  TODO Auto-generated constructor stub
    }

    public Player(string name, string country, string skill)
    {
        this.name = name;
        this.country = country;
        this.skill = skill;
    }

    public override string ToString()
    {
        return (this.name + (", " + (this.country + (", " + this.skill))));
    }
}