using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
	{
        float over = 0;
        float runs = 0;
        try {
            Console.WriteLine("Enter the total runs scored");
            runs = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the total overs faced");
            over = float.Parse(Console.ReadLine());
        }
        catch (FormatException e) {
            Console.WriteLine("FormatException");
            System.Environment.Exit(0);
        }
        catch (Exception e)
        {
            //  TODO: handle exception
        }
        
        try {
            if (over == 0) {
                throw new ArithmeticException();
            }
            
            float res = (runs / over);
            Console.WriteLine("Current Run Rate : {0:0.00}", res);
        }
        catch (ArithmeticException e)
        {
            Console.WriteLine("DivideByZeroException");
        }
        Console.ReadKey();
   }

}


