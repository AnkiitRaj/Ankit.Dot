using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
    {
        try {
            Player p = new Player();
            if ((p is Player)) {
                throw new MissingMethodException();
            }
            
        }
        catch (MissingMethodException e) {
            Console.WriteLine("Trying to invoke a no-argument constructor (that is not available) using CreateInstance method");
            Console.WriteLine("Exception Occured : MissingMethodException");
        }
        
        Console.WriteLine("Enter name of the player");
        string name = Console.ReadLine();
        Console.WriteLine("Enter country of the player");
        string country = Console.ReadLine();
        Console.WriteLine("Enter skillset of the player");
        string skill = Console.ReadLine();
        Player pp = new Player(name, country, skill);
        Console.WriteLine(pp);
        Console.ReadKey();
    }
}


