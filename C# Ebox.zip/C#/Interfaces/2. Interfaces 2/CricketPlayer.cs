﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class CricketPlayer : Player, IPlayerStatistics
{

    private long _totalRunsScored;

    public long TotalRunsScored
    {
        get { return _totalRunsScored; }
        set { _totalRunsScored = value; }
    }
    private long _noOfWicketsTaken;

    public long NoOfWicketsTaken
    {
        get { return _noOfWicketsTaken; }
        set { _noOfWicketsTaken = value; }
    }

    public CricketPlayer(string name, string team, long matches, long totalRunsScored, long noOfWicketsTaken) :
        base(name, team, matches)
    {
        this._totalRunsScored = totalRunsScored;
        this._noOfWicketsTaken = noOfWicketsTaken;
    }

    public new void DisplayPlayerStatistics() {
        Console.WriteLine("Player Details");
        Console.WriteLine("Player name : " + base.Name);
        Console.WriteLine("Team name : " + base.TeamName);
        Console.WriteLine("No of matches : " + base.NoOfMatches);
        Console.WriteLine("Total runsscored : " + this._totalRunsScored);
        Console.WriteLine("No of wickets taken : " + this._noOfWicketsTaken);
    }
}