﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class HockeyPlayer : Player, IPlayerStatistics
{
    private string _position;

    public string Position
    {
        get { return _position; }
        set { _position = value; }
    }
    private long _noOfGoals;

    public long NoOfGoals
    {
        get { return _noOfGoals; }
        set { _noOfGoals = value; }
    }

    public HockeyPlayer(string name, string teamName, long noOfMatches, string position, long noOfGoals) :
        base(name, teamName, noOfMatches)
    {
        this._position = position;
        this._noOfGoals = noOfGoals;
    }

    
    public new void DisplayPlayerStatistics() {
        Console.WriteLine("Player Details");
        Console.WriteLine("Player name : " + base.Name);
        Console.WriteLine("Team name : " + base.TeamName);
        Console.WriteLine("No of matches : " + base.NoOfMatches);
        Console.WriteLine("Position : " + this._position);
        Console.WriteLine("No of goals taken : " + this._noOfGoals);
    }
}
