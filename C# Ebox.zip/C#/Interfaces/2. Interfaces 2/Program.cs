using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{
        Console.WriteLine("Menu");
        Console.WriteLine("1.Crciket Player Details");
        Console.WriteLine("2.Hockey Player Details");
        Console.WriteLine("Enter choice");
        int choice = int.Parse(Console.ReadLine());
        if ((choice == 1)) {
            Console.WriteLine("Enter player name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter team name");
            string team = Console.ReadLine();
            Console.WriteLine("Enter number of matches played");
            long matches = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter total runs scored");
            long runs = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter total number of wickets taken");
            long wickets = long.Parse(Console.ReadLine());
            CricketPlayer p = new CricketPlayer(name, team, matches, runs, wickets);
            p.DisplayPlayerStatistics();
        }
        else if ((choice == 2)) {
            Console.WriteLine("Enter player name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter team name");
            string team = Console.ReadLine();
            Console.WriteLine("Enter number of matches played");
            long matches = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter the position");
            string position = Console.ReadLine();
            Console.WriteLine("Enter total number of goals taken");
            long goals = long.Parse(Console.ReadLine());
            HockeyPlayer p = new HockeyPlayer(name, team, matches, position, goals);
            p.DisplayPlayerStatistics();
        }
        else
        {
            Console.WriteLine("Invalid Input");
        }
	}
       
	

}


