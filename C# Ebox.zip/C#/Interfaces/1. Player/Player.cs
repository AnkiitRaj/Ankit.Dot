﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Player : IPlayerStatistics {
    
    private string name;
    private string teamName;
    private int noOfMatches;
    private long totalRunsScored;
    private int noOfWicketsTaken;
    
    public Player()
    {
       
    }
    
    public Player(string name, string teamName, int noOfMatches, long totalRunsScored, int noOfWicketsTaken) : 
            base()
    {
        this.name = name;
        this.teamName = teamName;
        this.noOfMatches = noOfMatches;
        this.totalRunsScored = totalRunsScored;
        this.noOfWicketsTaken = noOfWicketsTaken;
    }
    
    public void displayPlayerStatistics() {
        Console.WriteLine("Player Details");
        Console.WriteLine("Player name : " + this.name);
        Console.WriteLine("Team name : " + this.teamName);
        Console.WriteLine("No of matches : " + this.noOfMatches);
        Console.WriteLine("Total runsscored : " + this.totalRunsScored);
        Console.WriteLine("No of wickets taken : " + this.noOfWicketsTaken);
    }
}
