using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{   
        Console.WriteLine("Enter player name");
        string name = Console.ReadLine();
        Console.WriteLine("Enter team name");
        string team = Console.ReadLine();
        Console.WriteLine("Enter number of matches played");
        int matches = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter total runs scored");
        long runs = long.Parse(Console.ReadLine());
        Console.WriteLine("Enter number of wickets taken");
        int wickets = int.Parse(Console.ReadLine());
        Player p = new Player(name, team, matches, runs, wickets);
        p.displayPlayerStatistics();
	}
       
	

}


