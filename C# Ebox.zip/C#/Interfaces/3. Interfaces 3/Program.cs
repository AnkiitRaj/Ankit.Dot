using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    public static void Main(string[] args)
	{
        string ans = "YES";
       here: do {
            Console.WriteLine("Menu");
            Console.WriteLine("1.Bowler");
            Console.WriteLine("2.Batsman");
            Console.WriteLine("3.WicketKeeper");
            Console.WriteLine("4.AllRounder");
            Console.WriteLine("Enter your choice");
            int choice = int.Parse(Console.ReadLine());
            switch (choice) {
                case 1:
                    Console.WriteLine("Enter the Bowler details");
                    Console.WriteLine("Enter player name");
                    string name1 = Console.ReadLine();
                    Console.WriteLine("Enter team name");
                    string team1 = Console.ReadLine();
                    Console.WriteLine("Enter number of matches played");
                    int matches1 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter number of wickets taken");
                    int wickets1 = int.Parse(Console.ReadLine());
                    Bowler cp1 = new Bowler(name1, team1, matches1, wickets1);
                    cp1.DisplayPlayerStatistics();
                    break;
                case 2:
                    Console.WriteLine("Enter the Batsman details");
                    Console.WriteLine("Enter player name");
                    string name2 = Console.ReadLine();
                    Console.WriteLine("Enter team name");
                    string team2 = Console.ReadLine();
                    Console.WriteLine("Enter number of matches played");
                    int matches2 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the runs scored");
                    int runs2 = int.Parse(Console.ReadLine());
                    Batsman cp2 = new Batsman(name2, team2, matches2, runs2);
                    cp2.DisplayPlayerStatistics();
                    break;
                case 3:
                    Console.WriteLine("Enter the WicketKeeper details");
                    Console.WriteLine("Enter player name");
                    string name3 = Console.ReadLine();
                    Console.WriteLine("Enter team name");
                    string team3 = Console.ReadLine();
                    Console.WriteLine("Enter number of matches played");
                    int matches3 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter number of catches taken");
                    int catches3 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter number of stumpings");
                    int stumpings3 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter number of dismissals");
                    int dismissals3 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the runs scored");
                    int runs3 = int.Parse(Console.ReadLine());
                    WicketKeeper cp3 = new WicketKeeper(name3, team3, matches3, catches3, stumpings3, dismissals3, runs3);
                    cp3.DisplayPlayerStatistics();
                    break;
                case 4:
                    Console.WriteLine("Enter the AllRounder details");
                    Console.WriteLine("Enter player name");
                    string name4 = Console.ReadLine();
                    Console.WriteLine("Enter team name");
                    string team4 = Console.ReadLine();
                    Console.WriteLine("Enter number of matches played");
                    int matches4 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the runs scored");
                    int runs4 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter number of wickets taken");
                    int wickets4 = int.Parse(Console.ReadLine());
                    AllRounder cp4 = new AllRounder(name4, team4, matches4, runs4, wickets4);
                    cp4.DisplayPlayerStatistics();
                    break;
                    default:
                    Console.WriteLine("Please Enter a Valid Input");
                    goto here;
                    //break;
            }
            Console.WriteLine("Do you want to continue?");
            ans = Console.ReadLine();
            
            
        } while (ans=="YES" || ans=="yes");
    }
}


