﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class AllRounder : CricketPlayer, IPlayerStatistics
{

    private int _runs;

    public int Runs
    {
        get { return _runs; }
        set { _runs = value; }
    }
    private int _noOfWickets;

    public int NoOfWickets
    {
        get { return _noOfWickets; }
        set { _noOfWickets = value; }
    }

    public AllRounder(string name, string teamName, int noOfMatches, int runs, int noOfWickets) :
        base(name, teamName, noOfMatches)
    {
        this._runs = runs;
        this._noOfWickets = noOfWickets;
    }
    public new void DisplayPlayerStatistics()
    {
        Console.WriteLine("Player name : " + Name);
        Console.WriteLine("Team name : " + TeamName);
        Console.WriteLine("No of matches : " + NoOfMatches);
        Console.WriteLine("Runs scored : " + this._runs);
        Console.WriteLine("No of wickets taken : " + this._noOfWickets);
    }
}