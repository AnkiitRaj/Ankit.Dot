﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class WicketKeeper : CricketPlayer, IPlayerStatistics
{

    private int _noOfCatches;

    public int NoOfCatches
    {
        get { return _noOfCatches; }
        set { _noOfCatches = value; }
    }
    private int _noOfStumpings;

    public int NoOfStumpings
    {
        get { return _noOfStumpings; }
        set { _noOfStumpings = value; }
    }
    private int _runs;

    public int Runs
    {
        get { return _runs; }
        set { _runs = value; }
    }
    private int _noOfDismissals;

    public int NoOfDismissals
    {
        get { return _noOfDismissals; }
        set { _noOfDismissals = value; }
    }

    public WicketKeeper(string name, string teamName, int noOfMatches, int noOfCatches, int noOfStumpings, int runs, int noOfDismissals) :
        base(name, teamName, noOfMatches) {
        this._noOfCatches = noOfCatches;
        this._noOfStumpings = noOfStumpings;
        this._runs = runs;
        this._noOfDismissals = noOfDismissals;
    }

    public new void DisplayPlayerStatistics() {
        Console.WriteLine("Player name : " + base.Name);
        Console.WriteLine("Team name : " + base.TeamName);
        Console.WriteLine("No of matches : " + base.NoOfMatches);
        Console.WriteLine("No of catches taken : " + this._noOfCatches);
        Console.WriteLine("No of stumpings : " + this._noOfStumpings);
        Console.WriteLine("No of dismissals : " + this._runs);
        Console.WriteLine("Runs scored : " + this._noOfDismissals);
    }
}