﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Bowler : CricketPlayer, IPlayerStatistics
{

    private int _noOfWickets;

    public int NoOfWickets
    {
        get { return _noOfWickets; }
        set { _noOfWickets = value; }
    }

    public Bowler(string name, string teamName, int noOfMatches, int noOfWickets) :
        base(name, teamName, noOfMatches) 
    {
        this._noOfWickets = noOfWickets;
    }

    public new void DisplayPlayerStatistics() {
        Console.WriteLine("Player name : " + base.Name);
        Console.WriteLine("Team name : " + base.TeamName);
        Console.WriteLine("No of matches : " + base.NoOfMatches);
        Console.WriteLine("No of wickets taken : " + this._noOfWickets);
    }
}