﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Batsman : CricketPlayer, IPlayerStatistics
{
    private int _runs;
    public int Runs
    {
        get { return _runs; }
        set { _runs = value; }
    }
    public Batsman(string name, string teamName, int noOfMatches, int runs) :
        base(name, teamName, noOfMatches)
    {
        this._runs = runs;
    }
    public new void DisplayPlayerStatistics() {
        Console.WriteLine("Player name : " + base.Name);
        Console.WriteLine("Team name : " + base.TeamName);
        Console.WriteLine("No of matches : " + base.NoOfMatches);
        Console.WriteLine("Runs scored : " + this._runs);
    }
}