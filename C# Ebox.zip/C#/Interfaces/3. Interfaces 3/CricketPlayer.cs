﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class CricketPlayer
{
    private string _name;

    protected string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    private string _teamName;

    protected string TeamName
    {
        get { return _teamName; }
        set { _teamName = value; }
    }
    private int _noOfMatches;

    protected int NoOfMatches
    {
        get { return _noOfMatches; }
        set { _noOfMatches = value; }
    }

    public CricketPlayer(string name, string teamName, int noOfMatches)
    {
        this._name = name;
        this._teamName = teamName;
        this._noOfMatches = noOfMatches;
    }

    public void DisplayPlayerStatistics()
    {

    }
}