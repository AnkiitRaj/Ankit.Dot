﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static void Main(string[] args)
    {
        ArrayList myList = new ArrayList();
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
            myList.Add(int.Parse(Console.ReadLine()));
        int sum = 0;
        for (int i = 0; i < myList.Count; i++)
        {
            if (i % 2 != 0)
            {
                if ((int)myList[i] % 2 != 0)
                {
                    sum += (int)myList[i];
                }
            }
            else if (i % 2 == 0)
            {
                if ((int)myList[i] % 2 == 0)
                    sum += (int)myList[i];
            }
            }
            Console.WriteLine(sum);
            Console.ReadKey();


        }

    }