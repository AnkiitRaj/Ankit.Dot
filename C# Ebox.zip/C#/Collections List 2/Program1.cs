﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Program
    {
      public static void Main(string[] args) 
      {
          int n = int.Parse(Console.ReadLine());
          List<string> myList = new List<string>();
          for (int i = 0; i <n; i++)
              myList.Add(Console.ReadLine());

          string ans = "Yes";
          do
          {
              Console.WriteLine("Menu\n1.Insert Players\n2.Delete Players");
              int ch = int.Parse(Console.ReadLine());
              switch (ch) 
              {
                  case 1:
                      myList.Add(Console.ReadLine());
                      Console.WriteLine("Player details after insertion");
                      foreach (string ss in myList)
                          Console.WriteLine(ss);
                      break;
                  case 2:
                      string s = Console.ReadLine();
                      for (int i = 0; i < myList.Count;i++ )
                          if (s == myList[i].ToString())
                          {
                              myList.Remove(s);
                          }
                      Console.WriteLine("Player details after deletion");
                      foreach (string ss in myList)
                          Console.WriteLine(ss);
                      break;
              }
              Console.WriteLine("Do you want to continue");
              ans = Console.ReadLine();
          } while (ans == "Yes");
          // 2 int n = int.Parse(Console.ReadLine());
          //List<int> myList = new List<int>();
          //for (int i = 0; i < n; i++)
          //    myList.Add(int.Parse(Console.ReadLine()));
          //int sum = 0;
          //for (int i = 0; i < myList.Count; i++) 
          //{
          //    if (i % 2!= 0)
          //        sum += (int)myList[i];
          //}
          //Console.WriteLine(sum);
          // 3 int n = int.Parse(Console.ReadLine());
          //List<int> myList = new List<int>();
          //for (int i = 0; i < n; i++)
          //    myList.Add(int.Parse(Console.ReadLine()));
          //int f = 0, c = 0;
          //foreach (int s in myList)
          //{
          //    if (s >= 50 && s < 100)
          //        f++;
          //    if (s >= 100)
          //        c++;
          //}
          //Console.WriteLine(f+"\n"+c);
          // 4 string s = Console.ReadLine();
          //List<char> myList = new List<char>();
          //for (int i = 0; i < s.Length; i++)
          //{
          //    char ch = s[i];
          //    myList.Add(ch);
          //}
          //myList.Reverse();
          //foreach(char c in myList)
          //    Console.WriteLine(c);
          // 5 ArrayList myList = new ArrayList();
          //int n = int.Parse(Console.ReadLine());
          //for (int i = 0; i < n; i++)
          //    myList.Add(int.Parse(Console.ReadLine()));
          //int sum = 0;
          //for (int i = 0; i < myList.Count; i++) 
          //{
          //    if (i % 2 != 0)
          //    {
          //        if ((int)myList[i] % 2 != 0)
          //        {
          //            sum += (int)myList[i];
          //        }
          //    }
          //    else if (i % 2 == 0) 
          //    {
          //        if ((int)myList[i] % 2 == 0)
          //            sum += (int)myList[i];
          //    }
          ////}
          //Console.WriteLine(sum);
              Console.ReadKey();
      }

    }

