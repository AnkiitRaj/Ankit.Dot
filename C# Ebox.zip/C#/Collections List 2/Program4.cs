﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Program
    {
      public static void Main(string[] args) 
      {
          string s = Console.ReadLine();
          List<char> myList = new List<char>();
          for (int i = 0; i < s.Length; i++)
          {
              char ch = s[i];
              myList.Add(ch);
          }
          myList.Reverse();
          foreach(char c in myList)
              Console.WriteLine(c);
          // 5 ArrayList myList = new ArrayList();
          //int n = int.Parse(Console.ReadLine());
          //for (int i = 0; i < n; i++)
          //    myList.Add(int.Parse(Console.ReadLine()));
          //int sum = 0;
          //for (int i = 0; i < myList.Count; i++) 
          //{
          //    if (i % 2 != 0)
          //    {
          //        if ((int)myList[i] % 2 != 0)
          //        {
          //            sum += (int)myList[i];
          //        }
          //    }
          //    else if (i % 2 == 0) 
          //    {
          //        if ((int)myList[i] % 2 == 0)
          //            sum += (int)myList[i];
          //    }
          ////}
          //Console.WriteLine(sum);
              Console.ReadKey();


      }

    }