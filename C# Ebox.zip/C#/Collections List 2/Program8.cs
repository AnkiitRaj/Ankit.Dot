﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
      List<string> l1 = new List<string>();
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; (i < n); i++) {
            l1.Add(Console.ReadLine());
        }
        
        int count = 0;
        for (int i = 0; (i < n); i++) {
            string[] str = l1[i].Split('-');
            if ((str[1].Equals("0") && str[2].Equals("0"))) {
                Console.WriteLine(str[0]);
            }
            else {
                count++;
            }
            
        }
        
        if ((count == n)) {
            Console.WriteLine("No player has scored a duck");
        }
        
    }
}