﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  class Program
    {
      public static void Main(string[] args) 
      {
          int n = int.Parse(Console.ReadLine());
          List<int> myList = new List<int>();
          for (int i = 0; i < n; i++)
              myList.Add(int.Parse(Console.ReadLine()));
          int f = 0, c = 0;
          foreach (int s in myList)
          {
              if (s >= 50 && s < 100)
                  f++;
              if (s >= 100)
                  c++;
          }
          Console.WriteLine(f+"\n"+c);
          // 4 string s = Console.ReadLine();
          //List<char> myList = new List<char>();
          //for (int i = 0; i < s.Length; i++)
          //{
          //    char ch = s[i];
          //    myList.Add(ch);
          //}
          //myList.Reverse();
          //foreach(char c in myList)
          //    Console.WriteLine(c);
          // 5 ArrayList myList = new ArrayList();
          //int n = int.Parse(Console.ReadLine());
          //for (int i = 0; i < n; i++)
          //    myList.Add(int.Parse(Console.ReadLine()));
          //int sum = 0;
          //for (int i = 0; i < myList.Count; i++) 
          //{
          //    if (i % 2 != 0)
          //    {
          //        if ((int)myList[i] % 2 != 0)
          //        {
          //            sum += (int)myList[i];
          //        }
          //    }
          //    else if (i % 2 == 0) 
          //    {
          //        if ((int)myList[i] % 2 == 0)
          //            sum += (int)myList[i];
          //    }
          ////}
          //Console.WriteLine(sum);
              Console.ReadKey();


      }

    }

// Q2 List 2
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;


//class Program
//{
//    static void Main(string[] args)
//    {
//        int n = int.Parse(Console.ReadLine());
//        List<int> n1 = new List<int>();
//        for (int i = 0; i < n; i++)
//        {
//            n1.Add(int.Parse(Console.ReadLine()));
//        }
//        n1.Sort();
        
//        foreach (int s in n1)
//        {
//            Console.WriteLine(s);
//        }
        
//    }
//}
