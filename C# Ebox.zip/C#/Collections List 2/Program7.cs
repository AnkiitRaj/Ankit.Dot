﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
      Console.WriteLine("Enter the number of matches");
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the runs scored by the team");
        List<int> l1 = new List<int>();
        for (int i = 0; (i < n); i++)
        {
            l1.Add(int.Parse(Console.ReadLine()));
        }
        
        int count = 0;
        bool flag = false;
        for (int i = 0; (i < n); i++) {
            flag = false;
            // count=0;
            for (int j = 2; (j 
                        < (l1[i] / 2)); j++) {
                if (((l1[i] % j) 
                            == 0)) {
                    flag = true;
                    // count++;
                    break;
                }
                
            }
            
            if (!flag) {
                count++;
            }
            
        }
        
        Console.WriteLine("Number of prime scores : " + count);
        
    }
}