using System;
using System.Collections.Generic;  
public class TestMatch:Match{

    public TestMatch() { }
    public TestMatch(int _currentScore, float _currentOver, int _target)
        : base(_currentScore, _currentOver, _target) { }
	public override float calculateRunrate() 
    {
        int score = base.Target - base.CurrentScore;
        float ovr = 90 - base.CurrentOver;

        return score / ovr;
	}

	public override int calculateBalls() 
    {
        return (90 - (int)base.CurrentOver) * 6;
	}

}


