using System;
using System.Collections.Generic;
public abstract class Match {
	private int _currentScore;
	private float _currentOver;
	private int _target;
	public int CurrentScore
	{
		get
		{
		return this._currentScore;
		}
		set
		{
		this._currentScore=value;
		}
	}
	public float CurrentOver
	{
		get
		{
		return this._currentOver;
		}
		set
		{
		this._currentOver=value;
		}
	}
	public int Target
	{
		get
		{
		return this._target;
		}
		set
		{
		this._target=value;
		}
	}
    public Match() { }
    public Match(int _currentScore, float _currentOver, int _target) 
    {
        this.CurrentScore = _currentScore;
        this.CurrentOver = _currentOver;
        this.Target = _target;
    }

	
	public abstract float calculateRunrate();
	
	public abstract int calculateBalls();
	
	public void display(double reqRunRate,int balls){	
		Console.WriteLine("Requirements:");
		Console.WriteLine("Need " +(this._target -this. _currentScore)+(balls > 1 ? " Runs" : " Run" )+" in "+balls+(balls > 1 ? " balls" : " ball" ));		

		Console.Write("Required Run Rate - "); 
		Console.Write(string.Format("{0:0.00}",reqRunRate));
		Console.WriteLine();
	}

}


