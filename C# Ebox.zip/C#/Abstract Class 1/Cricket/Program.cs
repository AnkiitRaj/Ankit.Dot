using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{

		Console.WriteLine("Enter the Cricket Format");
		Console.WriteLine("1.ODI");
		Console.WriteLine("2.T20");
		Console.WriteLine("3.Test");
        int ch = int.Parse(Console.ReadLine());
        switch(ch)
        {
            case 1:
                Console.WriteLine("Enter the Current Score");
                int crun = int.Parse(Console.ReadLine());
	            Console.WriteLine("Enter the Current Over");
                float ovr = float.Parse(Console.ReadLine());
	            Console.WriteLine("Enter the Target Score");
                int tscore = int.Parse(Console.ReadLine());
                ODIMatch o = new ODIMatch(crun,ovr,tscore);
                double a = o.calculateRunrate();
                int b = o.calculateBalls();
                o.display(a, b);
                break;
            case 2:
                Console.WriteLine("Enter the Current Score");
                int run = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Current Over");
                float ov = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Target Score");
                int ts = int.Parse(Console.ReadLine());
                T20Match t = new T20Match(run, ov, ts);
                double x = t.calculateRunrate();
                int y = t.calculateBalls();
                t.display(x, y);
                break;
            case 3:
                Console.WriteLine("Enter the Current Score");
                int r = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Current Over");
                float or = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Target Score");
                int tsc = int.Parse(Console.ReadLine());
                TestMatch tm = new TestMatch(r, or, tsc);
                double c = tm.calculateRunrate();
                int d = tm.calculateBalls();
                tm.display(c, d);
                break;
            default:
                Console.WriteLine("Invalid Format type");
                break;
        }
        Console.ReadLine();
	}
       
	

}


