using System;
using System.Collections.Generic;  
public class ODIMatch:Match{


    public ODIMatch() { }
    public ODIMatch(int _currentScore, float _currentOver, int _target)
        : base(_currentScore, _currentOver, _target)
    {

    }

    public override float calculateRunrate() 
    {
        int score = base.Target-base.CurrentScore;
        float ovr = 50-base.CurrentOver;

        return score / ovr;
            
	}

	public override int calculateBalls() 
    {
        return (50 - (int)base.CurrentOver)*6 ;
	}

}


