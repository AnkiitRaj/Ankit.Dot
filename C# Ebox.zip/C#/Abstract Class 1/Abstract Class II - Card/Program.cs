using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{
		Console.WriteLine("Select the Card");
        Console.WriteLine("1.Payback Card");
        Console.WriteLine("2.Membership Card");
        int selCard = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the Card Details:");
        string[] dataList1 = Console.ReadLine().Split('|');
        string holderName = dataList1[0];
        string cardNumber = dataList1[1];
        string expiryDate = dataList1[2];
        string[] ed1 = dataList1[2].Split('/');
        if ((selCard == 1)) {
            Console.WriteLine("Enter points in card");
            int points = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Amount");
            double amt = double.Parse(Console.ReadLine());
            PaybackCard payIns = new PaybackCard(holderName, cardNumber, expiryDate, points, amt);
            Console.WriteLine(holderName + "'s Payback Card Details:");
            Console.WriteLine("Card Number " + cardNumber);
            Console.WriteLine("Points Earned " + payIns.PointsEarned);
            Console.WriteLine("Total Amount {0:0.0}" ,payIns.TotalAmount);
        }
        else if ((selCard == 2)) {
            Console.WriteLine("Enter rating in card");
            int rating = int.Parse(Console.ReadLine());
            MembershipCard memIns = new MembershipCard(holderName, cardNumber, expiryDate, rating);
            Console.WriteLine(holderName + "'s Membership Card Details:");
            Console.WriteLine("Card Number " +cardNumber );
            Console.WriteLine("Rating " + memIns.Rating);
        }
        else {
            Console.WriteLine("Invalid card");
        }
        Console.ReadKey();
}	
}