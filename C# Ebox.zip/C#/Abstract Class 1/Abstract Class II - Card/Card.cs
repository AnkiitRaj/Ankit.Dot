﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class Card
{

    private string _holderName;

    protected string HolderName
    {
        get { return _holderName; }
        set { _holderName = value; }
    }
    private string _cardNumber;

    protected string CardNumber
    {
        get { return _cardNumber; }
        set { _cardNumber = value; }
    }
    private string _expiryDate;

    protected string ExpiryDate
    {
        get { return _expiryDate; }
        set { _expiryDate = value; }
    }

    

    public Card()
    {
        //  TODO Auto-generated constructor stub
    }

    public Card(string holderName, string cardNumber, string expiryDate) :
        base() {
        this._holderName = holderName;
        this._cardNumber = cardNumber;
        this._expiryDate = expiryDate;
    }
}
