﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PaybackCard : Card
{

    private int _pointsEarned;

    public int PointsEarned
    {
        get { return _pointsEarned; }
        set { _pointsEarned = value; }
    }

    private double _totalAmount;

    public double TotalAmount
    {
        get { return _totalAmount; }
        set { _totalAmount = value; }
    }

    public PaybackCard(string holderName, string cardNumber, string expiryDate, int pointsEarned, double totalAmount) :
        base(holderName, cardNumber, expiryDate) {
        this._pointsEarned = pointsEarned;
        this._totalAmount = totalAmount;
    }
    
}