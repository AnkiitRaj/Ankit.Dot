﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class MembershipCard : Card
{

    private int _rating;

    public int Rating
    {
        get { return _rating; }
        set { _rating = value; }
    }

    public MembershipCard(string holderName, string cardNumber, string expiryDate, int rating) :
        base(holderName, cardNumber, expiryDate)
    {    
        this._rating = rating;
    }

    
}