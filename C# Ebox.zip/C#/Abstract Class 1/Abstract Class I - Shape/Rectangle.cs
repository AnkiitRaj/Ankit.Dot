﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Rectangle : Shape
{

    private int _length;

    public int Length
    {
        get { return _length; }
        set { _length = value; }
    }

    private int _breadth;

    public int Breadth
    {
        get { return _breadth; }
        set { _breadth = value; }
    }

    public Rectangle(string name, int length, int breadth) :
        base("Square") {
        this._length = length;
        this._breadth = breadth;
    }

    public override float CalculateArea()
    {
        return (this._length * this._breadth);
    }
}