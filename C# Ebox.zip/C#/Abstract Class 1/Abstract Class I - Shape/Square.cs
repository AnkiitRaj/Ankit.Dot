﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Square : Shape
{

    private int _side;

    public int Side
    {
        get { return _side; }
        set { _side = value; }
    }

    public Square(string name, int side) :
        base("Square") {
        this._side = side;
    }
    public override float CalculateArea()
    {
        return (this._side * this._side);
    }
}
