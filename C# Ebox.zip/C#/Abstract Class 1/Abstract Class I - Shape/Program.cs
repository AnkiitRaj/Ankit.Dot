using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{
	Console.WriteLine("Circle");
        Console.WriteLine("Square");
        Console.WriteLine("Rectangle");
        Console.WriteLine("Enter the shape name");
        string shapeName = Console.ReadLine();
        float area;
        if(shapeName.ToLower().Equals("circle")){
            Console.WriteLine("Enter the radius");
            int radius = int.Parse(Console.ReadLine());
            Circle cirIns = new Circle(shapeName,radius);
            area = cirIns.CalculateArea();
            Console.WriteLine("Area of Circle is {0:0.00}",area);
        }else if(shapeName.ToLower().Equals("square")){
            Console.WriteLine("Enter the side");
            int side = int.Parse(Console.ReadLine());
            Square sqIns = new Square(shapeName,side);
            area = sqIns.CalculateArea();
            Console.Write("Area of Square is {0:0.00}",area);
        }else if(shapeName.ToLower().Equals("rectangle")){
            Console.WriteLine("Enter the length");
            int length = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the breadth");
            int breath = int.Parse(Console.ReadLine());
            Rectangle recIns = new Rectangle(shapeName,length,breath);
            area = recIns.CalculateArea();
            Console.Write("Area of Rectangle is {0:0.00}",area);
        }else{
            Console.WriteLine("Invalid shape");
        }
        Console.ReadKey();
}	
}