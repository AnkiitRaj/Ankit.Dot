﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Match
{

    public void displayMatchDetails(DateTime matchDate)
    {
        string d = Convert.ToDateTime(matchDate).ToString("MM-dd-yyyy");
        Console.WriteLine("Match Date : " + d);
    }

     public void displayMatchDetails(string venue)
    {
        Console.WriteLine("Match Venue :");
        string[] str = venue.Split(',');
        Console.WriteLine(("Stadium : " + str[0]));
        Console.WriteLine(("City : " + str[1]));
    }

    public void displayMatchDetails(string winnerTeam, long runs)
    {
        Console.WriteLine("Match Outcome :");
        Console.WriteLine((winnerTeam + (" won by " + (runs + " runs"))));
    }
}