﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Menu");
        Console.WriteLine("1.Match Date");
        Console.WriteLine("2.Match Venue");
        Console.WriteLine("3.Match Outcome");
        int choice = int.Parse(Console.ReadLine());
        if ((choice == 1)) {
            Console.WriteLine("Enter the date of the match");
            //SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            DateTime d = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
            Match m = new Match();
            m.displayMatchDetails(d);
        }
        
        if ((choice == 2)) {
            Console.WriteLine("Enter venue of the match");
            string venue = Console.ReadLine();
            Match m = new Match();
            m.displayMatchDetails(venue);
        }
        
        if ((choice == 3)) {
            Console.WriteLine("Enter the winner team of the match");
            Match m = new Match();
            string winnerTeam = Console.ReadLine();
            Console.WriteLine("Enter the number of runs");
            long runs = long.Parse(Console.ReadLine());
            m.displayMatchDetails(winnerTeam, runs);
        }
        Console.ReadKey();
    }
}