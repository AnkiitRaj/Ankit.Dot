﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter player name");
        string name = Console.ReadLine();
        Console.WriteLine("Enter team name");
        string team = Console.ReadLine();
        Console.WriteLine("Enter number of matches");
        long matches = long.Parse(Console.ReadLine());
        Console.WriteLine("Menu");
        Console.WriteLine("1.Bowler details");
        Console.WriteLine("2.Batsman details");
        Console.WriteLine("Enter choice");
        int choice = int.Parse(Console.ReadLine());
        if ((choice == 1)) {
            Console.WriteLine("Enter number of wicktes taken");
            long noOfWickets = long.Parse(Console.ReadLine());
            Bowler p = new Bowler(name, team, matches, noOfWickets);
            p.DisplayDetails();
        }
        
        if ((choice == 2)) {
            Console.WriteLine("Enter number of runs scored");
            long noOfRuns = long.Parse(Console.ReadLine());
            Batsman p = new Batsman(name, team, matches, noOfRuns);
            p.DisplayDetails();
        }
        Console.ReadKey();
    }
}