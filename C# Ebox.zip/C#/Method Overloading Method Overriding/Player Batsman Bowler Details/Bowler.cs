﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Bowler : Player
{

    private long _noOfWickets;

    public long NoOfWickets
    {
        get { return _noOfWickets; }
        set { _noOfWickets = value; }
    }

    public Bowler()
    {
    }

    public Bowler(string name, string teamName, long noOfMatches, long noOfWickets) :
        base(name, teamName, noOfMatches)
    {
        this._noOfWickets = noOfWickets;
    }

    public void DisplayDetails() {
        Console.WriteLine("Bowler : " + Name);
        Console.WriteLine("Team : " +  TeamName);
        Console.WriteLine("Number of matches : " + NoOfMatches);
        Console.WriteLine("Number of wickets taken : " + this._noOfWickets);
    }
}