﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Player
{

    private string _name;

    protected string Name
    {
        get { return _name; }
        set { _name = value; }
    }

    private string _teamName;

    protected string TeamName
    {
        get { return _teamName; }
        set { _teamName = value; }
    }

    private long _noOfMatches;

    protected long NoOfMatches
    {
        get { return _noOfMatches; }
        set { _noOfMatches = value; }
    }

    public Player()
    {
    }

    public Player(string name, string teamName, long noOfMatches)
    {
        this._name = name;
        this._teamName = teamName;
        this._noOfMatches = noOfMatches;
    }

    public new void DisplayDetails()
    {
    }
}