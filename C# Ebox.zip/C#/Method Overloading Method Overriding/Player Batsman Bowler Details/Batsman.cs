﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Batsman : Player
{

    private long _noOfRuns;

    public long NoOfRuns
    {
        get { return _noOfRuns; }
        set { _noOfRuns = value; }
    }

    public Batsman()
    {
    }

    public Batsman(string name, string teamName, long noOfMatches, long noOfRuns) :
        base(name, teamName, noOfMatches)
    {
        this._noOfRuns = noOfRuns;
    }

    
    public void DisplayDetails()
    {
        Console.WriteLine("Bowler : " + Name);
        Console.WriteLine("Team : " + TeamName);
        Console.WriteLine("Number of matches : " + NoOfMatches);
        Console.WriteLine("Number of runs scored : " + this._noOfRuns);
    }
}