﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Delivery
{
    public Delivery()
    { }
    public void DisplayDeliveryDetails()
    {
 
    }
    public void DisplayDeliveryDetails(string bowler, string batsman)
    {

        string bowlerName = bowler;
        string batsmanName = batsman;
        Console.WriteLine("Bowler : " + bowlerName.Substring(bowlerName.IndexOf(" ") + 1));
        Console.WriteLine("Batsman : " + batsmanName.Substring(batsmanName.IndexOf(" ") + 1));
    }

    public void DisplayDeliveryDetails(long runs)
    {
        Console.WriteLine(("Number of runs scored in the delivery : " + runs));
        if (runs == 4) {
            Console.WriteLine("It is a Boundary.");
        }
        
        if (runs == 6) {
            Console.WriteLine("It is a Sixer.");
        }
        
    }
}
