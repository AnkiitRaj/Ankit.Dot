﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Menu");
        Console.WriteLine("1.Player details of the delivery");
        Console.WriteLine("2.Run details of the delivery");
        int choice = int.Parse(Console.ReadLine());
        if (choice == 1)
        {
            Console.WriteLine("Enter the bowler name");
            string bowlerName = Console.ReadLine();
            Console.WriteLine("Enter the batsman name");
            string batsmanName = Console.ReadLine();
            Delivery d = new Delivery();
            d.DisplayDeliveryDetails(bowlerName, batsmanName);
        }

        if (choice == 2)
        {
            Console.WriteLine("Enter the number of runs");
            long runs = long.Parse(Console.ReadLine());
            Delivery d = new Delivery();
            d.DisplayDeliveryDetails(runs);
        }
        Console.ReadKey();
    }
}