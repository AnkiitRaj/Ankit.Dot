﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class InternationalPlayer : Player {
    
    private string _capNumber;

public string CapNumber
{
  get { return _capNumber; }
  set { _capNumber = value; }
}
    
    private long _noOfTestAppearance;

public long NoOfTestAppearance
{
  get { return _noOfTestAppearance; }
  set { _noOfTestAppearance = value; }
}
    
    private long _noOfODIAppearance;

public long NoOfODIAppearance
{
  get { return _noOfODIAppearance; }
  set { _noOfODIAppearance = value; }
}
    
    public InternationalPlayer()
    {
    }
    
    public InternationalPlayer(string name, string country, string capNumber, long noOfTestAppearance, long noOfODIAppearance) : 
            base(name, country) {
        this._capNumber = capNumber;
        this._noOfTestAppearance = noOfTestAppearance;
        this._noOfODIAppearance = noOfODIAppearance;
    }
    
    
    public new void DisplayDetails() {
        Console.WriteLine("Player Details:");
        Console.WriteLine(("Player name : " + Name));
        Console.WriteLine(("Country : " + Country));
        Console.WriteLine(("Cap number : " + this._capNumber));
        Console.WriteLine(("Number of test appearnace : " + this._noOfTestAppearance));
        Console.WriteLine(("Number of ODI appearnace : " + this._noOfODIAppearance));
    }
}