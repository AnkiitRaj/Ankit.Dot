using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class Program
{
    static void Main(string[] args)
	{   
        Console.WriteLine("Enter player name ");
        string name = Console.ReadLine();
        Console.WriteLine("Enter player country");
        string country = Console.ReadLine();
        Console.WriteLine("Enter the Cap number");
        string capNumber = Console.ReadLine();
        Console.WriteLine("Enter the number of test appearnace");
        long testAppearance = long.Parse(Console.ReadLine());
        Console.WriteLine("Enter the number of ODI appearnace");
        long odiAppearance = long.Parse(Console.ReadLine());
        InternationalPlayer p = new InternationalPlayer(name, country, capNumber, testAppearance, odiAppearance);
        p.DisplayDetails();
        Console.ReadLine();
	}
       
	

}


