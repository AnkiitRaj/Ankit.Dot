﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Player
{

    private string _name;

    protected string Name
    {
        get { return _name; }
        set { _name = value; }
    }

    private string _country;

    protected string Country
    {
        get { return _country; }
        set { _country = value; }
    }

    public Player()
    {
      
    }

    public Player(string name, string country)
    {
        this._name = name;
        this._country = country;
    }

    public void DisplayDetails()
    {

    }
}